# memory · dev-20261108-001

## 2026-11-11 · Stage4 Part A

- sr_test CREATE IF NOT EXISTS OK；表原已在
- test.dws 11-08：171091 / 空渠道 0
- pb_ 写 sr_test 11-10：837 行；产 Paimon 同日 168615
- 根因：sr_test 外挂 `paimon.dws` COUNT 也是 837 → catalog 可见不全，非 SQL 少写
- 等主人面板勾 Stage4 三项；**未**代勾；**未**标 Stage4 done

## 2026-11-11 · Stage3

- lint OK；`dim_active_device_cnt`/`dim_new_device_cnt` propose+bind；full_chain 备 pb_ 步定义

## 2026-11-11 · start-modify v3

- task_version 2→3；from_stage=1
