# ads_app_active_summary 会话备忘

## 2026-11-12
- 狂人 #13268：分工单 docs/migration_assignment_20261016.md 第 42 行写的归蓝猫（猫猫代办）。草稿停住不提交，等狂人和猫猫确认有没有人在做。
- 如果归我：①影子期读 paimon.dws.dws_app_channel_dau_d（11-09 起生产在跑）；10 月补跑完之前上月列对不平是预期内的，先只比上周列。②首版照抄「应用×渠道×天行求平均」，改不改由知秋定，改了出 v2。③paimon 主键表用 INSERT INTO 按 app_id upsert，不用 OVERWRITE，旧应用保留。
