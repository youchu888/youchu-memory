# 死规矩 · Dev Session 禁止空标 stage done（主人 2026-07-29）

**适用**：又初推进任何平台 `dev-session`（含重建、提审、推进 stage、request-publish）。

## 铁律

**stage 1～6 的 `done` 必须伴随 `state_json` 执行产物。**  
列表好看 ≠ 可审。野花 / 审核插件在 stage7 要读前面各阶段「干了什么」；读不到就打不开。

## 禁止

- ❌ 只调 `POST /dev-sessions/{code}/stage/{n}/status` 把 1～6 标成 `done`
- ❌ `PUT /full` 只塞 title / rel_dir / outputs，不写 stage4/5/6 产物
- ❌ 用附件 HTML、口头「已推进」、或「列表 pending 野花」冒充阶段完成
- ❌ 缺产物仍 `request-publish`（等于把空壳交给审核）

## 必须写入 `state_json` 的字段

| key | 含义 | 最低内容 |
|-----|------|----------|
| `strict_mode` | 走法标记 | 如 `light_no_complement` |
| `owner_boundary` | 本侧职责边界 | `our_duty_ends_at` + `we_do_not` |
| `stage4_db_check` | 测试阶段产物 | `created` / `etlRan` / `playbookConfirmed` 全 true，且带 `etlMeta`（真查库结果）；有海豚则带 `live_sql_checks` |
| `stage5_prod_dryrun` | prod 干跑 | `prod_missing`（表/列级）+ `checked_at` |
| `stage6_commit` | 提交记录 | `sha`（`git rev-parse HEAD`）+ `checked_at` |

对照健康样本：`dev-20260727-comic-chapter-001` 等（≥12 key）。空标常见只有 5 个 key。

## 正确顺序

1. 真查 test（列/行/口径）→ 写 `stage4_db_check`
2. 真查 prod 缺什么 → 写 `stage5_prod_dryrun`
3. 记 commit → 写 `stage6_commit` + `owner_boundary` + `strict_mode`
4. `PUT /full` **合并**写入（勿丢既有字段）；stage7 保持 `in_progress`
5. 需要发产才 `request-publish`；**不需要海豚的（如纯 Spark）只补产物、不 RP**

参考脚本：`omdb/projects/event-new-fields/scripts/_strict_rewalk_one.py`

## 增补 · 2026-11-04（产品周提审 · 同日两拦）

再犯即违规。提审 / 补 note / 改 SQL 进 session 时：

1. **禁止**用「只有 title/target/sql 的瘦 state」整份 `PUT /full` 覆盖 —— 会冲掉 `dolphin_owned_tasks`；产发向导 Step2 报「既无 owned[env=test] 也无 target.task_code / 不可同步」，即使 test 海豚 task 仍在线。
2. **必须**合并保留：`dolphin_owned_tasks`（至少一条 `env=test`，含 project/wf/task code+name）、完整 `target`（prod 三元组；建议 `test_task_code`）、既有 stage4～6 / `publish_runs`。
3. **已产发归档**（`is_archived=true`）的 session：先 `POST /dev-sessions/{code}/uncomplete`，再 `request-publish`。否则 index 上 pending，野花「待我审核」列表仍看不到（默认滤归档）。
4. 提审后自检：`index?q=code&include_archived=false` 能命中且 `publish_request_status=pending`；`full` 里 `owned[env=test]` 非空。

详见 lesson：`lessons/2026-11-04-request-publish禁冲owned与先解归档.md` · 红线 35：`pinned/06-request-publish-owned-archive.md`。

## 自检（提审前必跑）

```bash
# 五件必须齐；缺任一禁止 RP
python3 -c "
import json,urllib.request
# ... GET /api/v1/dev-sessions/<code>/full
need=['strict_mode','owner_boundary','stage4_db_check','stage5_prod_dryrun','stage6_commit']
s4=sj['stage4_db_check']
assert all(k in sj for k in need)
assert s4.get('created') and s4.get('etlRan') and s4.get('playbookConfirmed')
"
```

## 打开会话（与空标并列的死规矩）

平台自 **2026-06-17** 起：**文件 content 不落 backend**（`GET /file` → 410；`bulk-pull` 只有 path）。

别人要打开 session，必须：

1. VS Code 工作区打开 **`dmp/dc-parent` 仓库根**（与 `project_id` 一致）
2. `git pull`，保证本地存在 `rel_dir`（例：`ops_system/04.dws/dws_session_duration_d`）
3. 再点开需求；**不能指望后端 materialize 写出正文**

`state_json` 五件齐 ≠ 文件可打开。五件解决的是 stage7 **审核界面渲染**；文件靠 **git 磁盘**。

插件禁止在无 content 时写空壳文件（会制造「打开了但是全空」）。

### 血案 · `进入 stage 失败: session state not found in …`

- 野花从「待发布申请」点 stage → `advanceToStage(dir)` 只靠 `resolveCodeByDir`
- 反查默认 index 对不上别人的 `rel_dir` → `readState` 空 → 报错
- **修**：`advanceToStage(..., { byCode })`；`openDevSessionStage` 必传 `session.state.code`
- 需发新 vsix 后生效

## 关联

- lesson：`lessons/2026-07-29-dev-session-禁止空标stage须落state产物.md`
- Cursor 规则：`.cursor/rules/dev-session-stage-artifacts-required.mdc`
- 平台文档：`dc-platform-server/docs/task_state_model.md`（Gate1 stage4 三勾）
- 插件：`vscode-extension/src/dev-session.ts` `advanceToStage`


归类入口：[`playbook_spark_prod_publish.md`](playbook_spark_prod_publish.md)
