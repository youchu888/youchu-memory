# 【点击率分析】ads_page_item_ctr_d · 又初 — 会话备忘录

## 2026-10-20
- 新建 Spark 会话 dev-20261020-002。
- 已定：按次数；只有曝光也落行；两边都没有不落行；按 event_time 归日；历史先不补；清单维表日期是分区，从 2026-10-01 起维护。
- 上游字段：page/item 均在 payload。

## 2026-10-20 stage3
- Stage 1/2 已完成。Stage 3 编码中：DDL/ETL/step/回写已落盘。

## 2026-10-20 stage3 收口
- step.json 四步补中文名/简介；调度线定为 `g_page_item_ctr`，11 槽，探针 `dw.dw_user_event_detail_new`（规则 `partition`，原 partition_ready 平台不认）。
- lint：ETL 无 error（step.json 头注释 warning 可忽略）。

## 2026-10-20 stage4
- 测试五步已由 API 直接跑完。
- ① 送 SQL ② Paimon+SR 建表 ③ 挂 `g_page_item_ctr`@11 ④ 单跑 T-1 四步 SUCCESS（dim/ads 各 436 行）⑤ 起点 2026-10-19 补 1 天 SUCCESS。
- playbook：rows=436、exposure_only=301、both_zero=0。
- `stage4_db_check` 三勾已写；Stage 4=done，进入 Stage 5。

## 2026-10-20 stage5
- 生产目标表未建、验证无产出：stage5_prod_dryrun=WARN。上游字段核对 PASS。Stage 5=done，进 Stage 6。

## 2026-10-21 stage6
- 会话文档与 SQL 已在 origin/dev；补对接表结构文件 `对接_表结构.md`。
- Stage 6 提交收口后进 Stage 7（仅 request-publish，不自发产发）。旧 tip 曾为 `07c52cef`（仍含 ctr）。

## 2026-10-24 bus#11375 审回改
- 审核未过：表存了 `ctr` 违反「表不存比率」。已去掉 ctr：paimon/SR DDL、ETL、回写、对接说明、spec/design/step 简介一并改。
- test：Paimon rebuild + SR `ALTER DROP COLUMN ctr`；近 3 天有数。

## 2026-10-24 bus#11377
- 去 ctr 版已推 **origin/dev** `59705bcf`（cherry-pick 自 `4e7987a3`）。
- 重做 S6：`stage6_commit.sha=59705bcf`，pushed=true。
- 重做 S5 verify 数据日 2026-10-23：rows=106995；exposure_sum=13508036；click_sum=1766525；与上游 `dw.dw_user_event_detail_new` 两事件条数对平。
- 等狂人复审后让野花发；又初不自行产发。

## 2026-11-03 bus#12164（reply_to #12159）
- **今天不发正式表。** 知秋定：ads 禁直读 `dw.dw_user_event_detail_new`，必须读 dwd_r。
- 设计落定一张 `dwd.dwd_app_pageitem_d_r`（两事件共表）：按 `(dt,app_id,event_id)` 去重；本层解析 page/item；分区 `DATE(request_time)`。
- ads/dim 改只读该 dwd_r；pb 改写 SR 影子 `ads_page_item_ctr_d_paimon_shadow` / `dim_app_page_item_d_paimon_shadow`；Paimon 仍用正式名。
- fanout 条目草稿在 `fanout_dwd_app_pageitem_d_r.snippet.json`，**未改**现网 manifest，等狂人确认。
- 影子闸照 #12151：7 日对平后再谈切流；联调只读影子。

## 2026-11-03 bus#12191（审回 #12186 不达标）
- DDL 改为 first-row 主键表：`PRIMARY KEY (dt,app_id,event_id) NOT ENFORCED` + `merge-engine=first-row` + `bucket=1`（对照 `dwd_app_page_click_d_r`）。
- **删掉**日批 `dwd_app_pageitem_d_r.sql`；唯一写入方=fanout；历史补数走 dwdr_backfill。
- step.json 去掉 dwd 步；dim 探 `dwd.dwd_app_pageitem_d_r` watermark（覆盖次日 03:00 前迟到）。
- fanout 草稿 bucket/sinkParallelism=1；过滤与截断以草稿为准。
- 交狂人三样：DDL、fanout 条目、step.json；编排/seed/合入重启由狂人挂。今日仍不发正式表。
## 2026-11-03 bus#12202\n- C：fanout 合入重启前 ads/dim 影子不发；明日狂人审草稿后再挂。\n

## 2026-11-04 bus#12298 bucket 量级
- 6.4 万来自 test 2026-11-02 日批试跑行数，不是 prod 全量。
- prod 量级按狂人 10-16 实测：曝光约 3815 万/天、点击约 219 万/天 → bucket=32、sinkParallelism=16（对照 page_view）。
- 已改 snippet / DDL / design；paimon dwd_r 不自建、不补数；等狂人合入重启。

## 2026-11-04 bucket 按 prod 实测改 16/8
- 6.4 万=test 2026-11-02 试跑，不是产线。
- prod 探数 `paimon.dw.dw_user_event_detail_new` dt=2026-11-03：exposure=80446332，click=6912631。
- 对照同日 page_view≈6.67亿(bucket32/par16)、page_click≈27亿(64/64)。pageitem≈8736万 → bucket=16、sinkParallelism=8。

## 2026-11-04 又初侧收口（通知狂人合入）
- 交付已齐：`fanout_dwd_app_pageitem_d_r.snippet.json` + `dwd_app_pageitem_d_r_paimon_ddl.sql` + `design.md` 均为 bucket=16 / sinkParallelism=8；commit `44018424` 已在 origin/dev。
- 未动：现网 `fanout/manifest.json`、产线建表、补数、ads/dim 影子发布（等 fanout 合入重启后）。
- bus 通知狂人：请审 16/8 → 合入 manifest → 重启；通过后再说下游影子。

## 2026-11-04 两事件拆成两张 dwd_r
- 作废合表 `dwd_app_pageitem_d_r`（含此前私聊史科特的合表 DDL）。
- 新表：`dwd_app_pageitem_exposure_d_r`（bucket=8/par=4，prod exposure=80446332）+ `dwd_app_pageitem_click_d_r`（bucket=2/par=2，click=6912631）。
- ads/dim/step/task/design/对接已改；直接私聊史科特更正，不经狂人转。

## 2026-11-05 bus#12439 审过 · bus#12440 回又初
- 狂人审完 `ops_system/spark_migrate/ads_page_item_ctr_d/`：ads/dim **可发 prod 影子**。
- 验收：**2026-11-04 试跑**与明细**逐位对平**后放行。
- 产影子执行人：**野花**；又初以 **bus#12440** 收审阅/发产结论，勿自行触发 prod 影子。

## 2026-11-05 bus#12440（回 #12439）
- 狂人审过：可发影子；已派野花只发 prod 影子（不发正式）。
- prod 核验 dt=2026-11-04：键 156440；曝光 76251917 / 点击 4606580，与两张 dwd_r 同窗口逐位相等 → part_04 PASS；列宽无超。
- 非阻断：有点击无曝光键 36774（约 23.5%）→ playbook 已加 part_05，影子期日盯。
- 闸门（其后被 #12455 废）：影子连续 7 数据日核平再谈正式表。又初未自行产发。

## 2026-11-05 bus#12444 · dwd_r DDL 对齐 prod
- 野花 S7 ②卡：ads/dim Paimon 已建；两张 dwd_r「生产已有同名表但结构不同」。
- 按狂人 DESCRIBE 改仓库 DDL：32 列（补 12 列）、dt 末列、PK (dt,app_id,event_id)、first-row；exposure bucket=16/tfs=256mb，click=4/tfs=128mb；加 lookup-wait=false。
- fanout snippet 对齐 prod：exposure 16/16、click 4/4；列映射跟 DDL；**未 ALTER 产表**。
- 回 S4 提交后请野花重走 S7。

## 2026-11-05 bus#12448 · Spark 版 DDL 原样替换
- S7 仍拒：Flink 写法导致 Spark __ddlcheck PARSE_SYNTAX_ERROR，被判「结构不同」。
- 已用 asset 251/252（狂人 SHOW CREATE + dry-run unchanged）原样替换 click/exposure DDL；生产表未动。
- exposure 用 referrer_page_key/name（无 position）；app_id/event_id/dt NOT NULL；USING paimon + TBLPROPERTIES primary-key。
- session 回 S4，待野花重走 S7。

## 2026-11-05 bus#12452 · S7③ 组清单修订
- 测网组仍带旧步 `dwd_app_pageitem_d_r` + dim 探 `dw.dw_user_event_detail_new`；产发不能原样抄。
- step.json 定稿：**无**合表日批步；dim/ads 探针改为 `dwd.dwd_app_pageitem_exposure_d_r` + `dwd.dwd_app_pageitem_click_d_r`（`rule=partition`）。
- 组最终步：dim_app_page_item_d → ads_page_item_ctr_d → pb_dim_app_page_item_d → pb_ads_page_item_ctr_d；挂 **11 槽**。
- 禁手改 full_chain；生产建组交狂人，又初只改 S4 材料。

## 2026-11-05 18:09 再探
- prod 已有两表；exposure 11-04=76251917 / 11-05=48154235；click 11-04=4606580 / 11-05=2978758；抽样字段正常。
- 已 bus 通知狂人：可推进 ads/dim（当时口径为影子）。

## 2026-11-05 bus#12455
- 定案：不走影子，pb 直写正式表；已改 pb_ads / pb_dim / step countTable / task.yaml / 对接 / design。
- #12452 的 partition 探针保留；与正式回写一并入库。又初不自行产发。

## 2026-11-05 影子残留清理
- 删 `*_paimon_shadow_ddl.sql`；design 调度段改正式回写；testcluster `countTable` 改正式名。
- 会话 state：`sr_use_shadow=false`，outputs 无影子 DDL。
