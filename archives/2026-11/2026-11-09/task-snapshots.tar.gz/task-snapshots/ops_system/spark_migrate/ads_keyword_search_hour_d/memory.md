# 关键词检索小时分布 — 会话备忘录

## 2026-10-20
- 会话 dev-20261020-003。老板定先迁这张。
- 现网日批、小时批都 JOIN `dim.dim_user_all`，不是 `dim_user_snap`。
- `paimon.dwd.dwd_keyword_search_h_r` 最后分区 2026-09-14 23 点，停更。改读仍在出数的 `paimon.dwd.dwd_keyword_search_d_r`，小时用 `HOUR(event_time)`，对齐现网 `date_trunc(event_time)`。
- 先做日终（昨天分区）对影子表。小时批继续写今天的正式分区，先不停。不补历史。
- 2026-10-20 晚上老板改了原始需求：用户类型改读视图 `paimon.dim.dim_user_all_d_v`（指向数据日那一版快照，和视频分析日终是同一份）。目标表名改为 `ads_keyword_search_hour_d_d`。空和关联不上仍为 unknown，不改大小写。正式表 2026-10-19 实测 user_type 为 NORMAL / VIP / unknown。

## 2026-10-22
- v3 重开。影子合计 103,423,804，正式表 101,021,108。Paimon 源表同一 event_id 有重复行。10-21 去重后 100,912,821，与 SR 源表去重后相同。正式表多出的 108,287 是 SR 源表自己的重复行。
- 计算改为先 `ROW_NUMBER() OVER (PARTITION BY event_id ORDER BY event_time)` 取第 1 条，再计数。用户维表不改。
- 老板接受 2026-10-21 验证结果：合计差 108,287 可以。用户类型拆分和正式表不一致，是数据日快照对跑批当时用户维，不改代码。

## 2026-11-03 切换材料
- 老板令：照落地页、漫画补切表材料。cutover.md、对账剧本 `00.pipeline/recon/recon_keyword_search_hour_shadow_vs_prod.sql`，存档 `recon_comic_landing_cutover_20261102/keyword_search_hour_1027_1102`。
- 10-27..11-02：影子每天少 11.2 万~15.6 万，逐日等于 SR 源表重复行数；影子合计等于 SR 按 event_id 去重数。不分用户类型时没有一个键影子偏高。用户类型 VIP +70 万~84 万 / NORMAL 对冲。
- 海豚两个任务：日批 21946312976896（wf_ads_日报表_日），小时批 21946311183104（wf_用户活跃留存_小时），均无下游依赖。切表只停日批，小时批留着出当天分区。
- runner 08 槽约 08:03 写完，比海豚日批 06:33 晚约 1.5 小时。
- 狂人 #12217：材料先不过。天任务不许读指向最新快照的视图，用户类型改 `dim_user_snap` snap_dt='${DT}'，开头加 `dim_user_snap$partitions` 分区闸；改完重对 10-27..11-02。其余（合计差、只停日批留小时批、槽位维持 08）通过；当天分区老口径、次日覆盖写进材料给知秋。
- 已改（本地）：用户类型读 snap_dt=DT + 分区闸；去重补定序 `event_time, app_id, uid`（10-27 有 489 个 event_id 最早时刻并列且 app_id 不同，原写法重跑会在应用间跳）。README/design/playbook/task.yaml 同步。
- 定稿 SQL 预算（Spark 查询接口逐日算，本地全键比）：合计与旧影子逐日相同；用户类型净差与旧影子几乎一样（旧影子当天跑时视图正好指向数据日快照）；逐类闭合，存档 keyword_search_hour_1027_1102_snapdt.out。10-27 重跑 21,337 键全等。
- 坑：SR 的 paimon catalog 读 dwd_keyword_search_d_r 不全（10-27 SR 6,902 万行 / Spark 1.007 亿行），这张表预算只能走 Spark。
