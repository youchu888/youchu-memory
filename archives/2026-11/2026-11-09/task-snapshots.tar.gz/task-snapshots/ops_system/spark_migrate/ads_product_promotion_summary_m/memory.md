# memory · 【产品推广月汇总】ads_product_promotion_summary_m · 又初

- session：`dev-20261027-001`（dolphin）
- test task：`23505820688000` @ `wf_ads_日报表_日` / 运营系统 `20524869250304`
- 依赖：并行上游 `ads_channel_metrics_daily_d`（与产品周同）
- 补数：DC `TASK_ONLY` 实例 `88319` SUCCESS（2026-10-27）
- 验数：`month_start_dt=2026-10-01` rows_n=keys_n=11 PASS
- prod：已有产品周表；产品月表待发布建表
- 对接：只保留产品周/月；文档见 `ops_system/05.ads/ads_product_promotion_summary_w/后端对接说明.md`

## 2026-11-02

- 产品月 Spark/SR SQL 加推广窗：`promote_start_date ≤ dt ≤ promote_end_date`（end 空=长期）；不看 status。

## 2026-11-04

- 定案只保留产品周/月；产品月四指标与产品周对齐：改读结算 `dws_app_channel_summary_d_d` + 运营留存/活跃，禁 `ads_channel_metrics_daily_d`。Spark/SR/`task.yaml` 已同步；部门周月不再跟改。
