# 记忆

- 2026-10-17：登录实时表 `dwd_user_login_d_v2_r` 在测试湖有数，事件都是 `user_login`。按现网双分区扫法写 Spark。不跟生产逐值比。
## 2026-11-03 bus#12202\n- event_time 口径：探针加 until=03:00；槽从 04 挪到 03。只 marginSec=60 会早跑。\n
