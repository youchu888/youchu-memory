# 【渠道日指标】ads_channel_metrics_daily_d · 又初 — 会话备忘录

## 2026-10-16
- 新建 Spark 会话 dev-20261016-013。目录与现网海豚会话分开。
- 正式表仍由海豚写入。回写只进影子表。
- 维表只读 paimon.dim.dim_user_snap，条件 snap_dt 等于业务日。不读 dim.dim_user_all。周表月表等这张对完数再写。

## 2026-10-20 stage3 编码

- 主 SQL：`ads_channel_metrics_daily_d.sql`（bm_union/bm_merge，landing click 用 `dwd_landing_page_click_d_r` + dt）
- 待 stage4：test 建 Paimon/SR 影子、跑通补数、与海豚 T-1 对 bitmap_count/SUM

## 2026-10-20 stage4

- commit `123293ae`：test 建表、挂 `g_ads_channel_metrics_daily_d@09`、补 `2026-10-19` → Paimon 4922 行，影子回写成功（`bitmap_from_binary`）。
- 与正式表差额：读 `_r`+`dim_user_snap`；正式海豚读批量表+`dim_user_all`。例 TJ-084 注册 `_r`=2898 / 批量表=141，影子与 `_r` 一致。
- INSERT 静态分区勿再列 `dt`。

## 2026-10-22 bus#11174 S5 Kryo 重跑
- 生产换回 Kryo jar（md5 910a6056）+ kryoserializer.buffer.max=2047m；未动 BitmapUdf.scala。
- 先 sql/deploy 到 `_verify/230fa1fb4825/` 沙箱再跑。
- run：560e5c21… / a72ab7c7…（dt=10-21）、3cad359d…（dt=10-20）均 failed。
- 无 Buffer overflow；Stage47 OOM at KryoSerializer.newKryoOutput（Java heap space）→ ExecutorDead。已 reply bus#11174。

## 2026-10-23 bus#11258 S6 收口 + 提审

- 卡点：管理报表三表依赖 prod `paimon.ads.ads_channel_metrics_daily_d`，现网无表/无编排步。
- S6：`stage6_commit.sha=cc5d524024dd72f17efecb6ded92e7bed40b2c9f`（content `d4346dd0`）；`strict_mode=light_no_complement`；boundary 写清不写正式 SR、不停海豚日指标直至切流。
- 提审：request-publish → reviewer=admin（狂人代审代发）；RP 说明见 note。
## 2026-11-03 bus#12202\n- 到达口径；snap_dt=DT + assert_true 分区闸；禁 dim_user_all_d_v；槽 02；只回写影子。\n
