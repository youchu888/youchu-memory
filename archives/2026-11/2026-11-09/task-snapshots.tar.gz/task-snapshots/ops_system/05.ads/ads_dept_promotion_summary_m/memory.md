# memory · 【部门推广月汇总】ads_dept_promotion_summary_m

- session: `dev-20261013-003`
- 父会话: `dev-20260929-002`（需求与设计在渠道月表目录）
- 粒度: `month_start_dt` × `dept_id`
- 新增: 产品内注册用户去重后，部门内按产品相加
- 充值: `SUM(revenue_total)`，单位分
- test 已建表；海豚 task `23353810189312`，上游 `ads_channel_metrics_daily_d`，工作流 `wf_ads_日报表_日`
- test 补数 pi 84552 SUCCESS（业务日 2026-10-12）：month_start=2026-10-01 一行 dept 41，新增 0、充值 0，与命中日表一致

## 2026-10-14

- 四列齐。一个月、一个部门一行。每天从日表重算本月 1 号到 T-1，覆盖这一行。不按天插行，不在结果上累加。
- 任务说明里的频率仍写 monthly，实际节点在日批里每天跑。
- test：2026-10-01 部门 41，新增 1、充值 2000 分、次留 0、日均活跃 0，与日表一致。次留和活跃为 0 是日表活跃 bitmap 为空。
- 会话 v2，1–6 完成，产发待审。提交 `02e566b9`。生产须按新 DDL 重建后再跑。

## 2026-10-19

- 部门月按是否免费拆行，主键加上 `paid_type`。口径与部门周相同。

## 变更 2026-10-22

- 粒度改为部门/产品 × 渠道（见 design/spec）；主键变更须 DROP 重建。

## 变更 2026-10-22（纠正粒度）

- 部门表主键：时间 × channel × dept_id
- 产品表主键：时间 × dept_id × app_id
- 须 DROP 重建后补数

## 2026-10-22

- 管理报表只保留部门周/月与产品周；渠道周/月表与海豚任务已下线。
- 部门主键：时间 × channel × dept_id；产品主键：时间 × dept_id × app_id。
## 2026-10-20 paid_type hotfix
- test publish + TASK_ONLY complement PI 86451 SUCCESS (biz_dt=2026-10-19)
- month_start_dt=2026-10-01 rows=1; paid_type=-1 (COALESCE no dim)
- prod live SQL 仍无 paid_type；表空；已 request-publish 提审产发

- 2026-10-21（bus#10880）：prod 全表 0 行、task 0~1s SUCCESS。根因：`INNER JOIN dim.dim_channel_info_all`，prod 该维表 COUNT=0 → daily/key_set 空；上游 `ads_channel_metrics_daily_d` T-1≈18万行正常。渠道周/月用 LEFT JOIN 故仍有数。方案：先灌满 prod `dim.dim_channel_info_all`，再补跑 w/m。

## 2026-10-23 16:00 bus#11262 撤回海豚产发申请

- 知秋 10-20 定：管理报表三表不上海豚，走 Spark（dev-20261022-001/002/003 · ad004aed）。
- 本会话 withdraw-publish：原 pending→野花（kakakh7787）申请已撤，status=none。
- 勿再 request-publish 本海豚会话。
