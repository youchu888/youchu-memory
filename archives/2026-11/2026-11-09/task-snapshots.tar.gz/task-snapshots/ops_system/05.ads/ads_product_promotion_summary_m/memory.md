# memory · 【产品推广月汇总】ads_product_promotion_summary_m

## 决策

- 粒度：`month_start_dt` × `dept_id` × `app_id`（与产品周同构，周期改为自然月）
- 指标：该产品下归属该部门的渠道合并后计算；不按渠道拆行
- 部门只认渠道维；无匹配不进表
- 与产品周并存；管理报表四表：部门周/月、产品周/月

## 变更 2026-10-26

- 新建本表（此前产品侧仅有周表）

## 2026-11-02

- 产品月对齐推广窗：日指标只计 `promote_start_date ≤ dt ≤ promote_end_date`（end 空=长期）；不按 status。与产品周同改。
