# memory · 【部门推广周汇总】ads_dept_promotion_summary_w

- session: `dev-20261013-001`
- 父会话: `dev-20260929-001`（需求与设计在渠道周表目录）
- 粒度: `week_start_dt` × `dept_id`
- 新增: 产品内注册用户去重后，部门内按产品相加
- 充值: `SUM(revenue_total)`，单位分
- test 已建表；海豚 task `23353809922176`，上游 `ads_channel_metrics_daily_d`，工作流 `wf_ads_日报表_日`
- test 补数 pi 84552 SUCCESS（schedule 2026-10-13，业务日 2026-10-12）：分区 0 行，当日渠道与维表无交集

## 2026-10-14

- 四列齐：新增、充值（分）、次留、日均活跃。日批覆盖业务日所在自然周，窗口到 T-1。
- 部门只从 `dim.dim_channel_info_all` 取；对不上的渠道不进表。
- test 补数 pi 84750–84753 SUCCESS，工作流版本 364。会话 v2，1–6 完成，产发待审。提交 `02e566b9`。
- 生产仍是旧 RANGE、只有新增和充值。新 SQL 前须按新 DDL 重建。
- 2026-10-19：部门周按是否免费拆行，主键加上 `paid_type`（0 免费 / 1 付费 / 2 半付费）。产品周增加 `dept_code`，对应需求里的部门 id。

## 变更 2026-10-22

- 粒度改为部门/产品 × 渠道（见 design/spec）；主键变更须 DROP 重建。

## 变更 2026-10-22（纠正粒度）

- 部门表主键：时间 × channel × dept_id
- 产品表主键：时间 × dept_id × app_id
- 须 DROP 重建后补数

## 2026-10-22

- 管理报表只保留部门周/月与产品周；渠道周/月表与海豚任务已下线。
- 部门主键：时间 × channel × dept_id；产品主键：时间 × dept_id × app_id。
- 2026-10-21（bus#10880）：prod 全表 0 行、task 0~1s SUCCESS。根因：`INNER JOIN dim.dim_channel_info_all`，prod 该维表 COUNT=0 → daily/key_set 空；上游 `ads_channel_metrics_daily_d` T-1≈18万行正常。渠道周/月用 LEFT JOIN 故仍有数。方案：先灌满 prod `dim.dim_channel_info_all`，再补跑 w/m。

## 2026-10-23 16:00 bus#11262 撤回海豚产发申请

- 知秋 10-20 定：管理报表三表不上海豚，走 Spark（dev-20261022-001/002/003 · ad004aed）。
- 本会话 withdraw-publish：原 pending→野花（kakakh7787）申请已撤，status=none。
- 勿再 request-publish 本海豚会话。

- 2026-11-04 bus#12320：四指标改结算/运营源（禁 ads_channel_metrics_daily_d）；对比报告 compare_week_2026-10-26__bus12320.md；审过再上。

## 2026-11-04 bus#12328
- 狂人审 21088810+832b6f1e 放行改结算/运营源。
- test 已 publish-task-sql（dept 23353809922176 v425 / product 23353810594048 v426）。
- request-publish → 野花 pending；prod 等 sync。上线后第一周分区出行数回狂人。
