# 视频有效播放星型模型(测试) — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 但又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-10-21
- 会话 dev-20261021-001 创建

## 2026-10-22（stage 1）
- dwm.dwm_user_video_d_d 无 is_eff_play 列，表本身即有效播放（>=5s）；用户说的 is_eff_play=1 按 play_day_flag=1 实现
- dws.dws_user_snapshot_d_d_v2 元数据中心查不到（404），字段以仓库 ops_system/00.pipeline/user_daily_backfill/ddl_snapshot_v2.sql 为准；Paimon 表，主键 dt,app_id,uid；user_type 取值 VIP/NORMAL（兜底 NORMAL）
- db.list_connections 当前 0 条授权，stage 1 未实跑数据，验收口径待 stage 4/5 有连接后实测
- 【用户确认】快照 channel 不会为空，organic 是兜底值；关联不上的用户 channel 记 organic（原话「记空」作废）
- 【用户确认】渠道两档分类用英文：organic / channel
- 【用户确认】user_type 用快照 user_type，不用 user_type_eod
- 【用户确认】事实表也回写 SR（事实 + 日 + 周 + 月 四张全回写）
- 【用户确认】新增月表；周表、月表每天增量 → 设计为每天从事实重算 T-1 所在周期分区并覆盖（WTD/MTD，幂等），不做旧 bitmap 累加
- spec 按 model 模式规则重写：S1 只定基础事实表 dws.dws_videoplay_fact_d_d；物化表名/列名/更新方式移出，原话记在 §2.6「物化意向（S2 面板定）」
- 维度登记：app_id rollup=required；channel rollup=source_type 兜底 organic（与用户一致）；user_type rollup=explode_user_type 兜底为空、登记取值 VIP/NORMAL → 与用户说的 vip/non_vip 不一致，待用户拍板（推荐沿用 VIP/NORMAL，关联不上记 NORMAL）
- /api/v1/star-dimensions 本地未连通，维度层次以 dimension.search 返回的 rollup_rule/fallback_value 为准
- 【更正】platform.get_star_dimensions MCP 工具已可用，维度以它为准（覆盖上两条按 dimension.search 的说法）：user_type 层次 split（mode=vip_normal，取值 VIP/NORMAL，无兜底值），不保留 = 所有用户类型（即用户说的 all，不在事实表造 all 行），周/月口径参数 vip 优先/分别算在物化方案选；channel 原值列 channel 兜底 organic，上一层派生列 channel_source_type（organic/channel）物化生成；周/月表 dt = 周期起始日
- 【用户确认】user_type 关联不上的记 NORMAL（方案 A）；事实表 user_type 只有 VIP/NORMAL

## 2026-10-22（stage 2）
- uid→bitmap 用 runner 内置 bm_union(uid)（纯数字直通 / 否则 murmur3_128 低 64 位，与现网 SR/Flink 一致），不走全局字典
- 存储模式抄 dws_drama_episode_fact_d_d：Paimon 计算表（PK deduplicate，INSERT OVERWRITE 分区）+ SR AGGREGATE 回写表（BITMAP_UNION / SUM，INSERT OVERWRITE PARTITION）
- 调度：两张上游都在 g_day_close_all（00 槽，峰值超预算 249%）→ 不加入该线，新建线 g_videoplay_daily，两个 watermark 探针，07 槽（余量 303s），run_mode=partition；备选 15/16 槽
- user_type 匹配上但取值不在 VIP/NORMAL → assert 失败，不静默映射
- state.table_name 仍是占位 dws_videoplay_d_d，stage 3 需 session.rename_table → dws_videoplay_fact_d_d
- 指标 eff_play_users / eff_video_cnt 已 metric.bind(design)，落在 metric_pending（指标库尚未入库，stage 3 metric.propose）

## 2026-10-23（stage 3）
- 【更正 stage 1 第一条】test Paimon 实查 DESCRIBE paimon.dwm.dwm_user_video_d_d：列是 is_eff_play（TINYINT）、dt 是 DATE，没有 play_day_flag；play_day_flag 只是 SR 版同名表的列名。ETL 按 is_eff_play = 1 过滤是对的；spec §2.4 写的 play_day_flag 以 design 为准
- test 实测 2026-10-21：dwm 20.2 万行全部 is_eff_play=1，eff_video_cnt 最小 1；快照只有 VIP(9.1 万)/NORMAL(31.0 万)，channel 无空值
- ETL 两表 dt 过滤统一写 DATE 字面量；修正注释里「dt 为字符串」的错误说法
- prod paimon_query 未启用（503 QUERY_THRIFT_USER 未配），prod schema 未核，上线前需确认 prod 上游同为 is_eff_play
- S2 面板实际物化：周表 + 月表（app_id × channel_source_type，user_type=不保留），没有单独日表、没有保留 VIP/NORMAL 的物化表，与 spec §2.6 原话（日表+周表、保留用户类型）不完全一致，待用户确认
- 平台生成的 pb_dws_videoplay_app_src_w_d / _m_d 回写用 DELETE FROM + INSERT INTO，被 session.lint 判 error（destructive.delete_from）；生成文件不许手改，已报给用户（平台侧需调整生成器或 lint 规则）
- 指标 eff_play_users / eff_video_cnt 已 metric.propose（pending），并 metric.bind(code) 到事实表 + 周表 + 月表共 6 条

## 2026-10-23（stage 2 重开）
- 【用户确认】物化方案维持面板现状：只出周表 + 月表（app_id × channel_source_type，user_type 不保留），不另出日表（关闭 stage 3 那条「待用户确认」）；日粒度直接查事实表 SR 回写表
- 【用户确认】user_type 维度说法统一为 VIP / NORMAL（平台登记即如此）；spec §0 原始需求里的「all/vip/non_vip」是建会话时的表单原话，AI 不可改，用户可在面板「编辑原始需求」修正
- 模型 model_def 原样重存（未改字段，model_hash 不变），design.md 已由平台写入 star-model 物化设计标记段；S3 物化脚本无需重新生成
- 调度复核（快照 v45）：00 槽峰值 7808s 超预算 217%；07 槽余量仍 303s，原结论（新建线 g_videoplay_daily、07 槽、watermark 双探针、partition）不变

## 2026-10-23（stage 3 重写）
- step.json 事实步原为 timer 且无探针，与 design 新建线结论不符 → 改为 trigger=probe + 两张上游 watermark 探针（不写 until），params.render 加 OUT_DB=paimon（照现网 dws_ad_error_metric_d 写法）
- 平台生成的 pb 周/月回写仍是 DELETE FROM + INSERT INTO，但本次 session.lint 不再判 error（0 error）
- 指标库后端查不到 eff_play_users / eff_video_cnt、事实表无绑定 → 重新 metric.propose（pending）+ metric.bind(code) 三张表共 6 条
