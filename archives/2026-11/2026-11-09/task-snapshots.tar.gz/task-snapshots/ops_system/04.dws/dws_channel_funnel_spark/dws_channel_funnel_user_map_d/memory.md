# 渠道漏斗 user_map 迁 Spark · 记录

- 2026-11-03 开 `dev-20261103-001`。漏斗 7 张里第 1 张。
- 生产探查日 2026-11-01：页面_r 8.5 亿，视频_r 22.3 亿，注册_r 604 万。`dim_user_all` 不存在，现网用 `dim_user_all_d_v`。小说/漫画当天 0。
- 字典 v1 已冻：迁移照抄，用户维用 `dim_user_all_d_v`，八张事件一律 `*_r`。不另拍板。
- 2026-11-03 纠：小说/漫画曾误写成无 `_r` 底表；已改 `dwd_novel_event_d_r` / `dwd_comic_event_d_r`。不读离线底表。
- 调度：新建线 `g_dws_channel_funnel_user_map_d`，槽 12。事件水位到次日 03:00。小说/漫画/用户维默认 60 秒。不并进 `g_funnel`。
- 第 1 到第 3 步门禁通过。提交 `7e9c204b` 已推。
- 测试 Paimon 表已建，run `b4b72cab-5aaa-43a1-ade5-270af2faeff9`，表 `paimon.dws.dws_channel_funnel_user_map_d` created。
- 测试影子表 `dws.dws_channel_funnel_user_map_d_paimon_shadow` 已建。
- 试挂组 `g_dws_channel_funnel_user_map_d` 被拒，只允许管理员。第 4 步进行中。未跑计算。生产不挂。不补历史。
