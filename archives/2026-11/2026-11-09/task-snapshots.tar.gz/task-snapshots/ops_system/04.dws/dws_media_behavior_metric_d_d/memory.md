# Paimon｜media 日汇总 — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 但又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-11-07
- 会话 dev-20261107-001 创建

- 用户确认观看时长采用方案 B：仅相邻事件 media_id 均非空白且相同的有效间隔计入该 media；其余间隔不计入，并统计影响。

- 用户确认按数据接收日归属，跨天事件计入接收日；event_time 用于观看间隔排序。
