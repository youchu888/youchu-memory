# memory · dev-20261016-001

- 2026-10-16：开会话。样板表 = 金币消耗。T-1（10-15）SR 明细与汇总次数 235805、枚数 9630037 已对齐。字典 v0.1 未冻结，未写 Spark SQL。
- 2026-10-16：主人定「一张表一个任务」。本表不拆日任务和小时任务。海豚现有两个写入方，切的时候一起停。
- 2026-10-16：写出沙箱 SQL `pipeline-runner/sql/dws_app_coin_consume_d_h.sql`，目标只写 `${OUT_DB}`。runner 的 test 控制面是通的。试跑要先把这份 SQL push 后再 `sql/deploy env=test`，本机 ssh 进不了 hadoop-1。
- 2026-10-19：知秋定组是依赖顺序，不是分类。加组要反复确认。金币消耗不加组，不进 `day_close_all`，单独一条线。组的中文说明等下一次插件升级。
- 2026-10-20：试跑 `run_id=17ee59e2-36dd-4371-bc0a-1785e8c37a4e` env=test SUCCESS rc=0，约 5 分钟。写出 `test.dws.dws_app_coin_consume_d_h` dt=2026-10-15：行 1846 / 次 3831 / 枚 131878。测试集群源表同日只有 3834 条事件，不是生产全量；SR prod 同日 77069 行 / 235805 次。对生产基线要用 env=verify，但 `sql/deploy env=prod` 被拦（须发布审核人/管理员）。commit `5c85dbe6`。
- 2026-10-20：补齐 step.json / task.yaml / design spark-scheduling（新建线 `g_dws_app_coin_consume_d_h`、槽 08、双探针）；会话 SQL 与 pipeline-runner 对齐。
- 2026-10-20：主人要求严格走 stage、每层汇报。已 **撤回** 过早 request-publish。S1：字典冻结 v1（金额转法 A / 维表 dim_user_all_d_v / 槽 08 / 日终一次）。
- 2026-10-20：S2 gate OK；S3 拆 `*_paimon_ddl.sql` + 计算脚本显式列清单，spark-gate3 / lint 均 ok。
- 2026-10-20：S4 API 五步完成（槽 08 组新建；补数 10-15~19 全 SUCCESS）。
- 2026-10-20：bus#10815 知秋放开 S5 开发者送 prod SQL；旧 RP 已撤。
- 2026-10-20：bus#10824 定验收 A（Paimon `_r` 真源）。去重版 `4f198b80` verify `3ecfb11c` · Spark vs `_r` 逐 app mismatch=0 · **S5 done**。同 event_time 窗 vs SR 剩 113 app 差（含 SF-02）已回 #10825。
- 2026-10-20：**S6 done** · checklist 全勾；fileHead 对齐后 test 重跑 `febfbb32` SUCCESS；request-publish 曾指向超管。
- 2026-10-21：**request-publish pending** · reviewer=知秋（`zhiqiu5678@gmail.com`）。
- 2026-10-22：知秋已发布 · S7 **done** · 生产只补数据日 2026-10-21。paimon 78948 行 / 次 242077 / 枚 9976322；主键重复 0；新+老对齐。vs SR 枚数 +6.5%，解释用（#10824）。
- 2026-10-28：知秋要求补回写步。正式表仍由海豚日任务和小时任务写，回写目标定为影子表 `dws.dws_app_coin_consume_d_h_paimon_shadow`。本步还没挂生产，正式表没改。
- 2026-10-28：平台第 1–3 步已完成。本地提交 `c7503252`。推送被挡住：HTTPS 没有已保存的登录，SSH 8082 被远端关掉。第 4 步要等这版推到远端才能部署。
- 2026-10-29：回写提交已推到 `dev`，`27b9e62fc48086888ac141dc3d193c747ee2adab`。测试第 4 步完成。影子表已建，回写步只挂测试线。2026-10-28 计算 42 行，回写影子表 42 行。正式表没写。
- 2026-10-29：第 5 步 PASS。验证跑 `079a1dd3` 写入 `test.dws`，79273 行 / 次 245098 / 枚 10072816。与去重后的 `dwd_coin_consume_h_r` 逐 app 差 0（343 个 app）。新+老等于总计。主键重复 0。回写步未在验证模式跑。
