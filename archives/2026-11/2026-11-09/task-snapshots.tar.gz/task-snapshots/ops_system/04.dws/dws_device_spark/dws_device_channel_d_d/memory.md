# 设备渠道日表

## 2026-10-30

- 开 `dev-20261030-003`。新表 `dws.dws_device_channel_d_d`。
- 第 1 到第 3 步已标完成。第 2、第 3 步门禁通过，错误为空。
- 2026-10-30 测试建表成功。建表 run `0fab8769-b0d9-4c65-8caa-e54bd4671930`。
- 只跑了数据日 2026-10-15。计算 run `07a7fd21-ae74-431c-ae59-c1b3fdb7c612`，success，rows_out 3038。
- 3038 行，等于设备天表当天的应用加渠道个数。活跃设备合计 10,654,786，新增 8,228,271，支付金额 546,926 分，都与设备天表相同。次日留存两列 3038 行全空。10 月 14 日 0 行。
- 旧表 `dws.dws_app_device_channel_d_d` 当天仍是 2712 行。
- 试挂测试组 `g_dws_device_channel_d_d` 被拒，只有管理员能建组。其他日期没跑。生产没动。第 4 步没有整步标完成。
- 代码 `f5ba640c` 已推送。
- 2026-11-03：地域第 6 步先放着，回接这张。测试目录确认没有 `g_dws_device_channel_d_d`，设备天表组 `g_dws_device_d_d` 已在。已 bus 请狂人在测试槽 12 建空组。生产不建。

## 2026-11-04

- 狂人 bus#12155：测试槽 12 已建组并挂步 `dws_device_channel_d_d`；sqlFile 指测试 repo；生产不挂。
- 第 4 步重核 10-15：rows=3038=pairs · active/new/paid 对齐设备天表 · d1 全空 · 旧表 2712 · PASS。
- SQL 注释去占位符（lint）。playbook / design / task.yaml / README 对齐「测试已挂」。
- 第 4 步标 done。进入第 5 步测试部署实跑。
- 第 5 步：deploy `59e48658` 200；run `8fa524b8` success rows_out=3038；六项对账 PASS。stage 5 done。
- 文档对齐现行规则：落地字段字典 `field_dict_dws_device_channel_d_d_v1_20261104.md`；spec/design/playbook 指向字典并写明继承 bus#12330；标明测试编排现为 timer、设计目标 probe。设备天表 spec/design 同步修正「已 RP 待审」边界句。

## 2026-11-05

- 第 6 步：测试证据齐（S4/S5 PASS · 10-15 · 3038 行）；申请发布给 **野花**（`kakakh7787@gmail.com`）。
- 边界调整说明：session 原写「生产不建」= 开发期不擅自建产；现按设备天表同路径，请野花审后生产建表+挂编排。不回写 SR。不改旧表 `dws_app_device_channel_d_d`。
- 原「timer → probe」待办作废：正式挂法与 002 同为 `g_device_daily` 组内 timer（#12557/#12569）。

## 2026-11-06 · #12538 / #12544

- 上游改为 `dwm.dwm_device_d_d`；排程挂入 `g_device_daily` 末尾接 `dwm_device_d_d`；`timer`、删探针。
- SQL 加 assert 闸；design 写明重跑 D 必须连带 D+1。
- 去掉「生产不建/不挂」现行措辞；发布等 002 首跑 + 野花批。
- 等 002 改名 push 后再 push 本表改动。

## 2026-11-06 · #12569

- 狂人复核 002 通过（`c162cadb`）并同步测试机，授权开始改 003。
- 本版：读 `dwm.dwm_device_d_d` + assert 闸；测试编排删 `g_dws_device_channel_d_d`/12 槽，步挂入 `g_device_daily` 末尾接 `dwm_device_d_d`；timer、无探针。
