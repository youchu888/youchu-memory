# 设备天表

## 2026-10-30

- 开 `dev-20261030-002`。第 1 到第 3 步已完成。
- 2026-10-30 测试建表成功。建表 run `a53f51b2-786c-4ac7-a9cb-971d48e17800`，表 `paimon.dwm.dwm_device_d_d` 新建。
- 只跑了数据日 2026-10-15。计算 run `b1eeb68e-e8b3-48a3-80d2-a10323b242b1`，success，rows_out 10,654,786。
- 当天行数与日间表相同。设备号空 0。新设备标记与首次出现日不一致 0。新设备 8,228,271。
- 天表支付金额 546,926 分，等于能对上日间表的那部分。支付明细当天合计 33,319,626 分，其中 2,136 台设备不在日间表里，金额 32,772,700 分，没有写进天表。
- 编排没挂。其他日期没跑。生产没动。平台第 4 步没有整步标完成。
- 2026-10-30 试挂测试编排：新建组 `g_dwm_device_d_d` 被拒，只有管理员能建组。测试上没有这个组。没有挂进 07 点的设备日结线。
- 已加急 bus#11801 回复 #11774，请狂人在测试槽位 12 建空组。生产不建。组好了再挂步、再补 10-14 到 10-29。
- 2026-11-02：bus#12077 已把计算步挂进测试槽 12 的 `g_dwm_device_d_d`。他 seed 数据日 10-31，成功但 0 行。日间表当天 8303 行，快照当天 0 行（10-30 有 93,916,759，11-01 也是 0）。关系日表和支付明细当天也是 0，但这两张是左连接，不是 0 行的原因。天表内连接快照，快照没有这一天就把日间表整段丢掉。

## 2026-11-04

- 按基础表铁律改验收：支付只对「日间 ∩ 支付」；跑前闸要求 snap+日间日结有数；调度注明只认日结正式版。
- playbook.md 已写。SQL 统一 DATE 比较（下一跑生效）。
- 第 4 步重核测试 dt=2026-10-15：前置 snap=18,855,909 / intraday=10,654,786；天表行数=10,654,786；device_code 空=0；is_new 不一致=0；paid_fen 天表=546,926 = 日间∩支付。PASS。生产不动。
- 第 5 步：commit `5975dfb6` → test sql/deploy；槽 12 `g_dwm_device_d_d` 重跑数据日 10-15，run `c6cf80bf` success rows_out=10,654,786；同日再跑 `1d520cdf` 同样 10,654,786。核：行数=日间、null_code=0、is_new 不一致=0、paid_fen 546,926=日间∩支付。生产验证未跑（生产不建）。stage 5 done。
- 第 6 步取证后用户授权勾完。commit `5cb9acd7` 已推。发布申请 pending，审核人野花（`kakakh7787@gmail.com`）。请审核发产：生产 Paimon 建表 + 挂编排；不回写 SR；历史先不补。

## 2026-11-06

- 野花已批：生产建表并挂编排；历史不补；不回写 SR。牡丹转发狂人 #12520 发产前修改清单。
- 已改：
  1) 排程：不新建线/不挂 12；挂入 `g_device_daily`（03）末尾接 `device_order_paid_v3_daily`；`trigger=timer`；删 4 个 watermark（step.json / design §3 / task.yaml）。
  2) SQL：uid_rel / order_paid 子查询 `WHERE dt = '${DT}'`（STRING 分区）；intraday 仍 `DATE '${DT}'`；加 `partitionOverwriteMode=dynamic`。
  3) 文档去掉「生产不建 / 生产不挂 / 测试专用」边界（DDL 头、step 说明、task note、design/spec/README）。
- 改完 push origin/dev · commit `bf41ccc9` · bus#12529 回狂人；后续狂人：生产建表 SHOW CREATE → 改编排 → 部署闸 → 核首跑。

## 2026-11-06 · 层改名 dws→dwm（知秋拍 · #12541）

- 表名：`paimon.dwm.dwm_device_d_d`（生产已建；旧 `paimon.dws.dws_device_d_d` 空表先留）。
- 仓库目录：`ops_system/03.dwm/dwm_device_d_d`（自 `04.dws/dws_device_spark/dws_device_d_d` 迁出）。
- SQL / step / DDL / 文档统一 `dwm_device_d_d`；测试 full_chain 挂入 `g_device_daily` 末尾（#12557 去掉单组 `g_dwm_device_d_d` / 12 槽）。
- push 前先 bus 狂人在测试建表核结构。
