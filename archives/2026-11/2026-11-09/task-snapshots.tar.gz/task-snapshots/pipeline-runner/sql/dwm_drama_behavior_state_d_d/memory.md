# 剧集｜Paimon｜行为中间状态 — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 但又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-10-20
- 会话 dev-20261020-004 创建


## 2026-10-24 短剧日报复用增量（v6）

用户授权004按插件S1→S3完成，不改生产，审核仍由用户提交。004只末尾增4列：has_coin_unlock、has_daily_source、daily_drama_name、daily_episode_no，41→45。006下一步对应加4列（66→70），日报最终只读006并保持15列，005/007及MV本次不改。来源标记不能用净指标是否为0代替；剧名/集号须按旧日报有效video和event_time/request_time/event_id规则单独选唯一属性，保留原scope_name及episode_states。新字段历史NULL必须回刷，不能默认当0。旧候选测试通过不代表v6已验收。
