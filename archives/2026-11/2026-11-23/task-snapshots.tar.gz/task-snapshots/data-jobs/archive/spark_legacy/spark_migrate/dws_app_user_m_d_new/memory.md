# memory · dws_app_user_m_d_new（_uc）

- 2026-11-18：同周表批次，首版 `_uc`。历史比对：周全等；月自 10-20 起约差 3 人（怪 uid 清洗）。
- 平台 session：`dev-20261118-002`。

- 2026-11-19：test SR 已建 `dws_app_user_m_d_new_uc_paimon_shadow`；S4 同周表，待 deploy 后 run-step。

- 2026-11-19：commit `39268d3d` 已推 origin/dev；sql/deploy test 成功。run-step 冒烟 dt=2026-11-05：周计算 rows_out=6614、周 pb shadow=6614；月计算=6693、月 pb=6693。注意 runner 日志任务日→数据段为 11-05→11-04，后续对平按实际写入周/月核对。

- 2026-11-19：test 多日补跑数据日 10-30~11-05（任务日=数据日+1）周/月计算+pb 全 PASS。与周表同批；月初/周切日行数波动见周表 memory。

- 2026-11-20：影子 month 202611/202610 与 paimon 一致。套表报告见 spark_migrate/reports/recon_new_split__2026-11-18__20261120_105148.md

- 2026-11-20：月表人数对平见周表同日；收口报告 reports/recon_new_split__2026-11-20_closeout.md
