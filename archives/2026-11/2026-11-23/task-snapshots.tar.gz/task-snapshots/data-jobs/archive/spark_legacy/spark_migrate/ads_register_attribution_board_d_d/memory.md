# 【归因看板】ads_register_attribution_board_d_d · 又初 — 会话备忘录

## 2026-10-16
- 新建 Spark 会话 dev-20261016-006。目录与现网海豚会话分开。
- 正式表仍由海豚写入。回写只进影子表。
- 归因结果已在 Paimon。本表是还没迁的看板。

## 2026-11-13 test A6
- 单跑 11-12 ETL+pb SUCCESS（当日 result 湖 0 行 → 入围有数、候选/成功/rewrite 均为 0 档）。
- 完整 rewrite 核对仍等 B1 attr_rewrite 挂后有结果分区再对。

## 2026-11-16 bus#13609
- B1 已上产，完整 rewrite 核对可择日跟；不再等「未挂」。
