# memory · dim_app_info_all 核清

- 2026-11-19：B1 核清收编。正式稿 `spark/06.dim/.../dim_app_info_all_sync.sql`（srViews）；full_chain 05 槽已挂。禁 JDBC。
- 探数：test paimon 10-19～11-18（缺 10-31）；prod 02-12～11-18。T-1=11-18 SR=Paimon 行数 test 932 / prod 1159；prod CRC 与字段聚合一致；test 键集+字段聚合一致（导出中文名编码乱码勿当内容差）。
- 对平注意：SR `LENGTH` 中文是字节，比名字用 `CHAR_LENGTH`。
- 不新建七步 session、不发产挂步；新分下游直接认本表。

- 2026-11-19：test 缺分区 10-31 已补跑（任务日 11-01 → 数据段 10-31，rows_out=881=SR）。窗口 10-19～11-18 现应连续。
