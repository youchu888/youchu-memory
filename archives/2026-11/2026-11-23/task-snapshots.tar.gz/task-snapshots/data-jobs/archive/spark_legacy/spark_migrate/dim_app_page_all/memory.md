# memory · dim_app_page_all（新分 B2）

- 2026-11-19：开 B2。正式海豚稿 `ops_system/06.dim/job_dim_page_type_d/`；迁 Spark 走 upsert + `_r`。
- 探数：test SR 约 37.5 万行（有 create_time）；prod SR 无 create_time 列。test paimon 已有空表但无 PK/merge-engine → 须 DROP 重建。`dwd_app_page_view_d_r` test T-1 有数。
- 定稿：首灌 srViews；日增 CACHE prev + COALESCE create_time；pb 整表影子。prod 不挂不切。

- 2026-11-19：test DDL DROP 重建 PK 表；首灌 seed rows_out≈375025；日增 11-12~11-18 全过；pb 影子 375048。正式 375097，差约 49 键（WARN，约 0.01%）。commit e14efccd 已推 origin/dev。

- 2026-11-20：对平 formal 384866 / shadow 375048；only_formal≈9870 only_shadow≈52（水位滞后 WARN）。见 spark_migrate/reports/recon_new_split__2026-11-18__20261120_105148.md

- 2026-11-20：页面再首灌+pb，影子 384815≈正式 384866（只在正式104/只在影子53）。

- 2026-11-21（bus#14178 放行补句）：只在影子约 50 键里，`create_time=2026-09-17 16:46:33` 一批（约 22）为异常/乱码 `page_key`（夹杂替换字符）。来源=首灌 `srViews` 继承当时 test SR 正式表脏键；旧正式日批只从 `dwd_app_page_view_d`（非 `_r`）增量 upsert，且要求 `page_key/page_name` 非空——这些脏键不在现网日源，正式侧日增写不进去（或表清理后不再含）。**不是影子多算，也不是某条 WHERE 误过滤正常键**。其余 only_shadow 多为水位/后灌时差。不挡放行。
