- 2026-10-17 访问和跳转已写。停留等 dwd_app_page_stay 实时表。人数用去重数对 bitmap_count。
- 2026-10-17 bus#10620：停留四列写 0 只能走到 S4。实时表由另一组建，建好前不能发布替换现网，否则停留指标会变成 0。
## 2026-11-03 bus#12202
- 核为到达口径；槽改 02；时间口径=到达；只回写影子可发。

## 2026-11-12 bus#13228 B2
- 停留改读 `paimon.dwm.dwm_app_page_stay_d`（产湖已有数）；uid_cnt 改字典号 bitmap（cand + thenSql，照漫画账号样板）。
- 影子/ Paimon 旧 bigint 须 DROP 重建（`recreate_shadow_uid_bitmap.sql` + 新 DDL）；pb 用 `bitmap_from_binary`。
- step 改 `impl=id_dict`，探针加 stay；产编排挂步/重建影子交审。

## 2026-11-12 bus#13263
- 狂人：今晚 00 槽不叠加编排；B2 照常推进。停留+字典号 bitmap 已在 5397ce8d；本 bus 另交 prod SR 影子 ALTER 运维包。

## 2026-11-13 test B2
- test SR 影子 `uid_cnt` 已 bitmap（旧表 rename 旁路 `_old_bigint`，DROP 无权限留下）。
- test Paimon DROP/CREATE：`uid_cnt`→BINARY；SQL 已同步 `testcluster/repo/.../dws_app_page_visit_d_d/`。
- 编排挂 `impl=id_dict` + `dict:uid_bl/rev_bl/counter_bl`（bak=`full_chain.json.bak_20261113_page_visit_id_dict`）。
- 单跑 数据日 2026-11-12：ETL `rows_out=3484`；id_dict cand=33392 new=0。
- 首轮 pb 因 SR 目录缓存仍见 BIGINT→VARBINARY 失败；重跑 pb OK `rows=3484`。
- 影子核：rows=3484 pv=428816 uid_card=132850 stay_sec_sum=0（test 湖 `dwm_app_page_stay_d` 仅空表，停留列暂 0；daemon 探针 stay 水位会等）。

## 2026-11-13 test B2 续
- 挂 `dwm_app_page_stay_d`（组内先于 page_visit）；单跑 11-12：`rows_out=367351`。
- 重跑 page_visit+pb：影子 stay_sec=13090347 / stay_pages=367351 / dropout=418；uid_card 仍 132850。
- FULL JOIN 报告：`validate__2026-11-12__test_b2_fulljoin.md`（equal_pv_stay 3109；uid 字典差预期）。

## 2026-11-16 B2 运维包
- prod 只读确认 uid_cnt 仍为 bigint。
- recreate_shadow_uid_bitmap.sql 补全 DROP+CREATE；运维说明 ops_B2_prod_shadow_recreate.md。
- 时机：知秋重建 paimon 后 → 运维跑重建 → 回执 SHOW COLUMNS → 再挂编排。

## 2026-11-16 bus#13609
- 狂人：B1 已上产（md5 6bab36b2，挂 g_dimuser_close）；11-15 对正式 918/913+5 已知差。A1 他排比对问知秋。B2：他重建 paimon，又初找运维重建 SR 影子后回他挂。
- 又初：仓内 md5 对齐；运维工单已出 `运维工单_B2_prod_SR影子重建.md`；待运维执行。

## 2026-11-16 B2 prod SR 重建完成
- 运维已重建；prod 只读 SHOW COLUMNS：15 列，uid_cnt=bitmap，主键 dt/app_id/page_key。
- 已 reply bus#13609 请狂人核后挂编排。
