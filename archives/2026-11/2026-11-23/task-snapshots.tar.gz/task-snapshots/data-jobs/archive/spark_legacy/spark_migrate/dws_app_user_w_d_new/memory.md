# memory · dws_app_user_w_d_new（_uc）

- 2026-11-18：周活跃迁 Spark，首版走字典号 `_uc`；对平窗口 ≥08-03；平台 API 化上线前 prod 不挂不切。
- 仓内稿源：`ops_system/00.pipeline/uid_dict/v3_hbase/active/dws_app_user_w_d_new_uc.sql` + ddl；pb/影子由 runner 普通稿改表名。
- test `dws_app_user_d_h_uc` 已有分区：10-30~11-05 连续、11-13；缺 11-06~11-12。paimon `dws_app_user_w_d_new_uc` 表已存在（历史单跑残留）。
- 平台 session：`dev-20261118-001`（需插件打开一次回填 state_json）。

- 2026-11-19：test SR 已 `CREATE TABLE ... LIKE` 建 `dws_app_user_w_d_new_uc_paimon_shadow`。S4 真跑依赖 sql 进 `pipeline-runner/repo` 后 deploy + run-step。

- 2026-11-19：commit `39268d3d` 已推 origin/dev；sql/deploy test 成功。run-step 冒烟 dt=2026-11-05：周计算 rows_out=6614、周 pb shadow=6614；月计算=6693、月 pb=6693。注意 runner 日志任务日→数据段为 11-05→11-04，后续对平按实际写入周/月核对。

- 2026-11-19：test 多日补跑数据日 10-30~11-05（任务日=数据日+1）周/月计算+pb 全 PASS。rows_out 摘录：10-30 w/m=7096/7096；10-31=8632/8632；11-01 w=8698 m=524（月初）；11-02 w=1333 m=1535；11-03=5587/5691；11-04=6614/6693；11-05=8876/8950。

- 2026-11-20：影子 week 2026045=8876 与 paimon 一致；对正式非_uc 不硬并。套表报告见 spark_migrate/reports/recon_new_split__2026-11-18__20261120_105148.md

- 2026-11-20：周月人数对平 week45/month10·11 影子=湖仓（活跃/新增人数一致）。

- 2026-11-21（bus#14178）：自洽验法 PASS——week2026045 vs 日表 11-02～11-05、week2026044 vs 10-30～11-01，逐 app 活跃/新增人数全等。抽样未过：日表无满 7 天；JHA-124/DX-030/HX-001 对旧正式非个位数。
