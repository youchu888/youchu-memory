# ads_app_active_summary 会话备忘

## 2026-11-12
- 狂人 #13268：分工单 docs/migration_assignment_20261016.md 第 42 行写的归蓝猫（猫猫代办）。草稿停住不提交，等狂人和猫猫确认有没有人在做。
- 如果归我：①影子期读 paimon.dws.dws_app_channel_dau_d（11-09 起生产在跑）；10 月补跑完之前上月列对不平是预期内的，先只比上周列。②首版照抄「应用×渠道×天行求平均」，改不改由知秋定，改了出 v2。③paimon 主键表用 INSERT INTO 按 app_id upsert，不用 OVERWRITE，旧应用保留。

## 2026-11-14
- S4 第五步“从起点补数”报 400：测试调度 05 槽已跑完 11-13（297 行，影子回写成功），水位已到起点，不用补，直接标记完成。S5 四步 16:59 走完（面板在生产数据上写出 732 行）。
- 测试环境对账：影子 297 = Paimon 297；only_shadow 0、only_prod 126；上周不一致 84、上月 121。原因是测试两边渠道日活不同源（Paimon 10-16 起才有数；SR 缺 11-04，其余天人数也不同），不代表口径问题。数值对账以生产为准。
- 表名 / 粒度：outputs 登记 ads_app_active_summary + partition_grain=none，与 design 一致；会话顶层的 _d_d / day 是表单原始值，spec 第 0 节不可改，第 39 行已说明。

## 2026-11-17
- 面板再点「从起点补数」仍 400：水线已到 2026-11-16，daemon 会接着跑 11-17，不用 seed。计算步/回写步顶部已是成功（297 行）。用 MCP 把 stage4 标 done，并推进到 stage6（stage5 此前已 done）。
