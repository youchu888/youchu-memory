# 【渠道汇总】ads_channel_summary_d · 又初 — 会话备忘录

## 2026-10-16
- 新建 Spark 会话 dev-20261016-014。目录与现网海豚会话分开。
- 正式表仍由海豚写入。回写只进影子表。
- 不直接读事件，读三张日汇总。等上游 Spark 有数再写 SQL。

## 2026-10-20
- stage 3：`ads_channel_summary_d.sql` / paimon DDL / SR 影子 DDL / `pb_*.sql` / `step.json` 已写。
- test 实查：`paimon.dws.dws_app_channel_summary_d_d` 在 2026-10-19 约 13.2 万行；`dws_app_channel_retention_d_d` 同日 0 行；`dws_register_by_landing_page_d_d` 在 Paimon 尚未建表（跑数前需补迁移或改读路径）。
- 用户上下文提到的 `paimon.ads.ads_channel_metrics_daily_d` 与本表无关（本表上游是三张 DWS 汇总，非 metrics_daily）。

## 2026-10-20 stage4

- 挂 `g_ads_channel_summary_d@10`，补 `2026-10-19` → Paimon **3747** 行。
- 落地页上游表未建，ETL 用空源（landing_page_new_user_num=0）。
- SR 回写暂失败：catalog 列名 `date_key` vs Spark 分区 `dt` 不一致，待对齐后再 pb。

## 2026-11-12 bus#13228 A1
- 留存禁读作废 `dws_app_channel_retention_d(_d)`；改读 `paimon.dws.dws_app_retention_d_h`（注册日 DT-1/DT-7 → last_day/last7，渠道维 bm_count）。
- step 探针同步改留存表；落地页仍空源待上游。

## 2026-11-13 test A1
- SQL+探针切到 `dws_app_retention_d_h`；卸作废 `channel_retention`。
- 单跑 11-12 ETL `rows_out=1366`；pb 修 `dt→date_key` 后影子 1366 行。
- 与正式差：影子行/新增/留存均高于正式（落地页空源 + 留存源更换），交审前再 FULL JOIN 分类。
- FULL JOIN 报告：`validate__2026-11-12__test_a1_fulljoin.md`（equal291 / metric_diff257 / only_shadow818 / only_formal39）。

## 2026-11-16 A1 交审样本
- 补强 only_formal/only_shadow 合计与头样；metric_diff 头样见 validate__2026-11-12__test_a1_fulljoin.md。
- 交审选项：接受结算全量 vs 对齐旧海豚过滤。产编排仍交狂人；本会话不手改 prod。
