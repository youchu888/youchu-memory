# 【归因无候选】ads_register_attribution_no_candidate_reason_d_d · 又初 — 会话备忘录

## 2026-10-16
- 新建 Spark 会话 dev-20261016-007。目录与现网海豚会话分开。
- 正式表仍由海豚写入。回写只进影子表。
- 读注册、归因结果、落地页曝光、落地页点击。这些不在已知缺实时表清单里。

## 2026-10-19
- 计算、Paimon 建表、影子表建表、回写、step.json 已按现网口径写完。
- 调度新建线 attr_no_candidate，槽位 04。不进 day_close_all：00 槽峰值 107.7%。
- 测试集群 2026-10-18：注册实时表、落地页曝光有行；归因结果表按日期过滤是 0 行。对账要等结果表当天有数。
- 同一天测试集群 iOS 注册的 attribution_flag 全是 0，所以计算跑通但结果 0 行。生产同一天 iOS 且 flag=1 有 91637 行，过滤条件本身成立。

## 2026-11-13 test A7
- SQL 与现网编排已对齐；单跑 11-12：ETL `rows_out=1`，pb OK。
- 影子=正式：`YC-159` / `no_landing_same_ip` / register_cnt=6。
- 当日 test 归因结果表 0 行；入围 iOS 自然 6 人全进无候选（符合 playbook「结果空则成功数可为 0/仅无候选类」）。
- 交审样例报告：`.claude/database/reports/ads.ads_register_attribution_no_candidate_reason_d_d/validate__2026-11-12__test_a7.md`
