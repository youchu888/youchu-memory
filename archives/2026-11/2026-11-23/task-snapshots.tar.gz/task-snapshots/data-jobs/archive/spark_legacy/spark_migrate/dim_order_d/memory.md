# memory · dim_order_d（新分 B3）

- 2026-11-19：开 B3。海豚稿 `ops_system/06.dim/job_dim_order_type_d/`；迁 Spark 读 `_r` 按日 OVERWRITE。
- 探数：test SR 11-18=555；prod 同日≈9.8 万。test paimon 空表无 PK → 须 DROP 重建。`created_h_r`/`paid_d_r` test T-1 有数。
- 定稿：下单/支付同单 ROW_NUMBER 去重；金额 STRING 转 DECIMAL；pb 日分区影子。

- 2026-11-19：DDL 重建 + 日算 10-30~11-05、11-12~11-18 全 PASS（paimon）。T-1 影子/正式行数差：paimon 654 vs 正式 555（_r 口径，WARN）。pb 初版 dynamic_overwrite 整表盖掉，已改 DELETE+INSERT（967b28c3）；重刷过程中 test SR 一度连不上，分区列表待复检。

- 2026-11-20：影子分区复检 PASS，与 paimon 14 日逐行一致；对正式样本日 WARN（_r 口径偏多）。报告 ops_system/spark_migrate/reports/recon_new_split__2026-11-18__20261120_105148.md

- 2026-11-20：口径差说明已落盘；根因 _r vs 非_r。

- 2026-11-21：bus#14187 批准 event_time 归属 + request_time<T+1 03:00（读 T/T+1、trim 去重、槽≥03、写完不回写）。SQL/task/step/design/口径说明/STATUS 已改；上游预演 14 天 6228=6228、截断 832。表内待重刷。
- 2026-11-21：bus#14221 复审放行；832 截断抽 3 天小时分布确认偏 test 隔天灌数；生产影子验收项写入口径说明（日截断占比>1%回知秋）；test 14 天按新 SQL 补刷中。
- 2026-11-21：test 14 天补刷完成，表内日行=预演 14/14 EQ。
- 2026-11-21：bus#14227 新分5张 test 收口通过；prod 挂载/切读等平台升级后再排，期间不碰生产。
