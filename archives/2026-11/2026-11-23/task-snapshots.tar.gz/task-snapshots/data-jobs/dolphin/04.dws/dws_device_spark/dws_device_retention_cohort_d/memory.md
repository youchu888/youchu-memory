# memory · dev-20261116-001

## 2026-11-21 · 口径修订并重开会话

- 主人要求：`channel` 改取 `first_sdk_init_channel`；`channel_type` 改五类（搜索引擎用户 / 渠道用户 / 未知来源用户 / 直接访问用户 / 其它用户）。
- 表结构不删。旧两档行清掉，只留新口径。
- 已 `start-modify` 从 stage 1 重开。SQL / design / spec / DDL 注释已改。
- 测试 Paimon 与测试 SR 旧分区已按进队日清完（20 个分区），表还在，行数为 0。生产表未动。

## 2026-11-16 · 开会话

- bus#13583：狂人通过维度改动，生产表已建。DESCRIBE 15 列与附件 316 一致。
- 会话停在 stage 1。未挂调度，未补数，未回写 SR。

## 2026-11-16 · stage 2、3 过门禁

- 上游字段用生产 DESCRIBE 核对。元数据目录没有这两张表。
- 调度加入 `g_device_daily`，接在 `dws_device_dim_d_d` 后。槽 03 峰值 105.4%，余量 -193 秒。编排未挂。
- SQL lint 无错。9 个设备口径指标进了本会话 pending，不复用账号 `day1_ret_cnt`。
- 2026-11-16 15:53 主人确认挂组：`g_device_daily` 槽 03，接在 `dws_device_dim_d_d` 后。槽仍超预算。
- 2026-11-16 16:19 看板不显示：建会话时 `project_id` 是空的，看板按 `dmp/dc-parent` 过滤。已补上，会话能被列出来。
- 2026-11-16 17:25 已 bus#13607 请狂人带做测试阶段。附件 318 是作业 SQL。测试编排拟挂 `g_device_daily` 槽 03，接在 `dws_device_dim_d_d` 后。先跑一个已日结日，不整段补。生产调度不挂。

## 2026-11-16 · bus#13608 测试阶段

- 狂人通过作业 SQL，要求推代码、建测试集群 Paimon 表、挂测试编排、只跑一个已日结日。
- 已推 `ffd20f3e`。只含本会话目录。
- 测试集群 `paimon.dws.dws_device_retention_cohort_d` 已建。partial-update，主键与生产一致，含 `target-file-size=128mb`、`snapshot.time-retained=7 d`。查询口拒绝 SHOW CREATE。
- 测试编排挂在 `g_device_daily` 槽 03，排在 `pb_dws_device_dim_d_d` 后。生产编排没有这一步。未 seed。
- 数据日 2026-11-15 已跑。`rows_out=30889`。`new_device_cnt` 非空 3584，`day1_ret_cnt` 非空 1832。分区 2026-10-17 到 2026-11-15。数据留着。未整段补数。
- 2026-11-16 17:57 主人要求回写测试 SR。测试库 `paimon` catalog 能读到这 30889 行。已 `INSERT INTO dws.dws_device_retention_cohort_d`，affected 30889。没加回写调度步，生产 SR 没动。
- 2026-11-20 补跑数据日 2026-11-14（rows_out 28164）和 2026-11-16（rows_out 27611）。进队日 11-14、11-15 同一行同时有新增和次留。测试 SR 重刷 90499 行。生产没动。

## 2026-11-16 · stage 1 完成

- 新版指标库没有可复用的设备进队留存口径。命中项都是账号留存。
- 会话从 stage 1 推到 stage 2。

## 2026-11-16 · 测试 SR 建表

- 测试库 `dws.dws_device_retention_cohort_d` 已建。15 列，主键与生产 Paimon 相同。分区 2026-10-15 到 2026-11-30，副本数 1。
- 接口可以查。2026-10-15 行数 0。生产 Paimon 同一天也是 0 行，作业还没跑，所以没有数可补。
