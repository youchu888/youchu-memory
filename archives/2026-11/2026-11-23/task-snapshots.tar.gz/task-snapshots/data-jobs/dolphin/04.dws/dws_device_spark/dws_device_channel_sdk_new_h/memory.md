# memory · dev-20261110-003

## 开任务

- 2026-11-10 主人 IDE：「要啊」— 清掉 002 小时夹带，另开小时表独立 session
- 对照日表：`dev-20261110-002`（已放下；S4 ①②④ OK，③⑤ HOLD）
- 口径真源：桌面德贵需求设计 v2.2 / 字典 v1.2 / 表结构 v1.2
- 狂人 #13069 full PASS（业务口径）；本 session 走平台 1→7

## 一表一任务

- outputs 仅 `dws_device_channel_sdk_new_h`
- 步骤：小时 ETL + pb_ + close + close-pb_（同表多步，非多表）

## Stage 进展

- Stage1 done：需求/字典对齐；上游 DESCRIBE 已核
- Stage2 done：设计（小时线 / close / 调度）
- Stage3 done（2026-11-10）：lint 0/0；render OK；指标 `new_device_cnt_sdk_channel_h` pending
  - 门禁：join `g_device_hourly` 因缺 snap/code_h 钩子失败 → design 首块改为新建线 `g_channel_sdk_new_h` + 四源 watermark 钩子后通过
- Stage4 in_progress：spark 面板五步待点；正式挂组仍等 SR + 狂人放行
