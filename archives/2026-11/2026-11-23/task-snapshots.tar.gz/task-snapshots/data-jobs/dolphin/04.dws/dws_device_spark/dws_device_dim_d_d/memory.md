# memory · dev-20261108-001

## 2026-11-19 · 主人定：产建表/产挂留给 S7

- 生产 SR 建表、产编排挂 pb_ **不在 S6 做**，发布向导时搞
- S6 清单 5/6/7 按此口径改为「语句已备 + 测侧已通」即过
- 不代勾 S6

## 2026-11-18 · Stage6 取证（主人：做到第六阶段）

- Stage5 标 **done**（核数沿用 11-10：168615 全等、无偏差）
- Stage6 **in_progress**：11 项清单已实检写入 playbook
- 产 SR 仍无表；产编排仍无 `pb_`；测组有 compute+pb
- 指标重 propose+bind 进 metric_pending（545/546）；正式 bindings 仍空，待面板审
- 本地 memory/playbook 有未提交改动；分支 behind origin/dev 42
- **不**代勾 S6；不进 S7

## 2026-11-11 · bus#13134 问狂人：产 SR 可否先建

- 发 `worker_ant`：进度 + 缺口 + 问是否可先建产 SR、是否违规、怎么走
- 附 DDL asset#303；等回

## 2026-11-11 · Stage6 取证（未勾）

- 产 SR：**无表**；产组有 dim、无 pb_
- 测组：dim+pb 已挂；SR DDL 已备
- **不**代勾 S6；建产 SR 后才能 S7 挂 pb_

## 2026-11-11 · Stage5 验证（待主人确认）

- 数据日 11-10；explain OK；verify run `9420580e` SUCCESS · rows_out=**168615**
- test.dws 与产 Paimon：行/active/new/空渠道/Top5 **全等**；PK 重复 0
- Stage5=in_progress；**未**代勾 done

## 2026-11-11 · Stage4 五步完成（IDE 代跑 · commit `5b7a4fef`）

- ① deploy test OK（ETL/DDL/pb）
- ② tables/apply：paimon OK；sr `unchanged`
- ③ 测编排：`g_device_daily@03` 升级 compute；**新挂** `pb_dws_device_dim_d_d`
- ④ run-step 数据日 11-10：compute `rows_out=837` SUCCESS；pb SUCCESS；已 clear
- ⑤ 补 11-06～11-10 共 5 天 OK（11-08 曾因 SR 读 paimon manifest 失败，重写分区后 pb 通过）
- `stage4_spark` / `stage4_db_check` 已写；Stage4=done；Stage5 pending
- 测环境 SR 外挂 catalog 仍可能偶发 manifest / 可见不全；S5 对账走 prod verify，不以测 pb 行数为准

## 2026-11-11 · Stage4 Part A（旧）

- sr_test CREATE IF NOT EXISTS OK；表原已在
- test.dws 11-08：171091 / 空渠道 0
- pb_ 写 sr_test 11-10：837 行；产 Paimon 同日 168615
- 根因：sr_test 外挂 `paimon.dws` COUNT 也是 837 → catalog 可见不全，非 SQL 少写

## 2026-11-11 · Stage3

- lint OK；`dim_active_device_cnt`/`dim_new_device_cnt` propose+bind；full_chain 备 pb_ 步定义

## 2026-11-11 · start-modify v3

- task_version 2→3；from_stage=1
