# memory · dwd_app_page_view_d

- P0：5 新字段；`page_enter_ts` 是 Unix **秒**；viewport `-1`→NULL；不补历史
- 日+时两份 ETL 都要改
- 平台职责止于 request-publish
- 姊妹 session：`dev-20260727-page-click-001`（已 RP）
- 2026-11-20 bus#14092：`page_url` 超 6144 字节整批被过滤。小时任务生产已热修，仓库 `316bce8f`。会话 `dev-20260623-002` 从 stage 1 重开为 v2，日任务补上同一截断。不补历史。生产发布只申请，不自行改产。
