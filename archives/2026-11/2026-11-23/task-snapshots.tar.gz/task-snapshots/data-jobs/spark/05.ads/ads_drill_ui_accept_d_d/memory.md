# 【界面验收】按区域层级统计地区数 — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 但又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-11-19
- 会话 dev-20261119-005 创建
- [stage1 用户确认] 目标库用 ads（`ads.ads_drill_ui_accept_d_d`），不用原话里的 drill 库
- [stage1 用户确认] 代码保存目录用 data-jobs/spark/05.ads，不用原话里的 ops_system/drill
- [stage1 用户确认] region_level 为 NULL 的行剔除，不单独成组
- [stage1 发现] 上游 dim.dim_region_info_all 无分区键，region_level TINYINT 可空（1国家/2省/3市）；元数据登记的是 SR 测试库版本，Paimon 端结构 stage 2 需核实
- [stage2 发现] Paimon 版 dim_region_info_all：region_level 0=未知(1行, region=99999999) / 1=240 / 2=2814 / 3=82891，无 NULL；2026-09-22 一次性导入后无新提交（静态表），调度器无步产出它
- [stage2 用户确认] region_level = 0（未知）也剔除；每天 3 行
- [stage2 设计] 新建单步线 g_ads_drill_ui_accept_d_d，timer 触发无钩子，07 槽，run_mode=partition
- [stage2 发现] runner.get_scheduling_context / get_pipeline_config 返回 404（平台未收到 full_chain 快照），调度判定改读仓库 pipeline-runner/steps/full_chain.json
- [stage2 卡点] 平台门禁拒 stage 2 done：「新建线必须给入口配放行钩子」。查 runner Probe.scala：watermark 要表级 max(last_update_time) ≥ 数据日次日 00:00，partition 要 dt=数据日 分区有数据 —— 静态无分区表两种都永不放行
- [stage2 用户决策·已推翻] 曾选「放宽平台门禁」，随后用户改为：不改门禁，直接往下走
- [stage3 状态] 门禁未改，stage 2 无法标 done、advance_to_stage(3) 被拒；session 仍停在 stage 2，stage 3 产物已写入会话目录但阶段状态未推进
- [stage3 产物] paimon 建表单独文件 ads_drill_ui_accept_d_d_paimon_ddl.sql（etl_files[0]）；计算脚本 ads_drill_ui_accept_d_d.sql（etl_files[1]，无建表语句）；ddl_file 无 SR 表，内容同 paimon 建表作基线；step.json 单步 timer、无 probes、tagTargets 指本表
- [stage3 验证] 测试 paimon 实跑 SELECT：1→240 / 2→2814 / 3→82891，与 stage2 分布一致
- [stage2 用户决策·推翻前述「照此往下走」] 不改门禁，也不在门禁被拒后继续往下走；改设计：上游换成 paimon.drill.drill_region_sample_d（按 dt 分区），加入已有线 g_drill_daily（mode=join，接在 drill_region_sample_d 之后，无 hooks），按 dt 统计各 region_level 地区数。上面「新建线 g_ads_drill_ui_accept_d_d / 07 槽 / 静态维表」相关条目作废
- [stage2 发现] 平台调度快照已恢复：g_drill_daily 步序 drill_seed_d → drill_seed_summary_d → drill_region_sample_d，09 槽，入口无钩子；drill_region_sample_d 的 tagTargets = paimon.drill.drill_region_sample_d；runner_lineage 里暂无该表（演练控制面），以 full_chain 为准
- [stage2 发现] drill_region_sample_d.region_level 是 INT（非 TINYINT），目标表 region_level 同步改 INT；测试 paimon 当前只有 dt=2026-11-17 一个分区（level 1 共 20 行，region 不重复）
- [stage2 验证] 新 SQL 的 SELECT 在测试 paimon 实跑 dt=2026-11-17：1→20
- [stage2 状态] 改设计后 stage 2 标 done 成功（门禁放行），已推进 stage 3
- [stage3 已处理] step.json 的 sqlFile 改为 /home/ec2-user/pipeline-runner-drill/repo/spark/05.ads/ads_drill_ui_accept_d_d/ads_drill_ui_accept_d_d.sql，与 g_drill_daily 其他步同在 drill 控制面仓库；元数据平台无 drill.drill_region_sample_d，无清洗规则可套，以 paimon DESCRIBE 为准
- [stage3 卡点] 标 S3 done 被 spark 调度门禁拒：「paimon.drill.drill_region_sample_d 现网血缘里没有这张表」。查明平台两份快照来源不一致：full_chain 快照是 drill 控制面编排（含 g_drill_daily），runner_lineage 快照却是生产 runner 的 /home/ec2-user/pipeline-runner/steps/full_chain.json 生成（207 步，无任何 drill 步）。设计无误，需 drill_admin 用 drill 控制面编排重推 runner_lineage 后重试；按用户要求不改门禁、不绕过
