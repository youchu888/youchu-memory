# 【关键词分析】ads_keyword_analysis_d_h — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-10-26
- 会话 dev-20261026-001 创建。只建需求，不停在第 1 步。
- 正式表 ads.ads_keyword_analysis_d_h 和盘中小时任务仍由海豚写。Spark 日终写 Paimon，再回写影子表。
- 检索必须读 paimon.dwd.dwd_keyword_search_d_r。小时检索实时 dwd_keyword_search_h 在 2026-09-14 已停。
- 点击读 paimon.dwd.dwd_keyword_click_d_r。用户类型读 paimon.dim.dim_user_all_d_v，不对快照，这张视图不做水位探针。
- 不补历史。数据起点等上线前再定。
- 建需求时核对：2026-10-25 检索日实时 142594042 行，点击日实时 111026659 行。
- 2026-10-26 走流程：新建线 g_ads_keyword_analysis_d_d，12 槽。只探两张日实时表。用户视图不探针。
- keyword_hash 在回写步用 bitmap_hash64_udf 生成。Paimon 主键是关键词原文。
- 影子表分区从 2026-10-25 起。表单数据起点仍空着，等上线前再定。

## 2026-10-27
- 第 3 步收口：影子表动态分区往前建 7 天。产出文件顺序定为 Paimon 建表、计算、回写。
- 回写步保留按 keyword_hash 聚合。同一个 hash 撞上两个原文时次数相加、bitmap 再并、关键词取 MAX。这是为了对齐正式表主键，不是普通整行回写。

## 2026-10-28
- 产出顺序已改成 Paimon 建表、计算、回写。检查 0 错误。
- 11 个指标已绑定。点击次数复用已有标准名，其余 10 个待审。绑定号 467 到 477。
- 改挂 02 槽。近 7 天最忙一天 02 占用 33%，12 是 23%，两边有余量，02 早出 10 小时。不选 01：两张关键词 dwd 是实时表，晚一个小时前一天更齐。06、10、11 已超时。
- 用户视图的 watermark 探针删掉。视图取不到水位，挂上会一直卡住。它在 00 槽产出，02 槽读的时候已经就绪。两张 dwd 探针保留。
- Paimon 补 keyword_hash BIGINT，位置在 user_type 后、keyword 前。主键改为 dt、app_id、user_type、keyword_hash。计算用 xxhash64(keyword)。回写影子表仍用 bitmap_hash64_udf，和正式表主键对齐。
- 2026-10-27 影子表对正式表：检索多 2,101,689，是日实时表把同一个 event_id 写了多行，SR 小时表按小时只留一行。117,176 个关键词检索合计相同，其中 703,721 次换了 user_type。按差额为 0，不能切正式表。记录在 playbook.md。
- 狂人 #11682：检索改为按 event_id 留最早一条。点击源 10-27 有 77,884,999 行、76,356,457 个 event_id，同样去重。user_type 以视图为准，hash 合并保持 bitmap_hash64_udf。重跑和对 bitmap 之前不切正式表。生产任务还是旧 SQL。
