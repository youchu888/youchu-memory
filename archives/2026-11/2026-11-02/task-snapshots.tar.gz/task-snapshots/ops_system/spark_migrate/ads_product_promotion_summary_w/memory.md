# memory

## 2026-10-20
- 对齐 Paimon 现网：渠道维 `dim_channel_info_all_snap`；推广日表 `ads_channel_promotion_summary_d_d`（date_key）；活跃 `bm_count(ads_app_metrics_daily_d.dau_ids)`（test 表空则 0）
- step 去掉 SR 影子回写；先只写 Paimon
- 部门/产品 Spark ETL 已落盘；依赖 `ads_channel_metrics_daily_d`（test Paimon 暂空）


## 2026-10-21

- 部门改为渠道 snap 的 dept_id / dept_name；不再写 dept_code。

## 2026-10-21

- 部门：sr_dim_channel + INNER JOIN，禁止空 dept_id / dept_id=-1。

## 2026-10-22

- 与海豚同口径：渠道周/月 LEFT JOIN 渠道维（部门可空）；产品周代表部门可空；已去 `dept_code`。

## 2026-10-22

- 管理报表只保留部门周/月与产品周；渠道周/月表与海豚任务已下线。
- 部门主键：时间 × channel × dept_id；产品主键：时间 × dept_id × app_id。

## 2026-10-22 Spark 切轨

- 不发 prod 海豚；三份海豚 request-publish 已撤回。
- test 海豚三 task 已停（flag=NO）。
- Spark session：`dev-20261022-001/002/003`；`pb_*` 回写 SR 正式表；testcluster 组已挂回写步，渠道周月组已从槽位卸下。

## 2026-10-23 srViews bug

- 根因：testcluster 已挂 compute 步无 `srViews`，daemon/`run-step` 报 `sr_dim_channel` 不存在。
- 修复：ETL `channel_dept` 改 `paimon.dim.dim_channel_info_all_snap WHERE snap_dt=${DT}`；`step.json` 去掉 `srViews`，probe 加 snap 水位。
- 影响：dev-20261022-001/002/003；产发前 push 本修复。prod snap 仍空（与 prod SR 渠道维空同源），需 snap 任务先有数。

## 2026-11-02

- 产品周加推广窗：`promote_start_date ≤ dt ≤ promote_end_date`（end 空=长期）；不看 status。与部门周同口径；对接只读产品周/月。
- test 海豚已发并补数：周 pi `89833` PASS（`week_start=2026-10-26` rows=13）。
