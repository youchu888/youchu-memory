# 关键词检索小时分布 — 会话备忘录

## 2026-10-20
- 会话 dev-20261020-003。老板定先迁这张。
- 现网日批、小时批都 JOIN `dim.dim_user_all`，不是 `dim_user_snap`。
- `paimon.dwd.dwd_keyword_search_h_r` 最后分区 2026-09-14 23 点，停更。改读仍在出数的 `paimon.dwd.dwd_keyword_search_d_r`，小时用 `HOUR(event_time)`，对齐现网 `date_trunc(event_time)`。
- 先做日终（昨天分区）对影子表。小时批继续写今天的正式分区，先不停。不补历史。
- 2026-10-20 晚上老板改了原始需求：用户类型改读视图 `paimon.dim.dim_user_all_d_v`（指向数据日那一版快照，和视频分析日终是同一份）。目标表名改为 `ads_keyword_search_hour_d_d`。空和关联不上仍为 unknown，不改大小写。正式表 2026-10-19 实测 user_type 为 NORMAL / VIP / unknown。

## 2026-10-22
- v3 重开。影子合计 103,423,804，正式表 101,021,108。Paimon 源表同一 event_id 有重复行。10-21 去重后 100,912,821，与 SR 源表去重后相同。正式表多出的 108,287 是 SR 源表自己的重复行。
- 计算改为先 `ROW_NUMBER() OVER (PARTITION BY event_id ORDER BY event_time)` 取第 1 条，再计数。用户维表不改。
- 老板接受 2026-10-21 验证结果：合计差 108,287 可以。用户类型拆分和正式表不一致，是数据日快照对跑批当时用户维，不改代码。
