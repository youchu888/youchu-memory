# 【漫画分析】ads_comic_analysis_account_d — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-10-24
- 会话 dev-20261024-001 创建。老板要迁 ads_comic_analysis_account_d，先建需求。
- 口径照抄现网天任务。正式表仍由海豚写，先回写影子表。不补历史，数据起点等上线前再定。
- 用户维读 paimon.dim.dim_user_all_d_v，不用快照表。对不上 channel 写 organic，country / device / user_type 写 unknown。
- 2026-10-22 到 2026-10-24 上游已有数。事件约 8516 万、1.00 亿、9376 万。点赞 31 万、41 万、33 万。收藏 73 万、94 万、78 万。评论 3956、4507、3268。购买 5997、7032、7563。

## 2026-10-26
- 老板要从第 1 阶段走到第 4 阶段再汇报。不发布、不补数、不切正式表、不选生产槽位。
- 详情面板已把 data_start_date 改成 2026-10-25。第 0 节原文仍写数据起点等上线前再定。以表单 2026-10-25 为准，不补这一天之前。
- 渠道照抄现网：读 dim_user_all_d_v.register_channel，对不上写 organic。不用视图里的纠正后 channel，也不读快照表。生产 DESCRIBE 已确认视图同时有 channel 和 register_channel。
- 事件表 page_no、read_progress、dt 都是字符串。计算时再转数值。
- 老板要求去掉 dim.dim_user_all_d_v 的水位探针。视图取不到水位。金币消耗任务配了它，从 2026-10-22 起每天被判未就绪。用户维由 00 槽产出，09 槽读取时已经就绪。计算 SQL 仍读这张视图，只是不探针。
