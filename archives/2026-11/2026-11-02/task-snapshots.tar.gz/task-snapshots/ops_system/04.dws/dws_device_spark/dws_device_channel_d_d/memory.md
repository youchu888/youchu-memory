# 设备渠道日表

## 2026-10-30

- 开 `dev-20261030-003`。新表 `dws.dws_device_channel_d_d`。
- 旧表 `dws.dws_app_device_channel_d_d` 在测试上 2026-10-15 已有 2712 行，不改不删。
- 生产不建。不回写 StarRocks。
