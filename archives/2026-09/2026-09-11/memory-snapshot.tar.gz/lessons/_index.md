# Lessons 索引

| 日期 | 标题 | tags | 一句话 |
|------|------|------|--------|
| 2026-09-11 | [拍板逐条展开禁止一句话甩选项](./2026-09-11-拍板逐条展开禁止一句话甩选项.md) | 沟通,拍板 | 需拍板时每条展开利弊与含义，禁止一句话多问 |
| 2026-09-10 | [主人贴定稿并说「上传云端」时，正文一字不改落盘再提交；同日上传为覆盖更新](./2026-09-10-主人贴定稿并说-上传云端-时-正文一字不改落盘再提交-同日上传为覆盖更新.md) | 日报,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-10 | [prod 主键变更/重建表前，先确认补回责任方与天数，并核实下游已切读；未切读则](./2026-09-10-prod-主键变更-重建表前-先确认补回责任方与天数-并核实下游已切读-未切读则重建前必须错峰协.md) | 大漏斗,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-10 | [commit 说明冒号后必须汉字](./2026-09-10-commit-message-must-be-chinese.md) | git, commit-message, chinese | 可 feat(scope): 前缀，正文中文；钩子拦无汉字 |
| 2026-09-10 | [闲时沉淀当日实活；用时只快速检索，禁止临时重翻半仓](./2026-09-10-idle-crystallize-retrieve-fast-no-archaeology-on-demand.md) | daily-report, work-log, lessons, agent-speed | 收尾写 work-log/lesson；催改日报只检索+贴正文，禁考古 |
| 2026-09-09 | [主人贴定稿说「上传云端」：本地落盘与 API 提交均不得改字](./2026-09-09-主人贴定稿说-上传云端-本地落盘与-api-提交均不得改字.md) | daily-report,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-09 | [注册人数业务日=事件时间归属；读 T/T+1 两分区，入仓时间卡次日 03:00](./2026-09-09-注册人数业务日-事件时间归属-读-t-t-1-两分区-入仓时间卡次日-03-00-截止.md) | 口径,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-09 | [新增账号活跃少算：先对用户维注册时间做覆盖核查，确认是日批缺口再查命名/字段](./2026-09-09-新增账号活跃少算-先对用户维注册时间做覆盖核查-确认是日批缺口再查命名-字段.md) | datacheck,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-08 | [用户贴定稿说「上传云端」时正文零改写，先落 `.cursor/work-log/](./2026-09-08-用户贴定稿说-上传云端-时正文零改写-先落-cursor-work-log-reports-日报.md) | daily-report,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-08 | [resume 失败时除提示重发/重启 agent，业务问句（打卡等）恢复后须续答](./2026-09-08-resume-失败时除提示重发-重启-agent-业务问句-打卡等-恢复后须续答原意-禁止只留连.md) | tg-cursor,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-08 | [海豚停跑占位禁纯 SELECT 1](./2026-09-08-dolphin-stop-placeholder-must-be-nonquery-not-select1.md) | dolphin,stop-placeholder,sqlType | SELECT×NON_QUERY 整 wf 挂；用 0 行 INSERT |
| 2026-09-07 | [定时 TG 推送可能早于定稿；推送内容与明日动作须与主人最终稿对齐，初稿与定稿不](./2026-09-07-定时-tg-推送可能早于定稿-推送内容与明日动作须与主人最终稿对齐-初稿与定稿不一致按定稿为准.md) | daily-report,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-07 | [TG 已推错误初稿时，以主人改定稿覆盖本地与云端，再 `post_daily_r](./2026-09-07-tg-已推错误初稿时-以主人改定稿覆盖本地与云端-再-post_daily_report_to_.md) | daily-report,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-07 | [写日报前须双机 sync 后合并 work-log + 全量 transcrip](./2026-09-07-写日报前须双机-sync-后合并-work-log-全量-transcript-派单来源-wor.md) | daily-report,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-07 | [概念详情须展开 label+impl+SVG图](./2026-09-07-metric-concept-ui-expand-detail.md) | metric-library,ui | bus#8082 知秋打回 |
| 2026-09-07 | [A灌包 entity/role 全撞 PK 只 skip](./2026-09-07-metric-library-A-entity-role-skip-on-pk.md) | metric-library,prod-sync,entity_dict | bus#8066 |
| 2026-09-07 | [metric_kind=constant；G4 豁免 impl](./2026-09-07-metric-kind-constant-g4-skip-impl.md) | metric-library,G4,constant | bus#8060 window_days helper |
| 2026-09-06 | [同日重复上传云端是 updated 覆盖同一条记录，inserted→updat](./2026-09-06-同日重复上传云端是-updated-覆盖同一条记录-inserted-updated-属正常-勿.md) | daily-report,upload,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-06 | [用户说「失败」先查 upload 日志与云端 record ID；TG 会话红状](./2026-09-06-用户说-失败-先查-upload-日志与云端-record-id-tg-会话红状态-上传-api.md) | daily-report,upload,tg,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-05 | [TG/bus 长消息禁止砍尾，必须分片续发](./2026-09-05-tg-bus-长消息禁止砍尾须分片续发.md) | tg,agent-bus,messaging,truncation | 禁止 [:4096]/[:3500]；分片+--text-file |
| 2026-09-05 | [群收不到工作簿就不要闹钟发群：等 bus 入站后再按实查 reply](./2026-09-05-workbook-no-group-alarm-reply-on-bus.md) | workbook,agent-bus,progress | 主人钦定：无入站不发群 |
| 2026-09-05 | [工作簿 09:01 兜底仍像秒回：写死 1/2 条 + 正文印「禁止秒回模板」](./2026-09-05-workbook-daily-fallback-still-looks-instant.md) | workbook,progress,instant-ack | 主人感觉仍秒回 |
| 2026-09-05 | [指标库 Phase1：other 批已落地，剩余主卡 diverged](./2026-09-05-metric-library-phase1-other-done-diverged-hold-next.md) | metric-library,phase1,diverged | other 已 apply；published 203；勿信过期 OPEN |
| 2026-09-05 | [upload|上传云端必须以定稿 Markdown 原封不动上传；定稿缺失时先同](./2026-09-05-upload-上传云端必须以定稿-markdown-原封不动上传-定稿缺失时先同步双机写稿-禁止.md) | daily-report,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-05 | [resume|agent-bus|用户只说「日报呢」时先澄清是要查定稿/TG、生](./2026-09-05-resume-agent-bus-用户只说-日报呢-时先澄清是要查定稿-tg-生成日报还是上传云.md) | daily-report,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-04 | [test 验收须全 app 空 filter 跑完 stage_metrics→](./2026-09-04-test-验收须全-app-空-filter-跑完-stage_metrics-stage_wi.md) | funnel,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-04 | [狂人侧消息常被压缩截断，reply 须贴回 #7900 等待审原文一字不动并写明](./2026-09-04-狂人侧消息常被压缩截断-reply-须贴回-7900-等待审原文一字不动并写明-commit-t.md) | agent-bus,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-04 | [explain PASS 后同一轮会话内立刻接 metric→wide 真跑，开](./2026-09-04-explain-pass-后同一轮会话内立刻接-metric-wide-真跑-开跑前确认源表-t.md) | funnel,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-04 | [ACK 被 silent 丢时用 --no-dedup 重发，以 reply 成](./2026-09-04-ack-被-silent-丢时用-no-dedup-重发-以-reply-成功为结案依据.md) | agent-bus,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-04 | [_r 表齐后仍须对齐 #7880 选表规则再改 SQL；主人拍板可自行推进，改完](./2026-09-04-_r-表齐后仍须对齐-7880-选表规则再改-sql-主人拍板可自行推进-改完-push-bus.md) | 大漏斗,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-04 | [摘 new 改 stage_metrics 时 _h_r 天计次固定 COUNT](./2026-09-04-摘-new-改-stage_metrics-时-_h_r-天计次固定-count-distinc.md) | 大漏斗,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-04 | [主人问「日报怎么不发了」须先拆 TG 推送与云端上传两条线，再决定查 old-m](./2026-09-04-主人问-日报怎么不发了-须先拆-tg-推送与云端上传两条线-再决定查-old-mac-定时链路还.md) | daily-report,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-03 | [狂人 bus 清单问进度：清单主责 + 自开实责，统一查「截至汇报前」，禁止秒回](./2026-09-03-workbook-progress-list-plus-owned-no-instant-ack.md) | workbook,agent-bus,progress,cutoff | 主人当面定口径 |
| 2026-09-03 | [日报云端上传须主人指令触发；定稿原样传，追问时用记录 ID 复核而非重传](./2026-09-03-日报云端上传须主人指令触发-定稿原样传-追问时用记录-id-复核而非重传.md) | daily-report-cloud,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-03 | [沙箱 explain 必须用 run_test.sh，禁止 run_step_o](./2026-09-03-沙箱-explain-必须用-run_test-sh-禁止-run_step_once-sh.md) | sandbox-explain,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-03 | [换 VPN 后会话 resume 易断，连接失败时让用户「重启 agent」并接](./2026-09-03-换-vpn-后会话-resume-易断-连接失败时让用户-重启-agent-并接上上一轮任务续做.md) | cursor-vpn,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-03 | [OneHR 设备页账号往返刷新（又初↔Ethan）](./2026-09-03-OneHR设备页账号往返刷新.md) | onehr, punch, screenshot, refresh | Window菜单AX切账号强制刷新设备列表 |
| 2026-09-02 | [DB 连不上先验 VPN/网络，勿先断密码过期](./2026-09-02-db-connect-fail-vpn-before-blame-password.md) | my.cnf,vpn,starrocks,network | 1045≠密码过期；对照平台 API cred+VPN 稳定后复测 |
| 2026-09-02 | [任务要自主往下推；卡点用 TG 私聊问主人，勿等主人追问](./2026-09-02-任务要自主往下推-卡点用-tg-私聊问主人-勿等主人追问.md) | autonomy,tg-dm,agent-bus,workflow | 审回执/下一步直接干；卡点私聊+ bus 要材料 |
| 2026-09-02 | [定稿推 TG ≠ 已上传云端；核对须分开查 dm_posted 与 upload](./2026-09-02-定稿推-tg-已上传云端-核对须分开查-dm_posted-与-upload-脚本执行记录.md) | daily-report,cloud-upload,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-01 | [OneHR 设备页必须设置侧栏非聊天 overlay](./2026-09-01-OneHR设备页必须设置侧栏非聊天overlay.md) | onehr, punch, screenshot | privacy往返致左聊天右设备；改 settings→devices + 侧栏 OCR |
| 2026-09-01 | [指纹/uid_map 本地改完须 push 并请知秋再审 PASS 后才可沙箱四](./2026-09-01-指纹-uid_map-本地改完须-push-并请知秋再审-pass-后才可沙箱四步-未-pass.md) | fingerprint,uid-map,HOLD,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-01 | [主人要任务进度时用人话逐项写节点/卡点/需确认项，并实查 task 板+work](./2026-09-01-主人要任务进度时用人话逐项写节点-卡点-需确认项-并实查-task-板-work-log-git.md) | progress-report,agent-bus,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-01 | [09:01 群进展/工作簿只写 T-1 截止累计进度；当天实活写 work-lo](./2026-09-01-09-01-群进展-工作簿只写-t-1-截止累计进度-当天实活写-work-log-次日工作簿再.md) | daily-report,workbook,work-log,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-01 | [task 板与 work-log 超过 1 天未对齐即执行缺口，先刷新 task](./2026-09-01-task-板与-work-log-超过-1-天未对齐即执行缺口-先刷新-task-板再答进展问.md) | workbook,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-01 | [workbook_progress_service 增补项必须读 workboo](./2026-09-01-workbook_progress_service-增补项必须读-workbook_supple.md) | workbook,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-01 | [读到群簿或有大活交付后，当天同步 task 板 + supplemental +](./2026-09-01-读到群簿或有大活交付后-当天同步-task-板-supplemental-work-log-大活.md) | workbook,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-01 | [req_ref|phase1-migration|Phase1 存量指标无 PR](./2026-09-01-req_ref-phase1-migration-phase1-存量指标无-prd-挂点时-用-.md) | metric-library,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-01 | [device-fingerprint|_r-retention|四路 `_r` ](./2026-09-01-device-fingerprint-_r-retention-四路-_r-保留期不一致时-禁止.md) | uid_map,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-01 | [agent-bus-review|wait-state|任务已交审或进入等 PA](./2026-09-01-agent-bus-review-wait-state-任务已交审或进入等-pass-状态时-立.md) | tg-progress,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-01 | [设备标签/uid_map 主键用 device_fingerprint，无指纹丢](./2026-09-01-设备标签-uid_map-主键用-device_fingerprint-无指纹丢弃-改造顺序-u.md) | device-fingerprint,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-01 | [Spark 新任务只写 SQL+steps.json 挂槽不改 Scala；源 ](./2026-09-01-spark-新任务只写-sql-steps-json-挂槽不改-scala-源-_r-cast-.md) | spark-steps,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-01 | [告警驱动处置：prod 告警→验还在→找失败 SQL→download-log；](./2026-09-01-告警驱动处置-prod-告警-验还在-找失败-sql-download-log-确认事故可立刻修.md) | prod-monitor,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-01 | [加 Spark 任务只改 SQL + steps.json 挂槽位，tagTar](./2026-09-01-加-spark-任务只改-sql-steps-json-挂槽位-tagtargets-必填-先-.md) | spark-scheduler,pipeline-runner,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-01 | [判为 prod 事故后可直接改代码并立即修复，处理完再报；非事故 prod 变更](./2026-09-01-判为-prod-事故后可直接改代码并立即修复-处理完再报-非事故-prod-变更仍须等知秋-go.md) | prod-incident,authorization,session-rotate | 会话轮换前自动蒸馏 |
| 2026-09-01 | [prod 告警处置顺序：先分 env → 问此刻是否仍在发生（DS state=](./2026-09-01-prod-告警处置顺序-先分-env-问此刻是否仍在发生-ds-state-1-不信-monit.md) | prod-monitor,oncall,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-31 | [TG 问狂人超时勿标「狂人回复」](./2026-08-31-tg-ask-outcome-title-not-kuangren-reply.md) | tgbot, worker_ant, ux | ask_outcome_title；memory patch apply_tgbot_ask_outcome_title.sh |
| 2026-08-31 | [server_monitor 告警处置 SOP bus#7708](./2026-08-31-server-monitor-incident-sop-bus7708.md) | server_monitor, dolphin, incident, download-log | old-mac 专责；先验仍在发生；禁信根因；DEPENDENT是果；playbook_server_monitor_incident.md |
| 2026-08-31 | [OneHR 打卡禁止上传过期截图；窗口定位不走 System Events](./2026-08-31-OneHR打卡禁止上传过期截图.md) | onehr, punch, screenshot, launchd | launchd System Events 超时后误传 08-28 旧图；只收 180s 内新截；CG helper |
| 2026-08-31 | [OneHR 打卡截图必须是设备管理页；拒绝壁纸/风景图](./2026-08-31-OneHR打卡截图必须是设备管理页.md) | onehr, punch, screenshot, validate | deeplink未切页截到壁纸；Vision校验+禁capture-only重试 |
| 2026-08-31 | [工作簿也要镜像到私聊（原文 + 发群进展）](./2026-08-31-工作簿也要镜像到私聊.md) | tgbot, workbook, dm-mirror, status_mirror | 工作簿不要求 @又初也进私聊；原文+发群进展各一份；inbound_dm 同日一次 |
| 2026-08-29 | [derived 比率指标：`default_aggregation` 留空，用分](./2026-08-29-derived-比率指标-default_aggregation-留空-用分子-分母-fk-表达.md) | 指标库G2,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-29 | [拍板/清库类任务主人说「不等点头」时：先执行落库，再 bus reply 对齐复](./2026-08-29-拍板-清库类任务主人说-不等点头-时-先执行落库-再-bus-reply-对齐复核-禁止空等事前.md) | agent-bus协作,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-29 | [打卡：不到点不打；打完再 TG 私聊通知](./2026-08-29-打卡通知-不到点不打-打完再TG私聊.md) | onehr,punch,notify | 私聊#423：禁提前打卡，成功/失败才通知 |
| 2026-08-29 | [derived 比率指标禁止 `default_aggregation=rati](./2026-08-29-derived-比率指标禁止-default_aggregation-ratio-按-v0-3-.md) | metric-library,derived,ratio,whitelist,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-29 | [G5「库内违规=0」≠ 应用层已落地；复验须分开报库内数据与 service/r](./2026-08-29-g5-库内违规-0-应用层已落地-复验须分开报库内数据与-service-router-是否做-.md) | metric-library,G5,application-layer,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-27 | [日报只写当天真实完成与真实进度；禁止硬凑、禁止跟别人回执写卡点](./2026-08-27-日报只写当天真实完成与真实进度禁止硬凑与跟别人回执.md) | daily-report, authenticity | 主人纠正：禁硬凑；以交办与交付为准，不跟别人回执写结果 |
| 2026-08-27 | [脏数据任务先 COUNT + COUNT(DISTINCT event_id) ](./2026-08-27-脏数据任务先-count-count-distinct-event_id-验重复-再导明细-配合.md) | dirty_data,datacheck,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-27 | [查 `dwd_standard_dirty_data_df` 前先对元数据，禁用](./2026-08-27-查-dwd_standard_dirty_data_df-前先对元数据-禁用臆测列-如无-cre.md) | paimon,dirty_data,sql,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-26 | [TG 先报有数后报 0 行：Agent 看 prod、SQL 队列连 test](./2026-08-26-tg-sql-queue-test-vs-agent-prod.md) | tgbot, sql-queue, my.cnf | Agent/MCP 连 prod，query_queue 用 test my.cnf → 前后矛盾 |
| 2026-08-26 | [TG SQL 答完禁止再发「这个回答合适吗？」](./2026-08-26-tg-ban-ask-answer-ok-feedback.md) | tgbot, feedback, ux | 曾关掉又被 patch 回滚；空实现+禁调用+重启才生效 |
| 2026-08-26 | [用户确认「传好了是吧」类追问时只复报日期/云端 ID/状态，勿重复执行 uplo](./2026-08-26-用户确认-传好了是吧-类追问时只复报日期-云端-id-状态-勿重复执行-upload-脚本.md) | daily-report,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-25 | [收到 mode=work 派单 60 秒内 ack、完工 reply 结案，审稿](./2026-08-25-收到-mode-work-派单-60-秒内-ack-完工-reply-结案-审稿类任务按回执缺口.md) | agent-bus,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-25 | [补设计可视化前先拉平台现网正文作 merge 底稿，避免本地补丁被后续版本覆盖后](./2026-08-25-补设计可视化前先拉平台现网正文作-merge-底稿-避免本地补丁被后续版本覆盖后再审仍报缺.md) | dev-platform,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-25 | [TG 重推日报前先确认推送脚本已改为只发正文无标题头，推完请主人在私聊目视验收](./2026-08-25-tg-重推日报前先确认推送脚本已改为只发正文无标题头-推完请主人在私聊目视验收.md) | daily-report,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-25 | [指标库 ER 推文档库后须同步落仓 `docs/metric_library_e](./2026-08-25-指标库-er-推文档库后须同步落仓-docs-metric_library_er_diagram.md) | doc-library,delivery,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-25 | [会话 resume 失败续做时，先查本地稿并对齐最新 spec 表名再推文档库，](./2026-08-25-会话-resume-失败续做时-先查本地稿并对齐最新-spec-表名再推文档库-勿用旧临时名或旧.md) | cursor-session,metric-library,er-diagram,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-24 | [画 ER 时 v0.2 三层实线作底座，v0.3 entity/event/ro](./2026-08-24-画-er-时-v0-2-三层实线作底座-v0-3-entity-event-role-虚线标待拍.md) | metric-library-er,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-24 | [知秋在 v0.2 底座 vs v0.3 超集拍板前，禁止改 DDL、建表或按未定](./2026-08-24-知秋在-v0-2-底座-vs-v0-3-超集拍板前-禁止改-ddl-建表或按未定增量落库.md) | metric-library-governance,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-24 | [改指标库表结构前先定理论层次（Registry / Metric Store /](./2026-08-24-改指标库表结构前先定理论层次-registry-metric-store-semantic-la.md) | metric-library-design,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-24 | [work-log|双机|hosts 缺口须在周报正文标注，勿假装双机流水齐全](./2026-08-24-work-log-双机-hosts-缺口须在周报正文标注-勿假装双机流水齐全.md) | 周报,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-24 | [大漏斗|探表|答「有没有数」须分环境查 SR 行数与 prod 是否存在，Spa](./2026-08-24-大漏斗-探表-答-有没有数-须分环境查-sr-行数与-prod-是否存在-spark-paimo.md) | dws,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-24 | [绿点|打卡|问机制先读 `should_appear_online()` 与计划](./2026-08-24-绿点-打卡-问机制先读-should_appear_online-与计划时间生成-勿把-jike.md) | tgbot,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-23 | [日报上传必须与用户定稿逐字一致，先落盘再上传；同日重复上传为 updated 覆](./2026-08-23-日报上传必须与用户定稿逐字一致-先落盘再上传-同日重复上传为-updated-覆盖-勿擅自改措辞.md) | daily-report,upload,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-23 | [指标库 Phase 0 四表：DDL §1 五问知秋拍板前禁止在 test me](./2026-08-23-指标库-phase-0-四表-ddl-1-五问知秋拍板前禁止在-test-metadata-建表.md) | metric-library,phase0,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-23 | [归因报告脚本跑完后必须核对是否已私聊/发出文件，不能仅以「文件已生成」结案](./2026-08-23-归因报告脚本跑完后必须核对是否已私聊-发出文件-不能仅以-文件已生成-结案.md) | attribution-report,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-22 | [关极客打卡改 .env 并延迟重启过签退窗；双机 tgbot 都要改，VPN/抽](./2026-08-22-关极客打卡改-env-并延迟重启过签退窗-双机-tgbot-都要改-vpn-抽查不受影响.md) | jike_checkin,tgbot,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-22 | [补跑前先核 SUCCESS PI 与上游；下游 NULL 先判上游是否本日无数，](./2026-08-22-补跑前先核-success-pi-与上游-下游-null-先判上游是否本日无数-避免重复补跑.md) | complement,ads,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-22 | [跳出率只用 dropout_page_cnt/stay_page_cnt；pv ](./2026-08-22-跳出率只用-dropout_page_cnt-stay_page_cnt-pv-与-jump-不.md) | page_visit,datacheck,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-21 | [同工作流下游 SUCCESS 但字段全 NULL 时优先查任务依赖顺序与上游分区](./2026-08-21-同工作流下游-success-但字段全-null-时优先查任务依赖顺序与上游分区就绪时间-别误判.md) | datacheck,dolphin,dag,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-21 | [补数秒失败先查目标静态分区是否存在，缺分区先 ADD PARTITION 再重跑](./2026-08-21-补数秒失败先查目标静态分区是否存在-缺分区先-add-partition-再重跑.md) | complement,partition,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-21 | [改进入/跳转口径前先对照现网：`entry_cnt` 与「站内跳入」语义相反，用](./2026-08-21-改进入-跳转口径前先对照现网-entry_cnt-与-站内跳入-语义相反-用户-跳出-对应-ju.md) | page-visit,metric,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-21 | [看进入/跳转次数用 DWS；看来源→去向分布必须回查 dwd_app_page_](./2026-08-21-看进入-跳转次数用-dws-看来源-去向分布必须回查-dwd_app_page_view_d-按.md) | dws-app-page-visit,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-21 | [绿点休息窗：平日 13:00–15:00+19:00–20:00，周六仅 13:](./2026-08-21-绿点休息窗-平日-13-00-15-00-19-00-20-00-周六仅-13-00-15-00.md) | tg-presence,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-20 | [休息窗 13:00–15:00 与 19:00–20:00 在 should_a](./2026-08-20-休息窗-13-00-15-00-与-19-00-20-00-在-should_appear_on.md) | tg-presence,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-20 | [取值条件不同导致结果不同即拆新指标，禁止同名不同义硬合并](./2026-08-20-取值条件不同导致结果不同即拆新指标-禁止同名不同义硬合并.md) | metric-library,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-20 | [标签链 prod 只跑 wrapper_daily_v3.sh，禁手工逐步跑 b](./2026-08-20-标签链-prod-只跑-wrapper_daily_v3-sh-禁手工逐步跑-base-否则水位.md) | spark,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-20 | [Spark prod 可用；用户标签链必须走 wrapper_daily_v3，禁手工逐步跑](./2026-08-20-spark-prod-hadoop1-可用-标签链须走-wrapper_daily_v3-禁手工逐步跑.md) | spark, yarn, user-tag, wrapper_daily_v3 | bus#6901：hadoop-1 yarn client；base 起不幂等须 wrapper+水位；03:10 错峰；prod 分区等知秋 |
| 2026-08-20 | [明日动作术语对齐 bus/工单原文（审核人漏填、回复、上一次与下一次），勿用近义](./2026-08-20-明日动作术语对齐-bus-工单原文-审核人漏填-回复-上一次与下一次-勿用近义错词.md) | daily-report,bus,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-20 | [上传云端以主人私聊定稿正文为准原封不动上传，不得先改本地文件再传](./2026-08-20-上传云端以主人私聊定稿正文为准原封不动上传-不得先改本地文件再传.md) | daily-report,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-20 | [prod 补数前先比 test/prod 线版 SQL（去注释）并查上游 DWD](./2026-08-20-prod-补数前先比-test-prod-线版-sql-去注释-并查上游-dwd-分区-逻辑一致.md) | complement,comic-analysis,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-19 | [日报定时能唤醒，但 executor 额度耗尽不降级 → 等人催](./2026-08-19-daily-report-executor-must-fallback-on-quota.md) | daily-report, cursor-executor, quota | 21:30 通了；composer-2.5 耗尽须立刻换 fast，禁止同模型空转 |
| 2026-08-19 | [用户指定正文上传云端时原封不动落稿上传，不得先改措辞再传](./2026-08-19-用户指定正文上传云端时原封不动落稿上传-不得先改措辞再传.md) | daily-report-upload,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-19 | [对外回复禁用「主人」，用「你」直说；内部记忆可留出处词，输出必须剥离](./2026-08-19-对外回复禁用-主人-用-你-直说-内部记忆可留出处词-输出必须剥离.md) | communication,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-19 | [写/推日报前必须先跑双机 work-log 同步并读合并稿，禁止仅靠 trans](./2026-08-19-写-推日报前必须先跑双机-work-log-同步并读合并稿-禁止仅靠-transcript-在同.md) | daily-report,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-18 | [test SR 建表走 dev session + MCP DDL；Paimon](./2026-08-18-test-sr-建表走-dev-session-mcp-ddl-paimon-staging-另.md) | dbprogramming,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-18 | [MySQL 8 条件唯一用生成列 NULL 不参与 UNIQUE；`metric](./2026-08-18-mysql-8-条件唯一用生成列-null-不参与-unique-metric_label-唯一.md) | metric-library,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-18 | [DDL 评审后改稿 push 不等于建表；Phase0 test DDL 须等 ](./2026-08-18-ddl-评审后改稿-push-不等于建表-phase0-test-ddl-须等-5-条拍板-知秋.md) | metric-library,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-18 | [工作簿进展读当日 work-log 实活，禁捞旧 bus 挂账与每日重复模板；今](./2026-08-18-工作簿进展读当日-work-log-实活-禁捞旧-bus-挂账与每日重复模板-今天确认清楚再回-.md) | workbook,tgbot,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-18 | [停留时长：有效会话（08-17 阿莱士）与离开事件埋点（产品未答）分层维护；pr](./2026-08-18-停留时长-有效会话-08-17-阿莱士-与离开事件埋点-产品未答-分层维护-prod-有分区-已.md) | page-stay,workbook,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-18 | [对外一句会被人当事实用的话，先查 memory/私聊/session/代码；拿不](./2026-08-18-对外一句会被人当事实用的话-先查-memory-私聊-session-代码-拿不准先说-正在核对.md) | agent-bus,workbook,口径,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-17 | [设计主体写齐后按 commit→bus狂人→DDL草案→bus知秋 顺序主动闭环](./2026-08-17-设计主体写齐后按-commit-bus狂人-ddl草案-bus知秋-顺序主动闭环-不等逐条授权.md) | design-delivery,agent-bus,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-17 | [又初负责概念层模型+迁移路径+DDL草案；狂人等模型交稿后再做264条语义归纳；](./2026-08-17-又初负责概念层模型-迁移路径-ddl草案-狂人等模型交稿后再做264条语义归纳-设计阶段不改现网.md) | metric-library,bus6655,分工,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-17 | [从0到1设计先查业界语义层/指标库实践，写进设计稿§0，并显式标注采纳项与因#6](./2026-08-17-从0到1设计先查业界语义层-指标库实践-写进设计稿-0-并显式标注采纳项与因-6552铁律不照搬.md) | metric-library,design,0-to-1,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-17 | [TG 绿点跟当天极客随机打卡计划走，TCP 不随下线断开](./2026-08-17-tg-visible-online-follows-jike-punch-plan.md) | tg, telethon, jike, punch | UpdateStatus 对齐 checkin/checkout 计划；查岗连接保持 |
| 2026-08-17 | [读消息须服务端分页对齐全量，禁止本地截断漏读](./2026-08-17-读消息须服务端分页对齐全量禁止本地截断.md) | context-bridge,agent-bus,tg | 私聊#327：prompt 改 full_sync + inbox 分页对账 |
| 2026-08-17 | [指标库 #6552：区分「认可(v0.1既有)」与「评审新增三处必改」，publi](./2026-08-17-metric-library-6552-区分认可与三处必改-req_ref四件套.md) | metric-library,bus-6552,session-rotate | bus#6625 纠正：req_ref 四件套 + 禁比率 + aggregation 白名单 |
| 2026-08-17 | [表级拓扑机器验过后，人工只盯列级：同名列归属、WHERE过滤、聚合口径、停更/视](./2026-08-17-表级拓扑机器验过后-人工只盯列级-同名列归属-where过滤-聚合口径-停更-视图架构.md) | lineage,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-17 | [周报说人话只改措辞不改版式，保留原分块/卡点/周会一句话结构](./2026-08-17-周报说人话只改措辞不改版式-保留原分块-卡点-周会一句话结构.md) | weekly-report,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-17 | [原 bus 被误结案后补正式回执须 `--no-dedup` 新发 reply，](./2026-08-17-原-bus-被误结案后补正式回执须-no-dedup-新发-reply-并检查-dedup-是否.md) | agent-bus,补发,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-17 | [prod 有分区有数不能证明口径对；bounce 争议看 DWM is_boun](./2026-08-17-prod-有分区有数不能证明口径对-bounce-争议看-dwm-is_bounce-与-dws.md) | session_duration,bounce,datacheck,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-17 | [狂人 bus 含 Q1/Q2/Q3 或「不许跳过三问」时禁止快车道 reply_](./2026-08-17-狂人-bus-含-q1-q2-q3-或-不许跳过三问-时禁止快车道-reply_only-结案-.md) | agent-bus,worker_ant,口径争议,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-16 | [未结项汇报必须二分「又初欠账」与「等外部拍板」，避免把 pending RP 说](./2026-08-16-未结项汇报必须二分-又初欠账-与-等外部拍板-避免把-pending-rp-说成又初完全没推进.md) | status-report,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-16 | [review|stage7 待审须 bus 私催 + 协作群 @，带 bus# ](./2026-08-16-review-stage7-待审须-bus-私催-协作群-带-bus-与-session-cod.md) | dev-session,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-16 | [terminology|见指标库 HTML「蓝底」图例时写「数据侧初稿、请产品确](./2026-08-16-terminology-见指标库-html-蓝底-图例时写-数据侧初稿-请产品确认-禁止读成审核.md) | docs,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-15 | [poller 遇 API 超时必须续心跳；启动脚本先写 pid 再 bootstrap](./2026-08-15-poller-timeout-先写pid再bootstrap-超时也续心跳.md) | agent-bus, poller, launchd | 超时不续心跳 + start 先 --once 会让 daemon 连环拉起 |
| 2026-08-15 | [日报推送：周六 18:30，其余工作日 21:30](./2026-08-15-daily-report-sat-1830-weekday-2130.md) | daily-report, launchd, schedule | 周六整条链路前移；flush 18:20 / wake 18:30 / fallback 18:45；新机须重装 flush |
| 2026-08-15 | [页面访问「进入」=来路空或 unknown，禁止沿用「会话首页+来路非空」初稿口](./2026-08-15-页面访问-进入-来路空或-unknown-禁止沿用-会话首页-来路非空-初稿口径.md) | metric-library,口径,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-15 | [指标库文档按大漏斗模板写，口径对齐 prod/已定 dev session，比率](./2026-08-15-指标库文档按大漏斗模板写-口径对齐-prod-已定-dev-session-比率字段查询侧现算不.md) | metric-library,page-visit,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-15 | [用户贴定稿并说「按这个上传云端」时，先写 reports/日报-日期.md 再 ](./2026-08-15-用户贴定稿并说-按这个上传云端-时-先写-reports-日报-日期-md-再-upload-a.md) | daily-report,upload,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-14 | [日报 21:30 断点：executor 必须真解析 DAILY_REPORT；写 lesson 不算修完](./2026-08-14-daily-report-executor-must-parse-DAILY_REPORT.md) | daily-report, cursor-executor, launchd, tg | `_parse_wake_line` 只认 AGENT_BUS 会丢掉日报；fallback 须直推/直跑；改完 kickstart |
| 2026-08-14 | [主人允许无二次指令时自主推进已派活；分工变被动（如补数只验数）不覆盖其它仍归己的](./2026-08-14-主人允许无二次指令时自主推进已派活-分工变被动-如补数只验数-不覆盖其它仍归己的独立任务.md) | agent-autonomy,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-14 | [派活默认闭环：一次性独立任务（如 _probe 上集群）不因盯盘/回执让路 in](./2026-08-14-派活默认闭环-一次性独立任务-如-_probe-上集群-不因盯盘-回执让路-indefinite.md) | task-priority,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-14 | [汇报任务进度前先查集群日志、outgoing 产物、bus 结案状态，禁止未核实](./2026-08-14-汇报任务进度前先查集群日志-outgoing-产物-bus-结案状态-禁止未核实就下-没干-没跑.md) | agent-execution,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-14 | [DAILY_REPORT 唤醒写入 wake_feed 但 executor 未](./2026-08-14-daily_report-唤醒写入-wake_feed-但-executor-未消费时-补跑-s.md) | daily-report,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-14 | [Spark/YARN 补数或 A/B 判定跑完后须立刻 bus reply 报秒](./2026-08-14-spark-yarn-补数或-a-b-判定跑完后须立刻-bus-reply-报秒数与选型-勿等催.md) | agent-bus,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-14 | [写明日动作前先对当天周几，周四及以后禁写「周中」作截止，改「周五」等具体日期](./2026-08-14-写明日动作前先对当天周几-周四及以后禁写-周中-作截止-改-周五-等具体日期.md) | daily-report,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-13 | [关键词页空白先查 ops-api 路由是否 404，prod 活表仅 d_h/s](./2026-08-13-关键词页空白先查-ops-api-路由是否-404-prod-活表仅-d_h-search_ho.md) | keyword-analysis,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-13 | [分工归属只认 workbook.md 实查项，清单无则等知秋定，禁止擅自指派](./2026-08-13-分工归属只认-workbook-md-实查项-清单无则等知秋定-禁止擅自指派.md) | ownership,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-13 | [活跃账号对数必须先对齐 app+业务日，再比 ads/dws/API 三处；T ](./2026-08-13-活跃账号对数必须先对齐-app-业务日-再比-ads-dws-api-三处-t-日与-t-1-不.md) | datacheck,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-13 | [活跃数核查统一走用户活跃 V2 与 `dau_count`，V1 仅 PV 会系](./2026-08-13-活跃数核查统一走用户活跃-v2-与-dau_count-v1-仅-pv-会系统性偏低.md) | datacheck,API,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-13 | [「搜索引擎占比」无标准字段时，用自然新增占比作临时代理并 bus 确认业务定义，](./2026-08-13-搜索引擎占比-无标准字段时-用自然新增占比作临时代理并-bus-确认业务定义-禁止把站内搜索或渠.md) | db,SEO,organic,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-13 | [两页同指标不一致时，先查表/API/ETL 完成度与分时快照时刻，再查口径定义](./2026-08-13-两页同指标不一致时-先查表-api-etl-完成度与分时快照时刻-再查口径定义.md) | datacheck,口径,看板,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-12 | [日报须 executor 消费；私聊硬超时防卡队列](./2026-08-12-daily-report-executor-and-dm-queue.md) | daily-report, tgbot, queue, cursor-executor | DAILY_REPORT 进 executor；AI_HARD_TIMEOUT=1800；21:45 兜底 |
| 2026-08-12 | [群聊显式 @ 又初时必须群内给实质答复，禁止以未 @ 机器人为由不回](./2026-08-12-群聊显式-又初时必须群内给实质答复-禁止以未-机器人为由不回.md) | tg-group,协作,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-12 | [开 YARN 前确认集群 spark 包与 origin/dev 一致，旧版单文](./2026-08-12-开-yarn-前确认集群-spark-包与-origin-dev-一致-旧版单文件-sql-与仓.md) | spark-cluster,deploy,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-12 | [大漏斗集群读湖仓不读 SR，停跑自查优先查 Paimon 分区可读性与 Flin](./2026-08-12-大漏斗集群读湖仓不读-sr-停跑自查优先查-paimon-分区可读性与-flink-fanout.md) | big-funnel,datacheck,paimon,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-12 | [工作簿进展改双通道后：群里发完同内容 mirror bus（kind=progr](./2026-08-12-工作簿进展改双通道后-群里发完同内容-mirror-bus-kind-progress-同日-w.md) | workbook-bus,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-12 | [显式 @ 又初 必须在群里实质答复；未 @ 则静默，回复中禁止解释「为何不回」](./2026-08-12-显式-又初-必须在群里实质答复-未-则静默-回复中禁止解释-为何不回.md) | tg-group,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-12 | [工作簿群/bus 进展统一读 `.claude/database/workboo](./2026-08-12-工作簿群-bus-进展统一读-claude-database-workbook-md-团队编号与.md) | workbook,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-11 | [日报 wake 读 AUTHORITY_HOST 禁止整文件去空白](./2026-08-11-daily-report-wake-authority-parse.md) | daily-report, launchd, tg, AUTHORITY_HOST | tr -d 空白会粘注释；跳过 # 取首行 |
| 2026-08-11 | [狂人记忆系统实操 v2](./2026-08-11-worker-ant-memory-v2-practice.md) | memory, worker_ant, bootstrap | 4前缀/硬注入/立刻沉/周体检；bus#6361 |
| 2026-08-11 | [用户说「推送云端」时只传已定稿 reports 文件，禁止改写；成功回执须含云端](./2026-08-11-用户说-推送云端-时只传已定稿-reports-文件-禁止改写-成功回执须含云端-record-.md) | daily-report,cloud-upload,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-10 | [DWS 核查须从上游按 ETL 规则全量重算交叉](./2026-08-10-dws-full-chain-reconstruct-crosscheck.md) | datacheck, full-chain, reconstruct | 汇总+行级 FULL OUTER；visit/session T-1 PASS |
| 2026-08-10 | [页面访问 jump_only 与空 uid 是口径规律](./2026-08-10-page-visit-jump-only-empty-uid-caliber.md) | page-visit, jump_only, empty-uid | 勿当 ETL 丢数；对账用有 uid view |
| 2026-08-10 | [归因 flag≠config≠result；metrics 断流单盯](./2026-08-10-attribution-flag-config-result-metrics-layers.md) | attribution, metrics, 断流 | metrics 自 06-29 空；分层报 |
| 2026-08-10 | [标签连续分区+漏斗未上线勿混名](./2026-08-10-user-tag-partition-break-and-funnel-not-on-prod.md) | user-tag, funnel, 断流 | tag 08-07 起 0；event_funnel 无表 |
| 2026-08-10 | [大漏斗扩全量前先用 SF-81 按 playbook 做口径 spot-chec](./2026-08-10-大漏斗扩全量前先用-sf-81-按-playbook-做口径-spot-check-宽表-is_.md) | etl-validation,funnel,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-10 | [收到「别一直发拦截了」类指摘时，立刻改工具/规则并继续干活，禁止重复发送同类说明](./2026-08-10-收到-别一直发拦截了-类指摘时-立刻改工具-规则并继续干活-禁止重复发送同类说明.md) | agent-communication,feedback,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-10 | [Yarn 日跑脚本须拦截已知 0 行源表的 app（如 app_2556），否则](./2026-08-10-yarn-日跑脚本须拦截已知-0-行源表的-app-如-app_2556-否则-exit-0-也.md) | yarn-spark,datacheck,anti-pattern,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-10 | [TG|收到用户「不要一直重复发拦截」时，立刻改行为并交付修复，禁止复读状态模板](./2026-08-10-tg-收到用户-不要一直重复发拦截-时-立刻改行为并交付修复-禁止复读状态模板.md) | 协作,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-10 | [yarn|大漏斗|冒烟|app_2556 源表 0 行会导致假成功，脚本层应硬拒](./2026-08-10-yarn-大漏斗-冒烟-app_2556-源表-0-行会导致假成功-脚本层应硬拒并在-readm.md) | spark,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-09 | [工作簿拦截私聊刷屏：launchd 找不到 mysql + 拦截未去重](./2026-08-09-workbook-verify-block-dm-spam-mysql-path.md) | tgbot, workbook-progress, mysql, dm-spam | 拦截同一天只 DM 一次；MYSQL_BIN |
| 2026-08-09 | [ETL 跑通但 0 行时先核对 app_id 与源表行数，再决定是否换 app ](./2026-08-09-etl-跑通但-0-行时先核对-app_id-与源表行数-再决定是否换-app-补跑.md) | funnel-etl,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-09 | [宽漏斗禁单 SQL 宽聚合，拆成 metrics + wide 两阶段，避免 d](./2026-08-09-宽漏斗禁单-sql-宽聚合-拆成-metrics-wide-两阶段-避免-driver-heap.md) | funnel-etl,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-09 | [user_is_new 禁止 JOIN 无分区 dim_user_all，改由当](./2026-08-09-user_is_new-禁止-join-无分区-dim_user_all-改由当日-user_r.md) | funnel-etl,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-08 | [口径|is_new](./2026-08-08-口径-is_new.md) | spec,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-08 | [funnel|oom|etl](./2026-08-08-funnel-oom-etl.md) | spark,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-07 | [指定审核人发产须同时满足 publish_request_status=pend](./2026-08-07-指定审核人发产须同时满足-publish_request_status-pending-与-pu.md) | publish-prod,publish_request_status,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-07 | [并行处理私聊/工作簿时仍须 60 秒内 agent-bus ACK，核查完再 r](./2026-08-07-并行处理私聊-工作簿时仍须-60-秒内-agent-bus-ack-核查完再-reply-禁止漏.md) | agent-bus,ack,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-07 | [群工作簿进度发群前必须 prod 实查分区/验数，禁止只看 test 或 dev](./2026-08-07-群工作簿进度发群前必须-prod-实查分区-验数-禁止只看-test-或-dev-session.md) | workbook-progress,prod-check,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-07 | [群工作簿进展须当日实查整理，新大活次日登簿汇报](./2026-08-07-群工作簿进展须当日实查-新大活次日登簿.md) | workbook-progress, tgbot, supplemental, criticism | 禁止复读硬编码；大漏斗登 supplemental#11 |
| 2026-08-07 | [报补数窗口与耗时时查全部分区 etl_time 与海豚实例，并区分「发起窗口」与](./2026-08-07-报补数窗口与耗时时查全部分区-etl_time-与海豚实例-并区分-发起窗口-与-表实际最早可落.md) | complement,datacheck,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-07 | [日报正文只用业务说法（如「五月至今补刷」），禁止写入内部分区区间、耗时秒数、PI](./2026-08-07-日报正文只用业务说法-如-五月至今补刷-禁止写入内部分区区间-耗时秒数-pi-等核对细节.md) | daily-report,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-07 | [写日报前必须先 prod/test/平台逐项核查再落稿，状态与补数范围禁止凭印象](./2026-08-07-写日报前必须先-prod-test-平台逐项核查再落稿-状态与补数范围禁止凭印象或局部样本.md) | daily-report,datacheck,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-06 | [bus 转发须自检正文完整；截断导致对方看不到问题时立即补发全量说明再结案](./2026-08-06-bus-转发须自检正文完整-截断导致对方看不到问题时立即补发全量说明再结案.md) | agent-bus,messaging,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-06 | [问指标是否被改时先查平台 metric 文档并对本地 diff，同时读齐私聊上文](./2026-08-06-问指标是否被改时先查平台-metric-文档并对本地-diff-同时读齐私聊上文-禁止跨轮次漏读.md) | context-continuity,platform-docs,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-06 | [狂人未更新工作簿时，自开任务写 workbook_supplemental.js](./2026-08-06-狂人未更新工作簿时-自开任务写-workbook_supplemental-json-合并逻辑按.md) | workbook,task-tracking,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-05 | [主人说「stage1-6 干完先不发」时：可标 stage done + tes](./2026-08-05-主人说-stage1-6-干完先不发-时-可标-stage-done-test-跑通-但-禁止-.md) | dev-session-stage,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-05 | [进入=会话首页且来路非空；刷新不算跳转；空 uid/device 丢弃——改 E](./2026-08-05-进入-会话首页且来路非空-刷新不算跳转-空-uid-device-丢弃-改-etl-前先核对这三.md) | page-visit-caliber,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-05 | [一个 PRD「页面访问」按指标类型拆成 visit_d（日指标）与 jump_d](./2026-08-05-一个-prd-页面访问-按指标类型拆成-visit_d-日指标-与-jump_d-跳转分布-两个.md) | page-visit,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-04 | [日报对照主人改定稿学习写法](./2026-08-04-日报对照主人改定学习.md) | daily-report, learning | 结果向少旁白；明日动作可多条估截止 |
| 2026-08-04 | [extension|security|官方 vsix 安装前必须 SHA256 ](./2026-08-04-extension-security-官方-vsix-安装前必须-sha256-校验通过-禁止跳.md) | dc-platform,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-04 | [extension|dual-mac|双机无 SSH 时扩展升级须各机本地跑 s](./2026-08-04-extension-dual-mac-双机无-ssh-时扩展升级须各机本地跑-sync-memo.md) | dc-platform,session-rotate | 会话轮换前自动蒸馏 |
| 2026-08-04 | [日报只写已完成；死锁少写；推送仅 old-mac](./2026-08-04-daily-report-no-in-progress.md) | daily-report, dual-mac, tg | 已完成→结果；未完→明日；死锁空；old-mac 推私聊 |
| 2026-08-04 | [日报定稿后必须推送 TG 私聊](./2026-08-04-daily-report-push-tg-dm.md) | tg, daily-report, dm | 仅 old-mac 跑 memory/scripts/post_daily_report_to_dm.py |
| 2026-08-03 | [归因 Paimon 影子全链 test](./2026-08-03-attribution-paimon-shadow-full-chain-test.md) | attribution-shadow, paimon, dolphin | 独立 wf+_r 全链；test 湖空则 0 行；真压测等湖或 prod |
| 2026-08-03 | [提交只动 ops_system：禁改平台插件与 api_v1](./2026-08-03-禁改平台插件与api_v1.md) | git, ownership, 禁改 | vscode-extension/dc-platform-server 禁改；误 push 则新 commit 恢复 |
| 2026-08-01 | [prod 补数全员开放](./2026-08-01-prod-complement-open-all-users.md) | dolphin, complement, prod | env=prod 补数非admin可用；三坑 dep_type/日期/force |
| 2026-08-01 | [butler 原生图记忆体系](./2026-08-01-butler-native-memory-system.md) | memory, butler, self-evolve | 项目.claude/memory+sqlite；六工具；写前query；读timeline+query |
| 2026-08-01 | [做事要考虑健壮性](./2026-08-01-robustness-first.md) | robustness, habit, ops | 失败自愈、不滚雪球、脚本同源、改完 smoke |
| 2026-08-01 | [新 Mac memory 同步总失败因旧脚本](./2026-08-01-new-mac-memory-sync-old-script.md) | memory-git, dual-mac, new-mac, launchd | LaunchAgent 跑 07-24 旧脚本无自愈；应对齐 memory/scripts 新版 |
| 2026-07-31 | [Dev Session 1–6 必须逐步做完否则别人打不开](./2026-07-31-dev-session-stages-complete-or-others-cant-open.md) | dev-session, stage1-6, publish_runs, strict | 禁空标 done/半截收工；产物+证据+push 齐再收口 |
| 2026-07-31 | [提交后立刻推远程禁止分两步](./2026-07-31-commit-then-push-no-two-steps.md) | git, push, feedback | 入库/commit 成功即 push；勿再问要不要推 |
| 2026-07-31 | [提交说明用第一人称直述禁我/主人/旁白](./2026-07-31-first-person-commit-voice.md) | git, commit, voice | 直述做了什么；禁「我/主人/旁白体」 |
| 2026-07-31 | [Stage4 海豚段不可半截](./2026-07-31-stage4-finish-dolphin-not-skip.md) | stage4, dolphin_test | 三勾后必须补数对账再标 done |
| 2026-07-28 | [回懂了必须立刻开干](./2026-07-28-ack-must-start-work.md) | ack, execution, criticism | ACK 后同会话动手，禁口头确认后静默 |
| 2026-07-28 | [群聊仅显式 @初儿/@又初 才回，取消裸喊名](./2026-07-28-群聊仅显式at初儿又初才回.md) | tg, group, mention, silent | 废止裸喊名；@worker_ant+文案带又初不再秒回 |
| 2026-07-28 | [探活 / bus 收条类对话：已闭环则勿再回](./2026-07-28-探活与bus收条无需再回.md) | tg, group, silent, liveness, bus-ack | 还活着吗/bus收到了吗/收到这块我跟 → 不回；禁 Cursor 叠回 |
| 2026-07-28 | [vsix 放 dc-platform-server/extension/ 走 g](./2026-07-28-vsix-放-dc-platform-server-extension-走-git-pull-s.md) | extension,release,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-28 | [device_id 空率≥90%（本需求 100%）则直建 dim_device](./2026-07-28-device_id-空率-90-本需求-100-则直建-dim_device_all-勿再设计-.md) | device_tag,dim,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-28 | [PRD 五档看板只查 session_duration 合表并带 stat_gr](./2026-07-28-prd-五档看板只查-session_duration-合表并带-stat_grain-page.md) | session_duration,backend,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-27 | [bus-reply|bus 派活要求「结论请回 bus」时，验完直接 agent](./2026-07-27-bus-reply-bus-派活要求-结论请回-bus-时-验完直接-agent-bus-结案-.md) | tg-group,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-27 | [群聊双 @ strip 误判没@初儿](./2026-07-27-group-dual-at-strip-false-negative.md) | tgbot,group,mention | strip @youchu 后 Agent 只见 mudan → 误回不回；已修 |
| 2026-07-27 | [mention-routing|未 @youchu_ai_bot 的群消息直接不](./2026-07-27-mention-routing-未-youchu_ai_bot-的群消息直接不回-且不在群里解释.md) | tg-group,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-27 | [bot 自查告警：连续失败才私聊](./2026-07-27-bot-selfcheck-notify-after-sustained.md) | tgbot, watchdog, alert | NOTIFY_AFTER=3；getMe 后跳过二次探活 |
| 2026-07-27 | [VPN 续期不因请假/节假日停止](./2026-07-27-vpn-renew-never-skip-leave-holiday.md) | vpn, leave, holiday, launchd | 每天必续；请假日历不管 VPN |
| 2026-07-25 | [bus 入站（含 mudan99 等 peer）与 TG @ 同优先级当天回；私](./2026-07-25-bus-入站-含-mudan99-等-peer-与-tg-同优先级当天回-私聊极简时群里仍要主动.md) | agent-bus,collab,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-25 | [发布顺序固定为本地→git push→海豚，发布后 live SQL 与 git](./2026-07-25-发布顺序固定为本地-git-push-海豚-发布后-live-sql-与-git-sha-dif.md) | publish,dolphin,git,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-25 | [开通归因前先查配置表有无行；无行 INSERT、有行再 UPDATE；增量开通勿](./2026-07-25-开通归因前先查配置表有无行-无行-insert-有行再-update-增量开通勿跑-bulk-i.md) | attribution,prod-config,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-25 | [发布前三处代码必须一致 git/本地/海豚](./2026-07-25-publish-git-local-dolphin-triple-sync.md) | dolphin,git,publish,session-rotate | 发布完成=三处同 SHA；先 push 再发海豚；发布后 diff live SQL |
| 2026-07-25 | [开通归因=配置表 is_run=1 + 客户端 attribution_flag](./2026-07-25-开通归因-配置表-is_run-1-客户端-attribution_flag-1-双开-诊断报告.md) | attribution,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-25 | [提审 @ 审核人用 `@mudan99_bot`（野花），禁止 @ 主人代审](./2026-07-25-提审-审核人用-mudan99_bot-野花-禁止-主人代审.md) | collaboration,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-25 | [本地合表/改 outputs 后立刻用平台 API 同步 session，勿假设](./2026-07-25-本地合表-改-outputs-后立刻用平台-api-同步-session-勿假设插件已跟上.md) | dev-session,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-25 | [星型模型设计 playbook 已沉淀](./2026-07-25-star-schema-design-playbook.md) | star-schema,design,dws,ads,playbook | 设计 DWS/ADS 前读 playbooks/star_schema_design.md；六原则+checklist |
| 2026-07-25 | [page_stay 是 uid×dt 事实表，session_duration ](./2026-07-25-page_stay-是-uid-dt-事实表-session_duration-是多维预聚合-合.md) | duration_model,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-25 | [test 上 dws 删表/改 PK 用 root@43.212.113.132](./2026-07-25-test-上-dws-删表-改-pk-用-root-43-212-113-132-9030-勿用.md) | test_db,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-25 | [五档 DWS 合表用 stat_grain 区分单次/日均，查询必带该列，否则两](./2026-07-25-五档-dws-合表用-stat_grain-区分单次-日均-查询必带该列-否则两种-y-轴会混算.md) | session_duration,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-25 | [归因 shadow 读 Paimon register + landing cl](./2026-07-25-归因-shadow-读-paimon-register-landing-click-view-开.md) | attribution-shadow,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-25 | [群聊进度第一句给结论，回前核对 bus 实态，列点 ≤4 条用 `·`，验完 b](./2026-07-25-群聊进度第一句给结论-回前核对-bus-实态-列点-4-条用-验完-bus-结案再群里一句带过.md) | tg-group,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-25 | [影子压测用独立 Spark wf + `_shadow` 表，源侧对齐后再首跑，](./2026-07-25-影子压测用独立-spark-wf-_shadow-表-源侧对齐后再首跑-严禁动现网-sr.md) | paimon-shadow,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-24 | [群聊问进度禁止秒回「行，我来」罐头 ACK](./2026-07-24-progress-ask-no-instant-ack.md) | tg, group, progress, instant-ack, self-evolve | 进度问 → direct 短报；禁 instant ack |
| 2026-07-24 | [跨 Agent 分工对齐走 bus 互督 checkpoint，不在群里公开回复](./2026-07-24-跨-agent-分工对齐走-bus-互督-checkpoint-不在群里公开回复派活细节.md) | agent-bus,tg,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-24 | [归因 apply 须同步回写 `dim_user_daily_snapshot`](./2026-07-24-归因-apply-须同步回写-dim_user_daily_snapshot-t-1-分区-ch.md) | attribution,dim,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-24 | [查岗 handler 未命中须打 debug 日志，触发条件收成「抽查群 @ 即](./2026-07-24-查岗-handler-未命中须打-debug-日志-触发条件收成-抽查群-即尝试解析-勿依赖固定.md) | attendance,tgbot,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-24 | [日报上传云端须主人显式指令；只传 `reports/日报-YYYY-MM-DD.](./2026-07-24-日报上传云端须主人显式指令-只传-reports-日报-yyyy-mm-dd-md-定稿全文-禁.md) | daily-report,upload,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-24 | [停 18:00 页面停留推狂人须卸载 `com.youchu.page-stay](./2026-07-24-停-18-00-页面停留推狂人须卸载-com-youchu-page-stay-18h-laun.md) | page-stay,launchd,agent-bus,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-24 | [TG 群发 urllib 超时则 kill 进程并改用 curl 重发，成功后再](./2026-07-24-tg-群发-urllib-超时则-kill-进程并改用-curl-重发-成功后再报-已到达.md) | tg-send,urllib,curl,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-23 | [get_task_instance_log 约 64KB 截断拿不到 SR 尾部](./2026-07-23-get_task_instance_log-约-64kb-截断拿不到-sr-尾部错-需海豚-ui.md) | dolphin,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-23 | [单 task 秒级 FAIL 且补跑成功：先跑验恢复四件套再判瞬时资源问题，不必](./2026-07-23-单-task-秒级-fail-且补跑成功-先跑验恢复四件套再判瞬时资源问题-不必改-sql.md) | dolphin,datacheck,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-23 | [prod 集群 SSH 用 ec2-user@175.41.188.204，勿用](./2026-07-23-prod-集群-ssh-用-ec2-user-175-41-188-204-勿用-hadoop-.md) | dolphin,ssh,session-rotate | 会话轮换前自动蒸馏 |
| 2026-07-23 | [会话轮换必须先沉淀再清空](./2026-07-23-session-rotate-must-distill-first.md) | tg,session-rotate,self-evolve,feedback | 清 resume 前必蒸馏；carry+lesson+通知 |
| 2026-07-21 | [Dev Session 对外汉字名 · 禁 code/项目id](./2026-07-21-dev-session-display-name-format.md) | dev-session, naming, feedback, tg, project | 发群/新建用【标签】表名 · 又初；禁 dev-xxx 与海豚 project_code 对外 |
| 2026-07-22 | [双 Mac work-log 统一后再写日报](./2026-07-22-dual-mac-worklog-unified-daily-report.md) | daily-report, work-log, dual-mac, sync | hosts 分流+合并；sync-memory-git 自动导出；正式稿进 memory/work-log/reports |
| 2026-07-15 | [日报周报语气：通俗但正式](./2026-07-15-report-plain-but-formal-style.md) | daily-report, weekly-report, writing-style, communication | 主人钦定；非技术看懂+书面语气；术语翻业务话、禁口语俚语；playbook+daily-report.mdc 已同步 |
| 2026-07-15 | [停留时长进度+群知秋钦定要点](./2026-07-15-stay-duration-and-group-directives.md) | stay-duration, session, dws_session_duration, attribution, tag, zhiqiu, group | Phase1(page_stay/sid)test闭环待prod提审；Phase2知秋令转DWS会话时长(账户+设备)墙钟五档待拍；宏/人工节点/分层铁律 |
| 2026-07-13 | [工作簿负责人以最新一日为准](./2026-07-13-workbook-ownership-latest.md) | workbook, ownership, group, feedback | 禁沿用过期归属；07-12 起停留时长改派又初 |
| 2026-07-09 | [VPN 续期按导入时刻滚动](./2026-07-09-vpn-renew-by-import-time.md) | vpn, launchd, ops | imported_at 记上次导入；满 23h 提前续；非固定零点 |
| 2026-07-08 | [日报禁止写 bus 编号须写任务名](./2026-07-08-daily-report-no-bus-id.md) | daily-report, feedback, bus | 主人钦定；日报正文禁 bus#；写任务名；已改正 daily-report.mdc |
| 2026-07-08 | [日报须汇总多 Agent 流水](./2026-07-08-daily-report-multi-agent-worklog.md) | daily-report, work-log, multi-agent | 先读 work-log 当日文件+全 transcript，勿只写当前会话 |
| 2026-07-08 | [归因出数硬条件与测试验收手册](./2026-07-08-attribution-test-gates-handbook.md) | attribution, test, gate, handbook | 入围/成功/回写门槛；HTML 手册路径 Downloads |
| 2026-07-08 | [内容排行猫猫线按令撤回](./2026-07-08-content-rank-handoff-rollback.md) | content-ranking, division, worker_ant | 代管撤回即停；勿冒领已完成 |
| 2026-07-07 | [监控群聊上下文定时归档](./2026-07-07-group-chat-context-archive.md) | tg, group, context, memory, archive | context.jsonl 瘦身→group_chat/archive；_search.jsonl 检索；bot 心跳每小时触发 |
| 2026-07-01 | [rewrite_status DDL 未同步 ETL 28≠27 活教材](./2026-07-01-rewrite-status-prod-ddl-etl-mismatch.md) | attribution, ddl, prod, rewrite_status, worker_ant | bus#617 知秋钦定；半上线→0秒FAIL→22表连锁；DDL+ETL同批+显式列清单 |
| 2026-07-02 | [群聊权威点名秒回 知秋/狂人](./2026-07-02-group-roll-call-authority-reply.md) | tg, group, roll-call, worker_ant | 在吗/谁活着/机器人挂了→健康则秒回；group_roll_call_handler |
| 2026-07-02 | [agent-bus 静默吞单两坑 seal+needs_reply](./2026-07-02-agent-bus-静默吞单两坑.md) | agent-bus, poller, worker_ant, feedback | bus#944 seal 误封；bus#980 漏判；狂人直派默认需 reply |
| 2026-07-02 | [bus 派活先回能接吗](./2026-07-02-bus-dispatch-先回能接吗.md) | agent-bus, worker_ant, 协作习惯 | 正文含先回能接吗→首条 reply 先答能接否+并行冲突 |
| 2026-07-02 | [agent-bus TG 镜像三坑 + 反套娃纪律](./2026-07-02-agent-bus-tg-mirror-anti-nesting.md) | agent-bus, tg, feedback, prod | no-dedup 必 mirror；未 unblock 勿 done；改 bot 前验 sendMessage |
| 2026-07-02 | [wf 权威名 wf_dws_汇总_日 · prod UI legacy dws_日](./2026-07-02-dolphin-prod-test-wf-name-map.md) | dolphin, prod, attribution, wf-map | canonical=wf_dws_汇总_日；prod API 用 code，UI 仍显示 dws_日 |
| 2026-07-01 | [bus 增补：干完也要 reply](../lessons/2026-07-01-agent-bus-reply-even-if-done.md) | agent-bus, worker_ant, feedback | 旧铁律不变；已做完仍 ACK+reply，附证据 |
| 2026-07-01 | [agent-bus「等待执行」误报](../lessons/2026-07-01-agent-bus-progress-ide-heartbeat.md) | agent-bus, progress, cursor | IDE 主会话干活但 progress 只盯 CLI；reply:bus 键结案 |
| 2026-07-01 | [归因 test DAG 与发布判断](../lessons/2026-07-01-attribution-test-dag-publish-gate.md) | attribution, dolphin, prod, publish | test 线上=repo 则无需再发；prod 群请示知秋 |
| 2026-07-01 | [归因 E2E 文档 + SF-81 灰度对数](./2026-07-01-attribution-e2e-platform-doc-and-sf81-gray.md) | attribution, gray, SF-81, test, platform-doc | 平台 doc 沉淀；test dim 同步后 TASK_ONLY apply 516/516 通过 |
| 2026-06-29 | [海豚 SQL 块注释 INSERT 0 行](./2026-06-29-dolphin-sql-block-comment-zero-rows.md) | dolphin, sql, attribution, prod | INSERT 前禁 `/* */` 块注释；用 `--`；SUCCESS 仍须查行数 |
| 2026-06-27 | [依工作狂人持续进化](./20260627-youchu-evolve-from-worker-ant.md) | worker_ant, self-evolve | 派单收尾提炼；纠正入库；禁止重复ack |
| 2026-06-27 | [agent-bus offset 四步修法](./20260627-agent-bus-offset-persistence.md) | agent-bus, poller, feedback | after_id 落盘/逐条推进/首轮跳 backlog/去重 |
| 2026-06-27 | [记忆体系与自我进化](./20260627-worker-ant-memory-architecture.md) | memory, feedback, worker_ant | 三级分层/触发词/Why+How/去重铁律 |
| 2026-06-27 | [工作狂人全量协作核心包](./20260627-worker-ant-full-collab-core.md) | worker_ant, etl, migration, dolphin | bus#77 七章；dynamic_overwrite/cat/海豚API/踩坑 |
| 2026-06-26 | [工作狂人协作速查 v1](./20260626-worker-ant-collab-cheatsheet.md) | worker_ant, starrocks, datacheck, prod | 速查简版；agent-bus bus#72 |
| 2026-06-24 | [ETL 统一 ops_system 分层目录](./2026-06-24-ops-system-etl-directory-layout.md) | ops_system, etl, dev-session, chcode | 禁仓库根 dwd_/dws_ session；SQL+文档同目录进 ops_system 对应层 |
| 2026-06-18 | [work-log 跨 Agent 共享](feedback_work_log_multi_agent_reports.md) | work-log, agent, daily-report | 本地 work-log/ 日流水；子 Agent 收尾必 append；不进 Git |
| 2026-06-18 | [ETL SQL 文件头三行声明](./2026-06-18-sql-etl-header-three-lines.md) | sql, lint, dolphin, etl | 前 30 行须 task/doc/params + 同目录 task.yaml；注释禁占位符 |
| 2026-06-17 | [StarRocks ALTER DEFAULT + PK MODIFY](./2026-06-17-starrocks-alter-default-and-pk-modify.md) | starrocks, ddl, primary-key | ADD DEFAULT 0 报错；主键表 key 列禁止 MODIFY |
| 2026-06-17 | [dc-platform 项目化记忆统一](./2026-06-17-dc-platform-projectization.md) | dc-platform, memory, archive | 公共记忆迁 ~/.dc-platform/memory/；task.yaml project=dc-platform |
| 2026-06-13 | [海豚发布 schedule 仍 OFFLINE](./2026-06-13-dolphin-publish-schedule-offline.md) | dolphin, schedule, dependent, video, test | wf PUT 后须 online_schedule；globalParams 与 repo SQL 须与线上一致 |
| 2026-06-10 | [核查规则沉淀剧本](./20260610-datacheck-playbook-as-asset.md) | datacheck, playbook, attribution, process | 核查认可后必更新 playbooks/；lesson 记坑、剧本记可执行 SQL |
| 2026-06-09 | [attribution_flag 列错位](./20260609-attribution-flag-column-order.md) | attribution, dwd, dolphin, test, schema | ALTER 追加列后须 INSERT 显式列名；小时任务缺字段会把 etl_time 写进 attribution_flag |
| 2026-06-05 | [归因 test 发布补数零行核验](./20260605-attribution-test-deploy-backfill.md) | attribution, dolphin, test, complement, dim | dim 须大写 app_id；补数 SUCCESS+0 行先查注册与落地页 IP 交集 |
| 2026-06-03 | [归因分析按 app 独立](./20260603-attribution-analyze-by-app.md) | attribution, datacheck, prod, per-app | 注册归因必须分 app 看漏斗与匹配因子；混算掩盖无候选/阈值差异 |
| 2026-06-03 | [生产 LTV 补数 readonly 限制](./20260603-prod-ltv-backfill-readonly.md) | prod, ltv, dolphin, complement, readonly | 生产 SR readonly + 无 prod 海豚写权限 → 必须海豚 UI/ETL 账号补数，不能直接 INSERT |
| 2026-05-29 | [dad-dau 分层根因与逐层核查](./2026-05-29-dad-dau-layered-root-cause.md) | datacheck, ads, dwd, dw, device_id, dad, dau | TJ-001 DAD 900w 根因在客户端 device_id 高 churn + ADS 口径含匿名 device；datacheck 必须逐层追到 dw |
| 2026-07-27 | [merge_pool 多桶 OVERWRITE](./2026-07-27-merge-pool-stage4-overwrite-and-publish.md) | merge_pool, stage4 | 同分区串行桶会互覆盖；默认 bucket_n=1 |
| 2026-07-28 | deprecate-must-offline-old-dolphin-task | high | dolphin,deprecate,half-migration | 合表废弃必须同批删旧海豚 task，禁半迁移 |
| 2026-08-03 | [查岗未回：work_online 克隆 session 双连抢更新](./2026-08-03-查岗未回因work_online克隆session双连抢更新.md) | attendance,tgbot,telethon | 同 auth_key 双连导致 NewMessage 丢失 |
| 2026-08-04 | [新 Mac 出站不同步：回旧机勿改链路](./2026-08-04-new-mac-outbound-tg-direct.md) | agent-bus,tg,new-mac,dual-mac | bot 活归旧机；新机勿加直推 |
| 2026-09-03 | [Spark 读 dwd 一律 `_r` 空表不报错](./2026-09-03-spark-读dwd一律_r后缀空表不报错.md) | spark,dwd,_r,funnel | bus#7863 |

| 2026-09-03 | OneHR截图勿用openW拉App | onehr,tcc,screenshot | `2026-09-03-OneHR截图勿用openW拉App.md` |
| 2026-09-03 | [大漏斗禁扫超大表须读事件_r](./2026-09-03-大漏斗禁扫超大表须读事件_r.md) | funnel,dwd,_r,sdk_init | bus#7880 |
| 2026-09-05 | [大漏斗沙箱开跑前核集群 SQL 是否定稿 _r 版](./2026-09-05-funnel-沙箱须先核集群-sql-是否定稿-_r-版禁扫-new.md) | funnel,sandbox,hadoop-1 | bus#8006 |
| 2026-09-07 | [指标库 G4/G5 写路径门禁已挂 service + API](./2026-09-07-metric-g4-g5-write-gates.md) | metric-library,G4,G5,write-path,D5 | |
| 2026-09-09 | [新增账号权威源 dim.register_time；app_user.new_users 少算先拆调度](./2026-09-09-new-users-vs-dim-register-authority.md) | datacheck, dim_user_all, dws_app_user_d, new_users | 基准用 dim；落表少先查小时窗+daily OVERWRITE |
| 2026-09-09 | [注册业务日=event_time+两天分区+request_time绝对截止线](./2026-09-09-register-biz-day-event-time-plus-request-cutoff.md) | caliber, register, event_time, request_time | 禁 now()；未开工不改代码 |
| 2026-09-10 | bus-给commit-hash须先确认已在origin | agent-bus, git | 给审核人 hash 前须 origin 可见，禁本地未推 |
| 2026-09-10 | funnel-升维验收须runner-test禁SR手工灌数冒充 | funnel,sandbox,criticism | 升维须 runner test 落库；禁把 SR 手工灌数当已验 |
| 2026-09-10 | [pipeline-runner test四步与test_sandbox铁律](./2026-09-10-pipeline-runner-test四步与test_sandbox铁律.md) | pipeline-runner,sandbox,test_sandbox | 四步+禁动full_chain；--dt=任务日；挂步三件齐 |
| 2026-09-11 | [funnel升维须四方同步且page_view全局过闸](./2026-09-11-funnel-升维须四方同步且page_view全局过闸.md) | funnel,pushback,SR,sandbox | 缺SR/pushback不上线；HAVING禁细粒度 |
