# memory · dev-20260907-001

## 决策

- 保留 is_run 展示语义；计算入围改双 flag
- sync 挂 apply 之后；只升 is_run 不自动置 0
- 旧看板停跑，新看板不在本 session

## 证据

- test PI #74415 · fixture YC-ATTR-V11
- prod 只读 T-1=2026-09-06 入围抽样

## 变更

- 2026-09-07 建 session，推进 1→6
