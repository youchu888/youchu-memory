# 会话记忆 · dev-20260908-001 归因看板

## 当前有效契约（2026-09-09 V1.0.11 口径同步）

- 目标表 `ads.ads_register_attribution_board_d_d`，粒度 `dt + app_id + attributed_channel`；18 列 = 3 维 + 原 13 个计数（E/C/S/H、写回五态、得分四档）+ `etl_batch_id`、`updated_at`。`AGGREGATE KEY(dt, app_id, attributed_channel)`，全部 value 使用 `REPLACE`。比率、产品状态及独立/默认规则分类都在查询侧派生。
- E 逐条件对齐生产 V1.0.11 的 `reg_enroll → reg_base`：注册 `r.dt='$[yyyy-MM-dd-1]'`、organic / natural / self / 空渠道（含 NULL）、`uid IS NOT NULL`、iOS、`r.attribution_flag=1`；INNER JOIN `dwd.dwd_app_install_d i`，同 app / device_id、`i.attribution_flag=1`，双方 device_id 均非 NULL 且 TRIM 非空；安装分区为业务日前 7 天至业务日，安装事件时间为注册前 7 天至后 1 小时。完整 SQL 见 spec §2.5-B。
- 日批严格保留 `PARTITION BY r.event_id ORDER BY i.event_time DESC` 取 `install_rn=1`，不改四键排名或新增并列规则；跨日明细用 `PARTITION BY r.dt, r.event_id`，保留逐注册安装日期 / 事件时间窗。当前展示产品、指定 app 及规则筛选在 rank 后应用。
- `is_run` 不过滤 ETL 入围；当前 `is_run=1` 只用于展示选品。配置变化可改变展示范围，不直接改变已落 ADS 的 E，不新增历史白名单快照或配置冻结。
- 以 E 为驱动按 `dt + app_id + uid + register_event_id` 四键 LEFT JOIN F，一次注册只进入一个原始 F 渠道桶；无 F 或 F 自身渠道为 NULL 时保留 SQL NULL，NULL 与空串分开，不改成 organic / unknown 哨兵，不将产品 E 复制到各渠道。`attributed_channel VARCHAR(64) NULL` 是第三个键，13 个计数口径不变且跨渠道可加。有效候选为 `source_event_id IS NOT NULL AND TRIM(source_event_id)<>''`；仅当 F 同注册日、全部匹配当前 E、候选有效且事件唯一时，C 才等于 F 当日行数。
- 产品数、产品状态及产品级写回状态先按完整查询区间跨天、跨渠道按 app_id 汇总再判定。Top5 读取筛选后 ADS 日渠道行，按原始渠道求区间 S / 写回成功 / H 之和，`HAVING SUM(S)>0` 后按 S 倒序 LIMIT 5，H/S 分母 0 返回 NULL；不再主查 F，也不先取每日 Top5。事件详情仍使用 E / F。
- F 渠道映射限定有效候选子集：先在 F 子查询或 JOIN ON 应用 `source_event_id IS NOT NULL AND TRIM(source_event_id)<>''`，再与 E LEFT JOIN；无有效 F（含防御性的空候选源行）落 NULL 桶，不在关联后的 WHERE 过滤 E。这与当前 18 列 ETL 的 `res` 条件保持一致。
- 默认展示 D-7 至 D-1，不含当天；每次 ETL 一天一分区，使用 `$[yyyy-MM-dd-1]` / `p$[yyyyMMdd-1]`。`INSERT OVERWRITE` 整分区覆盖并清除旧 app 行；输入未变时维度与 13 个计数幂等，执行元数据允许变化，输入变化后不承诺重现旧值。
- 规则仅按应用打分配置分类：当前白名单内，存在自身 `app_id` 且 `is_active=1` 的配置为独立规则，其独立规则 EXISTS 不叠加同一行 `is_run=1`；NOT EXISTS 为默认规则。部分字段回落默认值仍为独立规则，不看时间配置开关。
- 写回五态只在 S 内统计：先按 `rewrite_status=1/0` 分成功/失败；NULL + `未回写-app未灰度` 或 `已有真实渠道-免归因` 为 skipped；NULL + `未回写-归因仍organic` 为 not_writeback；其余 ELSE 为 unknown。保留 unknown 字段和计数，按已保存的字段保守映射，不推断具体原因；本轮不新增比例阈值、前端交互或告警，不将 unknown 作为待确认或阻塞项。
- 质量闭合：`E >= C >= S >= H`，写回五态之和 = S，得分四档之和 = S。上游仍按 90 分线产生 high 且 S 内 `score` 均非空时，在同一 S 口径满足 `score_gte100_cnt <= H <= score_80_99_cnt + score_gte100_cnt`。

当前文件状态：2026-09-09 核对实际 DDL / ETL 已为 18 列且 ETL 已写入 V1.0.11 入围逻辑；DDL 为 `replication_num=3`、16 桶、`start=-9999 / end=3 / history_partition_num=0`。-9999 是有限保留窗口，不是严格无 TTL。本轮只同步文档、只读查询示例及相应测试，不修改实际 SQL / DDL / task.yaml；文件存在不代表测试、部署或数据验收完成。

以下 stage 与核查记录按当时范围保留，旧 17 列、旧 is_run 入围及旧物理参数不是当前有效契约；历史 lint 和样本数量不替代当前版本验收。

## stage 1（2026-09-08）

- 上游注册表用 `dwd.dwd_user_register_d_v2`，**不用** `dwd.dwd_user_register_d`：后者只有 date_key/app_id/channel/uid，无 event_id，撑不起按 register_event_id 去重的 E 口径。
- **已作废的历史方案**：当时以 `dt+app_id+rule_id+rule_snapshot_id` 四维及约 195 字节估计选择 AGGREGATE KEY + REPLACE；之后曾改为两维 17 列，当前正式契约为三维 18 列。原估计与“不能用 PRIMARY KEY”的结论不适用于当前方案。
- 比率一律查询时算，不落表（比率跨天不可再聚合）。既有 dws_register_attribution_metrics_d_d 落了 3 个 DECIMAL 比率列，本表刻意不沿用。
- 平台 bug：`session.write_artifact` 在本 session 返回 ok + 正确字节数但 `local_written=false`，内容 0 字节落盘（spec.md 试了 3 次、memory.md 1 次都是）。经用户授权改为 Bash 直接写会话目录文件。

## stage 2（2026-09-08）· 三个 spec 阻塞项已用上游 ETL 源码查实

- **E 只能取 dwd**：`dws_register_attribution_result_d` 的 ETL 末尾是 `WHERE source_event_id IS NOT NULL`，无候选注册不入结果表，因此 E 必须从 dwd 直算。原记录无条件“C = 结果表行数”已修正为上面的条件等式；源码中的 `no_candidate` 分支在当前最终过滤下不会落入 F。
- **入围条件**：以本文件“当前有效契约”中的完整 reg_base 条件为准，包含 device 的 LOWER/TRIM 归一化。
  既有 `dws_register_attribution_metrics_d_d` 的 E 只写了 `channel='organic'`，渠道范围较窄；比较总数还需对齐其它过滤、业务日、批次及白名单，不能无条件断言两表的大小关系。
- **高置信**：当前上游以 `score>=90` 生成 `confidence_level='high'`；H 还必须限于 S。该等价关系及分数档上下界以源码 90 分线未改变、S 内 `score` 非空为前提。
- **写回五态映射**（分母 S，取自 apply 任务源码）：
  - `rewrite_status=1` → success（reason `已回写-命中<渠道>`）
  - `rewrite_status=0` → failed（计数字段仍为 `rewrite_fail_cnt`；reason `未回写-渠道未变更`）
  - NULL + `未回写-app未灰度` / `已有真实渠道-免归因` → skipped
  - NULL + `未回写-归因仍organic` → not_writeback
  - 其余（含仍是识别阶段值 `organic-待归因` / `自然增长归并organic`）→ unknown，用 ELSE 兜底
  - **已修正的原因说明**：apply 第 3 步 INNER JOIN 用户维表，未匹配行会保留原值，但其初始原因仍可能分到 skipped 或 unknown；已执行的部分分支也可能通过 `COALESCE` 保留旧 reason。unknown 无法单独证明 apply 未跑或未覆盖，不能承诺重跑后消除。
- **已作废的历史规则身份方案**：`rule_version` 是硬编码常量 `'mvp_v2'`；当时提出的 `rule_id` / `rule_snapshot_id` / 配置参数 MD5 均不纳入当前方案，也不再待用户拍板。当前只在查询侧区分独立/默认应用打分配置。
- **既有 developing 家族已登记 prod 调度标识**：`dws_register_attribution_metrics_d_d` 的 task.yaml 登记了 test=22127764280192 / prod=22179046738688（均在 wf_dws_汇总_日），metadata 显示 developing；这些标识不能证明当前任务正在运行，仍需调度及执行日志核实。原有废弃决策与责任约束不变：若要废弃须同窗口处理调度节点；按铁律 §5，那不是本 session 创建的 task，须 owner（又初）处理，AI 不据登记标识执行删除。
- **已被替代的历史 Top5 方案 B**：曾计划看板直查 result 明细；2026-09-09 已改为读取新增渠道维度的 ADS 表，不另建渠道表。2026-09-08 的 T-1 单日明细规模核查仍仅代表当日范围，不能推广为全历史规模或性能验收。

## 生产核查更新（2026-09-08）

- 已确认线上物理主键：DWD `(dt, app_id, event_id)`；F `(dt, app_id, uid, register_event_id)`；用户维表 `(app_id, uid)`；配置表 `(app_id)`。撤销“元数据未登记主键所以线上无主键”及完整主键关联会同键多行放大的猜测，不对约 15 亿行用户维表做全扫重复计数。
- 仍需区分物理复合主键与事件 ID 跨 app 唯一性；保留目标日注册事件跨 app 唯一性、F 完整键和事件唯一性及候选有效性检查。单日通过不代表全历史通过。
- T-1 的 E/F 匹配、写回分类及具体计数见[生产核查报告](/Users/bo/TQ/attribution-dashboard-docs/docs/attribution-dashboard-upstream-check-2026-09-08.md)。当日成功归因全部落 skipped，无 unknown 样本；不能据此验证历史 unknown 的具体成因，也不是 ADS 已上线或调度完成的证据。

## 用户确认（2026-09-08）· 白名单取当前态

- 看板与归因任务一样按 `dim.dim_app_attribution_config` 当前 `is_run=1` 取 app 集合，不要求新增白名单快照或冻结配置。本期 `needs_history_backfill=false`；后续获准重算仍读取执行时当前态，不保证重现历史产品范围。
- 相同条件不代表两次执行读取相同产品集合。归因与看板之间或重算前变更 `is_run`，E、产品范围和状态可能变化；新开启但原归因批次未处理的 app 可能呈现“有入围注册无候选”，不能据此断言历史匹配失败。上游任务未完成仍不能当业务零。
- 幂等校验以注册、归因结果及配置输入均未变化为前提；配置变化后的重算允许与旧数不同。

## stage 3（2026-09-09）· 既有 17 列首版实现记录

以下记录的是同目录已出现的 17 列、`dt + app_id` 实现事实，未同步当前 18 列契约。SQL、DDL、`task.yaml` 和 `.claude` 本轮均保留；历史 lint 记录不等于本次 18 列验证或测试环境上线。

- DDL 物理参数按 design §4 的三个待确认项这样定的：**省略 `dynamic_partition.start`**（StarRocks 默认 Integer.MIN_VALUE = 不删任何历史分区），这样"动态分区预建未来分区"和产品表说明的"无 TTL"两个要求同时满足，不用二选一；桶数取产品表说明的 **16**；`history_partition_num` 不设（本期 needs_history_backfill=false）。
- **没有改用表达式分区**：`INSERT OVERWRITE ... PARTITION (p<昨日>)` 需要目标分区已存在，表达式分区靠写入时自动建，命名分区的 OVERWRITE 首次跑当天会找不到分区。动态分区 `end=3` 提前建 3 天，才能保证命名分区一定存在。上游 result_d / metrics_d_d 也都是这个模式。
- ETL 结构：`elig`（DWD 入围，EXISTS 白名单）→ `res`（当日结果表，显式再限定有效候选）→ `joined`（完整四列键 LEFT JOIN，逐行算出 `rewrite_class` / `score_class` 两个分类列）→ 按 dt+app_id 聚合。分类先算成列再聚合，比在 15 个 SUM 里各写一遍 CASE 更不容易写漏分支。
- `score IS NULL` 的成功行落在 `score_class='sc_null'`，不进四档任何一列 —— 四档之和小于 S 就是质量异常信号，由 playbook 拦截。
- `etl_batch_id` 首版暂写 NULL：design 明确"接入实际发布批次标识，不自行定义批次来源宏"，所以没用 `$[yyyyMMddHHmmss]` 之类自造宏顶替；当前渠道维度与 18 列投影也尚未同步到实际脚本。
- lint 一次过（0 error 0 warning）；首轮 warning 是缺 `-- doc:` 头，已补。

## 渠道粒度更新（2026-09-09）· 仅方案文档

- 本次仅同步 spec / design / playbook / README / 本记录；spec §0 原始需求快照逐字保留。真实 DDL 的 16 桶、动态 `end=3`、不设 `start` / `history_partition_num`、无 TTL 保留，不另选物理参数。
- 同目录真实脚本仍为 17 列；docrepo 的旧 19 列模板是另一份遗留未同步资产，不能与真实脚本混为一谈，也不能把文档更新说成部署完成。
- 2026-09-08 单日抽样：产品日 16 行 → 产品日渠道 113 行（7.0625 倍）；113 = 97 个非 NULL 的产品渠道组合 + 16 个 NULL 桶，97 不是全局渠道数。E=4770、C=257、S=249 跨渠道守恒。证据见 [SQL](/Users/bo/TQ/attribution-dashboard-docs/docs/attribution-channel-grain-expansion-2026-09-09.sql) 与 [Notebook](/Users/bo/TQ/attribution-dashboard-docs/docs/attribution-channel-grain-expansion-2026-09-09.ipynb)；单日样本不推定未来规模或性能。
- 项目 AGENTS.md 已读；其引用的 `.cursor/rules/task-intake.mdc` 缺失，目标目录及 ops_system / 05.ads 没有更深 AGENTS.md。本轮按用户明确授权的文档范围推进，没有执行数据库、调度或 Git 写入。

## stage 3 重写（2026-09-09）· 入围口径对齐生产 V1.0.11

- **本地仓库文件不是线上版本**。`ops_system/04.dws/.../dws_register_attribution_result_d.sql` 与生产任务差异很大，按它写 ETL 会错。以后写下游必须用 `dolphin.get_task_sql` 拉线上版，不能只看仓库文件。
- 生产 V1.0.11（prod 2026-09-08 09:09:45 发布，session dev-20260907-001）的入围口径：
  - `INNER JOIN dwd.dwd_app_install_d ON app_id + device_id AND i.attribution_flag=1`，安装窗 = 注册前 7 天 ~ 注册后 1 小时，`ROW_NUMBER() PARTITION BY r.event_id ORDER BY i.event_time DESC` 取 1 防扇出
  - **不再用 is_run 过滤入围**；is_run 改由日批末 `dim_app_attribution_config_is_run_sync_d` 回写，仅供前端展示
  - 阈值三级兜底 `COALESCE(bc_s, bc_d, 40)`，打分项也都有硬兜底 → 「阈值 NULL 导致成功但渠道为空」在这版不成立
- **口径切换时间线**（用 created_at 实测）：dt≤2026-09-07 写于发布前，是旧口径；**dt=2026-09-08 起是新口径**（09-09 05:25 写入）。09-08 产品数从 8~9 掉到 6、F 行数 333→257，就是安装 join 收紧的效果。跨这个日期做对账必须分段。
- 渠道桶的结构性质：`attributed_channel` 非 NULL ⟺ 归因成功（实查 09-01~09-08：真实渠道桶 2377 行全 success，NULL 桶 451 行全 unattributed，空串 0 行）。所以**非 NULL 桶内 E=C=S 恒等**，按渠道算候选覆盖率/成功率没有意义。
- 但 `LOWER(c.channel) != 'organic'` 没有 TRIM，`' organic '` 能通过候选筛选 → 不能声称 organic 绝不出现（空串那半条成立，因为有 `TRIM(c.channel) != ''`）。
- **prod 项目码**：铁律文档写的 `20524837077760` 是过期值，实际运营系统 prod = `171982119739200`；prod wf_dws_汇总_日 = `174729604091712`。用错会搜出 0 条、误判成任务不存在。
- test 里有**三个 ONLINE 工作流**都含 `dws_register_attribution_result_d`（wf_dws_汇总_日 / wf_归因计算回写_日 / wf_归因落地页快路_日），都写同一张表；prod 只有一个。是否互相覆盖待查。
- `dolphin.list_schedules` 对 test 运营系统项目返回 HTTP 500，暂不可用。

## 当前证据边界补充（2026-09-09）

- `created_at` 或当前 SQL 不能独立证明历史分区实际执行版本；上文“dt≤2026-09-07 / dt=2026-09-08”切换分段及下降原因属于历史判断，不作为本轮已核实的验收依据。核对历史版本须结合对应实例、任务定义版本及写入记录。
- 本轮已核实 test 旧快路 00:10 执行后，新版 05:20 在同一数据源 1 覆盖 `p20260908`，存在实际覆盖；三个 ONLINE 工作流不等于三个 schedule 都在线，需分别核对定时状态及实际实例。
- 两份海豚规则文档及 DC Platform 公共记忆的过期环境码已修正并验证；上述过期码问题保留为历史记录，后续仍须在目标 env 按名称实时解析项目、wf、task code。

## Stage 3 本地保存（2026-09-10）

- 用户明确允许在本会话目录直接保存必要修订：DC Platform `session.write_artifact` 返回 `local_written=false`，磁盘未更新；`session.get` 的工件内容为空，不能据此覆盖本地文件。本次使用 apply_patch，只改本会话工件，不修改平台 / 插件。
- DDL 去掉 13 个计数列的 DEFAULT，由 ETL 显式写计数；修正 `start=-9999` 为有限保留窗口、NULL 渠道为原始未分配桶的注释。18 列、三键、REPLACE、3 副本、16 桶及全部分区参数不变。
- design 的单一列级血缘表补到 53 行，覆盖全部 18 列及关键条件。同步 spec / README / playbook；spec §0、现有 ETL 和 task.yaml 原样保留，既有记忆只追加不重写。
- 本会话已向 `metric_pending` 提交 13 个存储指标、3 个 derived 比率及 13 个 code 字段绑定，均待审核；`dt` / `app_id` 标准复用，`attributed_channel` 暂无可用标准，不替换成语义不明的 channel。
- 当前校验：18 列及投影一致性、53 行血缘覆盖 / 源列有效性检查通过；33 项查询文档内存测试重新通过；session.lint 0 错误、0 警告。详见 playbook 的 Stage 3 验证记录。
- 目标数据库验收未完成：本会话上次 test SHOW CREATE TABLE 连接超时。本次未建表、未跑数、未发布、未提交 Git；Stage 4 的测试面板仍需用户人工打开并确认。
- 本次另直接执行真实 ETL 的 SELECT 部分（仅日期宏 / 函数适配），在既有独立内存样本中验证 9 条入围事件、6 个渠道桶及全部 13 个计数；未运行 StarRocks 写入。
- 平台阶段状态未完成：本地保存及规格 / 质量复核通过后，`session.set_stage_status(stage=3,status=done)` 被守卫拒绝，原因是 rel_dir 下没有 Git tracked 文件。未按错误提示擅自改目录、git pull、暂存或提交；当前 Stage 3 仍为 in_progress，既有 Stage 4 标记未改。下一步需用户决定是否将本会话工件纳入 Git 跟踪后重试。

## Stage 3 复核（2026-09-10 第二轮，AI 只读核查）

- **test 目标表已存在且结构正确**（补上次超时未完成的核查）：`information_schema` 实查 `ads.ads_register_attribution_board_d_d` = 18 列，`column_key=AGG` 落在 `dt` / `app_id` / `attributed_channel` 三列，`attributed_channel` 可空。与会话 DDL 完全一致，不存在 spec 验收 #14 担心的「旧 17 列两键表」。`state.outputs[0].prod_table_built=false`，prod 未建。
- **上游 25 个引用字段全部存在、类型兼容**（test 实查）：`dwd_user_register_d_v2` 9 列 / `dwd_app_install_d` 5 列 / `dws_register_attribution_result_d` 11 列。注意 `score` 是 INT、`rewrite_status` 是 TINYINT，四档与 1/0 判定不需要额外 CAST。
- 🔴 **T-1 分区不存在，stage 4 首跑必挂**：`SHOW PARTITIONS` 实查只有 `p20260910` / `p20260911` / `p20260912` / `p20260913`（今天 + 3），**没有 `p20260909`**。ETL 写入的是昨日分区 → 会报分区不存在。
  - 根因：`dynamic_partition.end=3` 只预建**未来**分区；`history_partition_num=0` 表示**不建任何历史分区**。本会话记忆早前那条「end=3 提前建 3 天，才能保证命名分区一定存在」只对未来成立，**对 T-1 不成立**，该结论需修正。
  - 稳态下 T-1 分区是「昨天作为今天」时被建出来的，所以只有建表首日（本表 2026-09-10 11:20 建）以及调度漏跑那天会缺；但缺一次就整任务挂。
  - 两条修法：① DDL 加 `"dynamic_partition.history_partition_num" = "3"`（官方语义：建表时预建 N 个历史分区，今天 09-10 会得到 p20260907~p20260913，覆盖 T-1，且对漏跑有冗余）；② 保持 DDL 不变，首跑前手工 ADD PARTITION 补 p20260909。选哪条由用户拍板，AI 未擅自改 DDL。
- 静态检查全过：`session.lint` ok=true / 0 error / 0 warning；ETL 与 DDL 注释内均无占位符字面量；ETL 单 statement（1 个分号）；INSERT 带显式 18 列清单（前向兼容）；`GROUP BY` 覆盖全部非聚合列；驱动表是 `elig`（保证 E>0 且 C=0 的产品不丢行）。
- 时间正确性复核：注册 / 结果都取业务日 T-1 宏，安装窗上下界都是 DATETIME 表达式（`DATE_SUB(r.event_time, ...)`），不存在 DATETIME 列 BETWEEN 日期字面量的截断漏数；全程无正方向偏移。
- 指标绑定后端查不到：`metric.search('eligible_register_cnt')` 与 `metric.bindings_for_table('ads','ads_register_attribution_board_d_d')` 均返回 0 条。与「已提交 metric_pending 待审」自洽（pending 不进这两个查询），但 stage 7 同步指标 / 血缘前须确认审核已推。
- 平台侧两个已知故障复现：`session.get` 返回的 `files` 全部为空串（工件实际在磁盘且非空）；`session.write_artifact` 历史返回 `local_written=false`。均为平台问题，AI 不改平台源码，留给用户处理。
- 阻塞项延续：`session.set_stage_status(3,'done')` 上次被守卫拒（rel_dir 下无 Git tracked 文件）。是否把本会话工件纳入 Git 跟踪仍待用户决定。
- **用户拍板（2026-09-10）：采用方案 ①**，DDL `dynamic_partition.history_partition_num` 由 0 改为 3，并同步 design §2.1 / §4、README、playbook 的对应描述。定位为**写入可用性配置，不是历史补数**，`needs_history_backfill=false` 不变。
- 遗留：test 库那张表是 2026-09-10 11:20 用旧参数（history_partition_num=0）建的，改 DDL 文件**不会**升级已存在的表 —— `CREATE TABLE IF NOT EXISTS` 不改既有配置。要让 test 表生效必须 `ALTER TABLE ads.ads_register_attribution_board_d_d SET ("dynamic_partition.history_partition_num" = "3")`，改完再 `SHOW PARTITIONS` 确认 T-1 分区已出现；没出现就手工 ADD PARTITION 补一次。该 ALTER 属于动目标库，留到 stage 4 由用户在测试面板拍板执行。
