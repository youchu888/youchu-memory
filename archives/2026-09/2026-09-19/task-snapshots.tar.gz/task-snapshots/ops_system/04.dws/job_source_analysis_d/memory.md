# memory · dev-20260825-001

- 2026-08-25 建需求；**3 DWS + 1 ADS**：retention / active / ltv / ads_metric
- 过滤 `platform=web`；关联 `device_fingerprint`
- **野花 08-25 定：本期只做账号，设备切换不做**（PRD P0 设备维本期砍掉）
- test task：retention `22812731291648` · active `22812799937152` · ltv `22812733678976` · ads `22812733988864`
- prod：本需求不做
- 2026-08-25 ⑨：搜索引擎仅 Google/Yandex/社交/baidu/Bing；**取消 search_other**


- 2026-08-26：弃用父+子（dev-20260826-001~005），恢复合表单需求 `dev-20260826-010`。


- 2026-08-26 stage1：合表 `dev-20260826-010` 重走 1-7；spec §1-5 对齐 3DWS+1ADS（含独立 active）；§0 原文保留。


- 2026-08-26 stage2：合表 design+playbook；四表字典 34/6/38/43；不拆父子；表名沿用 `_d`。


- 2026-08-26 stage3：四表 DDL/ETL 与 design 字典对齐核对；task.yaml 指向本 session；不拆子。


- 2026-08-26 stage4 Part A：四表 ETL 双跑幂等通过；playbook CP1–4 过；等面板三勾后再发海豚 task。

- 2026-08-26 stage4 Part B：面板三勾完成；test 新建 task retention `22825605329408` / active `22825605777280` / ltv `22825606218496` / ads `22825606645120`；TASK_ONLY 跑通（PI 71177/71179）；T-1 25 行对齐；已推进 stage 5。

- 2026-08-26 stage5：prod readonly 查 — **缺** `dwd_sdk_init_d`、注册表 **无** `device_fingerprint`、四目标表未建；ETL dry-run 无法跑。stage5 未过；stage6/7 等上游发产令。

- 2026-08-26 野花令：上游已发产 — prod 注册表 `device_fingerprint` AFTER `device_id`；`dwd_sdk_init_d` 建表+挂日批 `182606503682176`；T-1 complement PI=33398 SUCCESS。可重跑 stage5。

- 2026-08-26 stage5 重跑：上游 OK；三 DWS INSERT→SELECT dry-run T-1 各 626 行 / new=1,989,473 / channel_user=0 / dup=0；目标表+ADS 未建属预期偏差。**Stage5 通过（发产前口径）**；等 OK → stage6。

- 2026-08-26 stage6：prod 四表已建；task retention `182607351643264` / active `182607354195072` / ltv `182607357568128` / ads `182607360159872`；T-1 PI 33399+33401；626 行对齐。stage6 收口中（commit）。
