## Stage4 Part B（2026-09-16）

- publish test：`v327→v328` OK（`new_sql`）
- complement TASK_ONLY schedule `2026-09-16 07:25:00` pt=`20260915`
- PI76907 / PI76908 SUCCESS；task TI226325 SUCCESS
- 验数：09-13 day3 PDR843=MV843；09-09 day7 PDR496=MV496
- stage4=`done`

## Stage5（2026-09-16 · prod 只读 dry-run）

- CP-R1 prod SQL 仍旧窗口（无 pt-2/6）· 预期 fail
- dry-run MV：09-13 d3=**284196**；09-09 d7=**135353**
- live PDR 两天仍 NULL
- CP-R4 day1 09-14：346850=346850 PASS
- 总评 dry-run **PASS**；live 止血待 stage7
- stage5 实检完成，等 OK 推 stage6
