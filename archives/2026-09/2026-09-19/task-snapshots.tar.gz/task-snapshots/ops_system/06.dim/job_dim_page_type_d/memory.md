# memory · dim_app_page_all create_time

- **Stage1 DONE 2026-09-17**：实检 spec（字段字典/方案A/不新建task）+ test/prod binding 对齐 `dim_app_page_all.sql`；标 done，Stage2 in_progress。
- **Stage2 DONE 2026-09-17**：实检 design vs 现网（test 已有 create_time；prod 无）；补「先 ALTER 再发 ETL」顺序；Stage3 in_progress。
- **Stage3 DONE 2026-09-17**：lint 0 error；DDL/ALTER/ETL col_list+COALESCE 三处对齐；test 海豚 live SQL=仓库；Stage4 in_progress。
- **Stage4 DONE 2026-09-17**：复检 DESC/计数/幂等；PI77288+77289；写入 stage4_db_check；Stage5 in_progress。
- **Stage5 DONE 2026-09-17**：prod 只读复检（无 create_time；T-1 557742/已在维表=全；旧 SQL）；写 stage5_prod_dryrun；Stage6 in_progress。

- 2026-09-17：知秋要求绑定+代码升级，不新建 task。方案 A 存量。
- test binding 已有；prod binding 本轮补上。
- 2026-09-17 test ALTER OK：`create_time` 已加；`cnt=119854` 全非空；min=max=`2026-09-17 16:46:33`（方案 A 加列时刻）。
- 2026-09-17 test：publish v32→v33；complement `PI77288`/`PI77289` 双枪 SUCCESS（dt=2026-09-16）。
- 幂等：两枪后 create_time 仍全是加列时刻 `2026-09-17 16:46:33`（newer=0）；T-1 页面 16429 全已在 dim（new_only=0），COALESCE 路径已验。
- 2026-09-17 prod dry-run（只读）：表尚无 create_time；dim≈237万/1030 app；T-1=`2026-09-16` 页面 557742，已在 dim=557742，**would_be_new=0**；prod 海豚仍旧 SQL（无 COALESCE）。未 ALTER/未发产。
- 下一手：git commit/push → request-publish → prod ALTER+发版。
