# memory · dwd_sdk_init_d

- 2026-08-22：来源分析开工。狂人 bus#6991 拍板 v1 最小集 ~35 列、1 表宽表、event_id 去重（request_time 最早）、不落 payload/*_o。
- 硬伤：PK(dt,app_id,event_id) 现网 08-20 约 1.5% 重复，必须显式 ROW_NUMBER 去重。
- 口径修正：来源 web 判 `platform='web'`，**禁止** DWS 用 `device='PC'`（会丢 Android H5 ~76%）。
- `dwd_user_register_d_v2` 加 `device_fingerprint`：仓库 DDL/日+小时 ETL 已改（AFTER `device_id`）；**test 已 ALTER**。
- 2026-08-22：test 冒烟 dt=2026-08-21：源 31,166,773 → dwd 30,677,927（去重 1.57%）；PK 唯一；platform=web 26.18M 行 referer 非空 21.66M。
- 2026-08-22：test 挂海豚 wf_dwd_事件明细_日 task_code=22778484085888（after dwd_app_install_d）；publish v337→v338。
- 2026-08-26 野花令 prod：
  - 注册表 `ADD COLUMN device_fingerprint ... AFTER device_id`（ordinal 11，与 test 一致，非表尾）
  - `CREATE TABLE dwd.dwd_sdk_init_d`（35 列）
  - 注册日/小时 SQL 发产（日 wf v325→326 task `174729506942789`；小时 wf v57→58 task `174729503687488`）
  - 新建 prod task `dwd_sdk_init_d`=`182606503682176`（after install）；complement PI=33398 两 task SUCCESS
