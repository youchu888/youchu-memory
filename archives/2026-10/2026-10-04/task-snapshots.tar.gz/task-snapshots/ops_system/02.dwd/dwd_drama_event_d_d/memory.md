# 短剧日报｜剧集行为明细表加工 — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 但又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-09-18
- 会话 dev-20260918-001 创建
- [stage1 review] 目标 dt = 事件发生日 DATE(event_time)，不直接取上游 dt；上游 dt 口径、扫描分区范围、迟到处理放 stage 2 验证
- [stage1 review] 唯一键 (dt, app_id, event_id)，对账用同一组合键；DUPLICATE KEY 不去重，由 ETL ROW_NUMBER 排重
- [stage1 review] play_speed 按埋点文档为 实际倍速×100 的 INT（1.25 倍 = 125），DWD 原样保留不换算
- [stage1 review] 补字段 drama_content_type，取值 short_drama
- [stage1 review] app_id / event_id / event_time 空 → 不入表计异常量；对账拆成 有效入表量 + 异常量 + 重复量；drama_id 非空率阈值按近 7 天基线定
- [stage1 review] 完播依据完成标记或进度；drama_duration 用于有效播放判断，不是完播分母；uid 只说明用于账号去重，不限定 bitmap 实现
- [stage1 review2] 迟到不能只靠扩大扫描分区；T-1 分区跑完后仍可能进数，stage 2 必须定完成信号或历史业务日回刷（窗口 M 待定）
- [stage1 review2] 对账两层：扫描分区级（全部记录 = 有效 + 各类异常单列，含 event_time 缺失这类无法归日的）；业务日级（有效记录 = 目标行数 + 重复量）；app_id 缺失单列
- [stage1 review2] 幂等限定为相同上游快照 + 相同参数下重跑结果一致
- [stage2] 表模型改为 PRIMARY KEY(dt, app_id, event_id)（跟 dwd_comic_event_d 一致；平台规范 DUPLICATE 不做 ETL 目标），仍用 ROW_NUMBER 固定去重排序
- [stage2] 迟到方案：每日一条 INSERT OVERWRITE 覆盖 T-2、T-1 两个分区；业务日 D 只收上游接收分区 [D, D+2]；超前 / 超窗记异常。依据：兄弟表 video/comic 都扫 dt IN (T-1, T)，说明上游 dt 是接收日而非事件日（待 P10 实测确认）
- [stage2] 上游是实时入湖，海豚内无上游任务可 DEPENDENT；task 挂 wf_dwd_事件明细_日（03:25）独立节点 pre=0
- [stage2] DB（sr_prod / sr_test）连接超时，payload 键名、迟到分布、非空率基线均未实测，已列为 playbook P0 / P9 / P10 上线前关卡
- [stage2 review] 截止口径改为按入库时间 create_time：业务日 D 收 create_time < D+2 00:00 的记录；D+2 03:25 终产（3h25m 可见缓冲，P10 验证）；截止线后入库记「超窗迟到」。入表规则、终产时刻、异常判定用同一条线（取代上一版"上游分区 [D, D+2]"方案）
- [stage2 review] 补数：入表集合只由固定截止线决定，已过截止线的分区重算逐行一致，日常补数不会把相邻完整分区覆盖成不完整；另提供单日补数脚本 _backfill.sql 只覆盖指定业务日（不能用返回空集的方式拦截，OVERWRITE 空集会清空分区）
- [stage2 review] ID（uid/sid/device_id/drama_id/video_id/media_id 等）和展示文本一律不截断，非主键字符串列 VARCHAR(65533)，保持严格模式，超长直接报错；主键 app_id(50)/event_id(64) 超长记异常
- [stage2 review] 去重决胜：request_time → create_time → 上游 dt → 38 个输出列拼接串，保证同快照结果唯一确定；P11 监控同键不同内容的冲突重复
- [stage2 review] 已有埋点文档（截图），OM 配置及清洗后实际数据尚待核验；异常分 7 类（新增 create_time 缺失、分区越界）
- [stage2 review2] 终产改为上游水位门禁：W ≥ C(D)+δ（δ=30min）才终产；W 首选上游入湖作业的已提交水位（待与上游确认），无则用代理判据（全事件最新 create_time ≥ C(D)+δ 且每个活跃 app 最新 create_time ≥ C(D)）并记录取舍；新增前置任务 dwd_drama_event_d_d_wm_check（失败重试 12 次 × 30 分钟）；P13 终产 7 天后审计残余风险。"两次计数相同"不能证明可见
- [stage2 review2] 迟到窗口 L 改为待验证参数（初始提案 2）：P9 按 L=1/2/3/7、按 app 统计超窗损失率，需求方确认可接受损失率和终产时点后取最小 L；未定值不发布；不默认丢弃合法迟到事件
- [stage2 review2] 去重决胜改为全部 38 个输出列逐列 ASC NULLS FIRST 排序，不再用拼接串（避免分隔符串值、NULL 标记撞值）
- [stage2 review3] 扫描范围由 L 统一推导：目标日 [S-L, S-1] 各自允许 [D-1, D+L]，并集 [S-L-1, S+L-1]（之前写死 S+1 只在 L=2 时正确）
- [stage2 review3] 历史补数统一走单日补数脚本，按该日自己的截止线 C(D) 检查水位；日常 task 的海豚补数只用于补跑最近失败的调度，且仅在 W ≥ C(S-1)+δ 时才保证不降级
- [stage2 review3] 水位来源优先级：上游已提交水位 > 上游消费/提交进度 > 代理判据（仅共享链路全事件最新 create_time）；不按单个 app 有无新数据阻塞或排除；独立通道无进度时照常终产、标「未证实完整」并强制 P13；采用代理判据需用户确认
- [stage2 通过] 用户复核 v4 通过，可进入 SQL 实现和测试，但不能认定可上线。上线前置：OM 字段核验（P0）、L 与损失率确认（P9 + 需求方）、水位来源（上游确认）、门禁失败时确实阻止写入（stage 4 必测）。若采用代理判据，「终产」仅表示本轮计算结束，不对下游承诺完整
- [stage3] 上游 OM 长度：app_id / event_id 均 VARCHAR(64)；主键取 app_id(50)+event_id(64) 以守住 PK 128 字节，app_id 51–64 字节会计入 E3，P0 加 app_id 最大长度检查
- [stage3] 平台 lint 把正则里的单独 ? 判为非法占位符，改用 {0,1}；注释里的 03:25 这类「冒号+字符」也避免（可能被当 :name）
- [stage3] 水位门禁失败机制：标量子查询条件不满足时返回 2 行让 SR 报错（未找到 SR assert_true 文档）；stage 4 必测条件为假时确实失败、主任务不执行
- [stage3] 单日补数脚本不用自定义参数：以调度日期 D+1 启动，T-1 宏即 D；血缘 source_fqn 按平台约定写 event:drama_event
- [stage3 review] 补分区初始化脚本 _init.sql（手工、多语句、不进海豚）：先关动态分区→逐日 ADD PARTITION IF NOT EXISTS→恢复；DDL 改 history_partition_num=3；执行顺序 建表→init→SHOW PARTITIONS→首跑
- [stage3 review] 补数不能复用日常门禁（以 S=D+1 启动时日常门禁查 S 00:30，早一天放行）；新增 _backfill_wm_check.sql 查 S+1 00:30 = D+2 00:30；补数工作流无定时调度，检查→写入，只能整体启动
- [stage3 通过] 2026-09-19 用户基于磁盘当前版本复核通过（上一轮引用了旧文件，已撤销）。stage 4 必测：DDL 与 init 实际执行、ADD PARTITION IF NOT EXISTS 与动态分区开关行为、两个门禁条件为假时报错并阻断写入、严格模式默认值、宏渲染日期与分区名、补数工作流按日期串行时的调度日期取值

## 2026-09-19
- [stage3 收尾] 会话目录由用户改到 ops_system/02.dwd/dwd_drama_event_d_d（平台要求 rel_dir 至少 2 段），stage 3 标 done
- [stage4 阻塞·上游] **test / prod 均无 event = 'drama_event'**：test 全历史 0 条，prod 近期 0 条，两库自 2026-06-01 起无任何 drama / episode 命名事件；上游链路正常（51 种事件持续入库，最新 create_time 即当前时刻）。test 2026-09-18 有 6 条 TJ-084 联调数据，报在 video_event（video_content_type=OTHER）下带 drama_* 字段、行为字段为 video_behavior_key、时长为 video_duration、无 play_speed
- [stage4 决策] 按埋点文档继续用 drama_event + play_behavior_key + drama_duration，**不**因 6 条联调数据改口径；需上游确认事件登记 / 清洗链路是否已推 test
- [stage4 Part A 技术验证 2026-09-19，sr_test 3.4.10] 建表成功；history_partition_num=3 自动建 p20260916…p20260922（3 天历史+当天+3 天未来），建表后 3 天内首跑不需 init；enable_insert_strict 默认 true；主 ETL 执行成功但 affected_rows=0；门禁放行（gate=NULL）与拦截（Expected LE 1 to be returned by expression : BE:11004）均实测通过
- [stage4 未验收] 无数据 → P0–P13 全部未验证；「ETL 全过」不据此勾选（覆盖写入下"成功"≠"数据正确"）。项目催进度时可先部署，但不得把未验证项标成通过

- [2026-09-19 范围最终确认] 用户要求只保留主加工 ETL；两个水位检查和独立补数脚本已删除。历史 design/playbook 中的门禁与补数方案不再生效，当前权威为重写后的 spec、design、playbook 与 outputs。init 仅在分区缺失时手工使用，不进海豚。
