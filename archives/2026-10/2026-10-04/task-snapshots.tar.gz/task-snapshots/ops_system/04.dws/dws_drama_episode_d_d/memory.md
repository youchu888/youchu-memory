# 会话记忆

- 2026-09-19：用户明确本期 DWS 是 StarRocks 实现，先不管 Spark。
- 四张 SR DWD 分别聚合，按 dt、app_id、drama_id、video_id 取键并集。
- 有效播放采用四条件 OR；观看按 sid，观看账号按 uid；点赞取消扣减且可为负。
- department_name 必须保留，但当前只有 dept_code，没有权威名称配置；本期写 NULL。
- 目标使用日分区 INSERT OVERWRITE 保证重跑幂等。
- 上游 drama_id、video_id 为 VARCHAR(65533)，目标以 STRING 保存，不截断。
- 2026-09-19：Stage 4 已在 sr_test 建表并由海豚 task 23089408486784 实跑成功；因四张 DWD 和清洗原始表均无四类事件，结果为 0 行，真实口径未验收。
- 2026-09-19：Stage 5 的 sr_prod 只读检查发现四张短剧 DWD 和 DWS 目标表均不存在，原始四类事件也为 0；生产对象与数据就绪后必须重跑 Stage 5。
- test DWS 任务当前为工作流内并行节点；平台未提供创建跨工作流 DEPENDENT 节点的可用接口，提交 review 前仍需补四张 DWD 的真实调度依赖。
