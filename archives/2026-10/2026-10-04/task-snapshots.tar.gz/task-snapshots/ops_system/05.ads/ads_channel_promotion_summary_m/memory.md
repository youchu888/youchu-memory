# memory · 【渠道推广月汇总】ads_channel_promotion_summary_m

- session: `dev-20260929-002`
- 部门：只认 `dim.dim_channel_info_all`，禁止 `dim_app_info_all.dept_code`
- 口径与周表共用；海豚 task `23209697504256`
- stage4 PASS（ret_sum≈45200）；stage5 同周表 WARN；stage6 待 commit
