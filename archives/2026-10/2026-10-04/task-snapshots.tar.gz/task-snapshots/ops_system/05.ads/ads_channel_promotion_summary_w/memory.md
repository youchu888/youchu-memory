# memory · 【渠道推广周汇总】ads_channel_promotion_summary_w

- session: `dev-20260929-001`
- 部门：只认 `dim.dim_channel_info_all`，禁止 `dim_app_info_all.dept_code`
- test：表已建；海豚挂 `wf_ads_日报表_日` task `23209697185664`
- 次留：`LEAST` 右侧必须 `DATE(DATE_SUB(...))`；周一 biz 次留可为 0，验收用周中 schedule
- stage4 PASS（80861）；stage5：prod 无目标表 + 无渠道维表（WARN）；stage6 待 commit
