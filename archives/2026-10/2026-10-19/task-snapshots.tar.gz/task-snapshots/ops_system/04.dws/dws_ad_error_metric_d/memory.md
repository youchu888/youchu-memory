# 【广告错误次数】dws_ad_error_metric_d — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 但又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-10-16
- 会话 dev-20261016-023 创建

## 2026-10-17
- 口径基准：生产海豚 dwd_ad_error_d（task 180032067758208）行过滤 event_id 非空、app_id 非空且 <> '-'，fanout 写 _r 没有，Spark 必须补
- 现网 dwd 对 ad_slot_key/ad_id/error_code/error_stage/trace_id 有 LEFT 截断；实测 _r 10-01～10-17 最长 42/39/19/7/91 字节，未触及，本表不截断，只保留 ad_id 截 32
- 预比：生产 SR 用同逻辑读 paimon _r，10-13（2,628 行）、10-15（2,933 行）与正式表逐行全等
- 调度：独立新线 ad_error_daily，04 槽，探 dwd.dwd_ad_error_d_r（水位实时）；不并入广告请求线，避免改其入口钩子
- 指标 ad_error_cnt 已提案（pending），代码绑定 paimon 表 error_cnt
