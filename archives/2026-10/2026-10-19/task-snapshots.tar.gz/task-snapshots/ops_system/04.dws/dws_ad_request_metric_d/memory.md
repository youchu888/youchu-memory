# 【广告请求次数】dws_ad_request_metric_d — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 但又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-10-16
- 会话 dev-20261016-022 创建
- 目录定为 `ops_system/04.dws/dws_ad_request_metric_d/`（建会话时表名为空，插件落到了仓库根 `pending/`，已迁走删除）
- time_basis=event、迟到等待 3 小时（D+1 分区精确封口 request_time < D+1 03:25:00），与现网 dwd 日覆盖封口一致
- 首版回写 SR 影子表 `dws.dws_ad_request_metric_d_paimon_shadow`；正式表仍归海豚 task 180032172673152，对平 + 知秋审批后同一动作切换并停海豚
- 对账以现网生产版广告事件 dwd 口径为准（`job_dwd_ad_sdk_event_split_d` 本地改动未上线）
- 踩坑：fanout 写 `dwd_ad_request_d_r` 只按事件过滤，缺现网 dwd 的 event_id 非空、app_id 非空且 <> '-' 过滤，Spark 必须自己补
- 预比：生产 SR 用同逻辑读 paimon `_r`，10-13（1,312 行）、10-15（1,371 行）与正式表逐行全等
- 指标 ad_request_cnt 已提案（pending），绑定到 dws / paimon 两张表的 request_cnt
