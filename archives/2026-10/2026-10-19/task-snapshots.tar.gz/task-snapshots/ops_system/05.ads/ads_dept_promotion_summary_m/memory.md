# memory · 【部门推广月汇总】ads_dept_promotion_summary_m

- session: `dev-20261013-003`
- 父会话: `dev-20260929-002`（需求与设计在渠道月表目录）
- 粒度: `month_start_dt` × `dept_id`
- 新增: 产品内注册用户去重后，部门内按产品相加
- 充值: `SUM(revenue_total)`，单位分
- test 已建表；海豚 task `23353810189312`，上游 `ads_channel_metrics_daily_d`，工作流 `wf_ads_日报表_日`
- test 补数 pi 84552 SUCCESS（业务日 2026-10-12）：month_start=2026-10-01 一行 dept 41，新增 0、充值 0，与命中日表一致
