# memory · 【产品推广周汇总】ads_product_promotion_summary_w

- session: `dev-20261013-002`
- 父会话: `dev-20260929-001`（需求与设计在渠道周表目录）
- 粒度: `week_start_dt` × `app_id`
- 新增: 产品内渠道注册用户去重
- 充值: `SUM(revenue_total)`，单位分
- test 已建表；海豚 task `23353810594048`，上游 `ads_channel_metrics_daily_d`，工作流 `wf_ads_日报表_日`
- test 补数 pi 84552 SUCCESS（业务日 2026-10-12）：176 行，新增 105197，充值 31203800 分，与日表按产品对上
