# memory · 【部门推广周汇总】ads_dept_promotion_summary_w

- session: `dev-20261013-001`
- 父会话: `dev-20260929-001`（需求与设计在渠道周表目录）
- 粒度: `week_start_dt` × `dept_id`
- 新增: 产品内注册用户去重后，部门内按产品相加
- 充值: `SUM(revenue_total)`，单位分
- test 已建表；海豚 task `23353809922176`，上游 `ads_channel_metrics_daily_d`，工作流 `wf_ads_日报表_日`
- test 补数 pi 84552 SUCCESS（schedule 2026-10-13，业务日 2026-10-12）：分区 0 行，当日渠道与维表无交集
