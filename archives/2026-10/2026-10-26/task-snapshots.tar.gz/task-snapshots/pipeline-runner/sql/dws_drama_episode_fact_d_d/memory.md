# 剧集｜Paimon｜单片日事实 — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 但又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-10-20
- 会话 dev-20261020-006 创建

## 2026-10-21 欧阳最新口径及知秋评审修订

来源：用户在本会话转述欧阳“1按照知秋的来”“阿莱士说按照集数走了，回看不算，就算实际看到的集数”，随后明确授权落实五项评审意见。聊天原文未给出欧阳这两句的具体时分，不补造时间。

本条覆盖旧的“同SID同剧多集算1”和“点击回看追加观看集次”。观看次数统一按app_id＋drama_id＋SID＋video_id去重，分析与排行均使用bm_episode_watch_dsv并集基数。同SID同剧看三集计3，同SID同集重复上报计1，换SID会新增观看次数。有效观看四条件OR不变。

人均观看集数按各账号实际有效观看过的不同剧＋集计数，分子不包含回看操作次数、不包含SID，也不受首次回看先后影响；设备版对应device_id。同人不同SID反复看同集只贡献1，先回看后有效观看正常贡献1，只有回看而未有效观看贡献0。分母仍为有效观看账号/设备并集，零分母沿原契约返回0；无UID不补造账号。单集键沿既有全日原始集号及唯一映射/视频回退，不能改用展示维表赢家。

原episode_base_account_count/device_count重算为每mask属性范围内去重观看集数的标量校验量。增加bm_watched_episode_u/d（只追加两列，64→66），保存账号/设备＋剧＋episode_key集合，跨属性桶/跨SID以并集计算人均分子，禁止简单SUM这些标量当成任意多选后的去重集数。回看次数、回看人数及其他独立指标仍保留，旧bm_watch_s/ds不删除或悄悄改义。新集合历史NULL表示尚未回刷，不能当空集合0放行。

消费公式：观看次数=BITMAP_UNION_COUNT(bm_episode_watch_dsv)。账号人均观看集数=BITMAP_UNION_COUNT(bm_watched_episode_u)/BITMAP_UNION_COUNT(bm_viewer_u)，设备对应d；读取前须确认所选范围新集合均非NULL。分析仍先产每日结果，底部合计/平均按每日规则；排行周月先合并周期集合再取基数，不SUM每日去重人数。

本次另外落实：006显式SET spark.sql.optimizer.runtime.bloomFilter.enabled = false；跳出两集合统一TRIM(video_id)判空。调度仅做插件容量估算，不自动改生产槽位、审核状态或发布申请。旧验收回执不代表本版66列已经通过，必须重新做本地与test验证，最终审核由用户提交。
