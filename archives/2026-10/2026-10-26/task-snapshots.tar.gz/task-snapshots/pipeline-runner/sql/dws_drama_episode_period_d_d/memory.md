# 单集周期详情会话备忘录

## 2026-10-20 本地应用记录

本次独立组定义已应用到本地会话目录；计算SQL和指标列不变。真实test调度挂接、当前版本提交推送及原生S4/S5以随后平台回执为准，不能以原候选预检或旧固定样本替代。最终审核用户提交，生产未修改。下方关于“仅TQ／未应用”的文字为落盘前的设计与取证记录。


## 2026-10-17
- dev-20261017-006：仅本地Stage1/2文档和Spark候选，未变更平台阶段、test或生产。
- 保留23列接口和闭合周期；排行周/月日更不传播；解除旧rank_period假依赖。
- 直接实时Paimon四源，缺源与零值须用独立完整性guard区分；prod仅元数据可见、test10-17小样本均不是完整周期验收。
- 修改前会话模板备份于TQ/drama-rank-spark-20261014/downstream/episode/backup。
- S3文件规范补齐：计算目标OUT_DB宏，PaimonDDL固定dws，SR影子_paimon_shadow及pb两个step已交齐未执行；task.yaml仅备份。
- test event/collect元数据为first-row，PK dt/app_id/event_id；同键变体可能丢最新版，ROW_NUMBER无法恢复，默认READY_EVIDENCE={}继续阻断。
- 交叉复核修复：scan/guard与实际输出周期起点一致，09-06仅day不要求08-31；非法历史DT在源视图前拒绝。SR影子DDL预建09-01至生成日+3天分区，此前沿用365天；2026-10-19用户已确认候选改为start=-9999，生产未改。
- 最新元数据复查补齐四源test/prod均first-row、test仅10-17、prod0分区；不能仅凭first-row判指标错，需同PK差异版本或唯一事件契约证据。
- 完整交付SQL在新隔离local Paimon warehouse四组I/O回归exit0：09-30 day/month静态写、固定输入重跑保邻分区、空源缺proof保旧、synthetic完整零清残留。DPP=false为独立app测试profile，未向候选SQL加SET；append-only保留版本fixture不代表live first-row已满足口径。

## 2026-10-19 当前006版本补验
- 正式SQL 100a7bfd0a3fe7abafb9d063e11ec136f913082e4ad8003a177e86459cce21c5，native step probes，无READY参数；计算/DDL/PB/step本轮字节未改，中文名简介已齐。
- test app application_1777107170800_0961，17日day=884行；18日day=1117、闭合week=1658，同dt共2775行；每DT两轮计算及两轮影子回写，8组独立23列对账0差异，其他分区不变。
- 只test影子TTL同步-9999，生产和共享编排未改；12—16缺历史，18日闭合week仅现有样本，不作为完整周证明。
- SR元数据探针旧语法失败已留档，正确SHOW CREATE CATALOG后只续SR；不将首app报告success=false改写成成功，不手勾Stage、不提交审核。证据 `/Users/bo/TQ/drama-rank-spark-20261014/downstream/episode006_release_20261019/`。
- 当前版本的原生S4/S5仍需按正式SQL SHA提交绑定；本次独立QA、静态检查和文档同步不替代原生阶段回执，不手工修改阶段。审核由用户提交，本轮不提交、推送或部署。

## 2026-10-20 独立发布候选（未应用）
- 仅TQ候选：006独立新组g_dws_drama_episode_period_d_d、04，入口probe四实时DWD watermark marginSec10860，PB timer；不再依赖001/005。
- 后续Goal合并正式SR目标候选：计算SQL/PaimonDDL/spec不变，SRDDL/PB仅目标改正式表，PB日期CAST/23列不变；app0961旧影子对账仅复用口径，不能证明新正式目标已写，新组/step/目标的原生S3/S4/S5仍待绑定。
- 原始shadow=true有确证；本次Goal正式目标false是新选择，不改spec§0。仅env=test且主会话先备份日期数据，本候选不执行SQL、不改repo/metadata/编排/生产。
- raw_input除table_name外为空，恢复依据与S6/S7影响单列提案，未写state。生产/正式repo/调度/审核未改。
