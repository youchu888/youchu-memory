# 【广告错误次数】dws_ad_error_metric_d — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 但又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-10-16
- 会话 dev-20261016-023 创建

## 2026-10-17
- 口径基准：生产海豚 dwd_ad_error_d（task 180032067758208）行过滤 event_id 非空、app_id 非空且 <> '-'，fanout 写 _r 没有，Spark 必须补
- 现网 dwd 对 ad_slot_key/ad_id/error_code/error_stage/trace_id 有 LEFT 截断；实测 _r 10-01～10-17 最长 42/39/19/7/91 字节，未触及，本表不截断，只保留 ad_id 截 32
- 预比：生产 SR 用同逻辑读 paimon _r，10-13（2,628 行）、10-15（2,933 行）与正式表逐行全等
- 调度：独立新线 g_dws_ad_error_metric_d，04 槽，探 dwd.dwd_ad_error_d_r（水位实时）；不并入广告请求线，避免改其入口钩子
- 指标 ad_error_cnt 已提案（pending），代码绑定 paimon 表 error_cnt
- 线名按平台规范改为组名 g_dws_ad_error_metric_d（2026-10-17，照 022 流程）
- 2026-10-17 SR 影子表 DDL 的 dim_hk 注释改全角冒号「md5：」：生产发布接口 lint 会把 md5:app_id 当占位符拦截（022 已同样处理，狂人 #10640 接受）
- 2026-10-17 S5 对数：验证跑 test.dws.dws_ad_error_metric_d 10-16 与生产正式表全等（3027 行 / 1,580,263 / 校验和 6,613,095,334,775）。平台 stage4_spark 记录为空（测试 paimon 有 3 个快照，S4 实际跑过：写 142 → 清空 → 重跑 142），S6 判 S4/挂调度没做到，需回 S4 面板补挂槽和跑一步记录
