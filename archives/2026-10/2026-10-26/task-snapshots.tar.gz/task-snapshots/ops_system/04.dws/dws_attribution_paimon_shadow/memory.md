# memory · dev-20260804-001

- 显示名：【归因Paimon影子压测】result/apply/metrics_r · 又初
- test wf 已 ONLINE；T-1 0 行因湖 `attribution_flag` NULL，按拍板不改口径
- prod `_r` / 影子 wf 未建 → Stage5 WARN；Stage7 申请审核后由审核人发
- 审核人：平台指定 `admin`（可发 prod）；同步 bus 狂人协调审核发布
- 关联：现网会话 `dev-20260610-904` / `dev-20260701-001` / `dev-20260624-001`（只读现网，不混本影子链）
- 探针长文：`../dws.dws_register_attribution_result_d/paimon_shadow_probe.md`
- Stage6 commit `71c81aa4` pushed origin/dev · 2026-08-04
- Stage7 request-publish pending · reviewer=admin；bus#5944 已请狂人审核发布
- **2026-10-23 知秋定 · bus#11232**：test `wf_dws_归因_paimon_shadow_日` 内 **`dws_register_attribution_result_d_r` 已停用**（平台停用接口，回读 `flag=NO`）。起因：自 10-21 起每日 06:30 首次执行报 `SR planner use long time 3000 ms`，约 5 分钟重试才过，日产假告警。同 wf 的 `dim_user_attribution_channel_apply_d_r` / `dws_register_attribution_metrics_d_d_r` 仍 `flag=YES`，是否一并停 **等知秋定**（又初不擅自停）。
