# memory · dev-20260907-001

## 决策

- 保留 is_run 展示语义；计算入围改双 flag
- sync 挂 apply 之后；只升 is_run 不自动置 0
- 旧看板停跑，新看板不在本 session

## 证据

- test PI #74415 · fixture YC-ATTR-V11
- prod 只读 T-1=2026-09-06 入围抽样

## 变更

- 2026-09-07 建 session，推进 1→6

- 2026-09-12：入围只留四条件，取消安装关联。test 海豚 result v273 / sync v274 / 影子 _r v2。补数 PI #75858 业务日 2026-09-10：入围 800、有候选 64、结果 64、四条件外 0。
- 2026-09-16：spark `attr_result.sql` 对齐 SR v1011（去掉 is_run 黑名单过滤；落 score_* 分项 + time_bucket_max_seconds）。集群需同步仓库文件后再跑。

- 2026-10-21（bus#10921 · 知秋令）：影子 `dws_register_attribution_result_d_paimon_shadow` vs 正式表全键（app_id×uid）对账；剧本落 `ops_system/00.pipeline/recon/`。数据日 10-21 起 Spark 读 `*_snap`；连续 7 天对平后报狂人切正式表并停海豚 task `174729603403591`。会话 `dev-20260610-904`。渠道周/月无关。
