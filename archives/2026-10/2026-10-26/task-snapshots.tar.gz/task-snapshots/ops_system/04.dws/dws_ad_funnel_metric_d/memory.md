# 【广告漏斗】dws_ad_funnel_metric_d — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 但又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-10-16
- 会话 dev-20261016-024 创建

## 2026-10-17
- 口径基准：生产海豚四张 dwd（响应 180032055043200 / 展现 180032058179712 / 点击 180032061051008 / 关闭 180032064923776）行过滤 event_id 非空、app_id 非空且 <> '-'，fanout 写 _r 没有，Spark 必须补
- 响应 dwd 的 ad_slot_key 有字符清洗 LEFT(regexp_replace(...,'[^a-zA-Z0-9_]',''),128)，响应分支照搬；其余 dwd 的列宽截断实测 _r 10-01～10-17 未触及（广告位最长 42、类型 15、关闭类型 6），不加截断
- 展现 _r 的 is_closable / is_skippable 已是 int，直接用；响应 _r 没有这两列，本表也不需要
- 预比：生产 SR 用同逻辑读四张 paimon _r，10-13（10,191 行）、10-15（10,597 行）与正式表 7 个指标逐行全等
- SR 读 paimon 的长 SQL 规划超时，要加 SET_VAR(new_planner_optimize_timeout=60000)
- 调度：独立新线 g_dws_ad_funnel_metric_d，04 槽，入口探四张 _r（水位均实时）；不并入广告请求线
- 线名按平台规范改为组名 g_dws_ad_funnel_metric_d（2026-10-17，照 022 流程）
- 2026-10-17 SR 影子表 DDL 的 dim_hk 注释改全角冒号「md5：」：生产发布接口 lint 会把 md5:app_id 当占位符拦截（022 已同样处理，狂人 #10640 接受）
- 2026-10-20 吸取 022/023 教训：step.json 四个探针 marginSec 60→12360、两步补中文名/简介；狂人已建生产 paimon 表并核过 DDL，SR 影子表也核过；下一步测试 S4 → 发布，挂步由狂人负责
- 2026-10-20 新 jar（until 写法）已上生产，知秋已把生产编排里的 022/023 改成 until "03:25"；会话 step.json 同步改为 until，024 也直接用 until（等价于 marginSec 12360）
