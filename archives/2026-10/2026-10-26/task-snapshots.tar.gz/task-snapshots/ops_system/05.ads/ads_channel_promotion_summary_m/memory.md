# memory · 【渠道推广月汇总】ads_channel_promotion_summary_m

- session: `dev-20260929-002`
- 部门：只认 `dim.dim_channel_info_all`，禁止 `dim_app_info_all.dept_code`
- 口径与周表共用；海豚 task `23209697504256`
<<<<<<< Updated upstream
- 子会话：部门月 `dev-20261013-003`
- stage4 PASS（ret_sum≈45200）；stage5 同周表 WARN；stage6 已推送 `75630359`
- 2026-10-08：生产发布申请已通过，审核人野花（`dev-20260929-002`）
- 2026-10-19：与周表同一批口径。月表 test 已按业务日 2026-10-18 重跑。4–9 月未补。

## 2026-10-21

- 同周表：去掉产品维 `dept_code`，部门只认渠道维 `dept_id`/`dept_name`。

## 2026-10-21

- 同周表：无部门渠道不落表，dept_id 必有。

## 2026-10-22

- 渠道周/月：维表对不上时 `dept_id`/`dept_name` 可空（LEFT JOIN）；RANGE 分区 OVERWRITE 用「本周/月新数 UNION 其它分区旧数」保住历史。
- 产品周：部门取渠道维按产品 `dept_id` 最大一条；可空。
- 已去 `dept_code`；test 核对通过后入库并申请/发布生产。
=======
- stage4 PASS（ret_sum≈45200）；stage5 同周表 WARN；stage6 待 commit
- 2026-10-12：补 `month_recharge_amount` / `month_deduction_recharge_amount` / `month_coin_recharge_amount`，口径同周表
- 2026-10-20（知秋 #10750 / 回 #10715）：**本轮新口径先不迁 Spark**，继续走原海豚会话 `dev-20260929-002`，发布交野花。
  - **不迁原因**：paimon 日推广 `ads.ads_channel_promotion_summary_d_d` 次留列全空；产品日活仍在 SR `ads.ads_app_metrics_daily_d` → Spark 这轮出不全。
  - **再迁前提**（须同时满足，满足后再开 Spark 迁移，**勿当永久海豚**）：① 日推广次留列已进 paimon 且可对账；② 产品日活已进 paimon。
  - **发布说明必写**：prod 渠道部门列（`dept_id`/`dept_name`）可继续为空——上游 `dim.dim_channel_info_all` 缺失/无匹配时的预期，不是报表 bug；禁止用产品维表部门顶。

- 2026-10-21（狂人 bus#10874）：prod 海豚 `ads_channel_promotion_summary_m/_w` 已回滚到 **10-09 版**。根因：10-20「测试同步生产」推了未发版（含 dept 新列）SQL，生产表未加列→10-21 日报表 Unknown column、连带约20 task。新版上产须 **S6/S7 + 生产改表同批**，禁止再测同生产单推 SQL。补数由狂人侧进行中。
>>>>>>> Stashed changes
