# memory · 【产品推广周汇总】ads_product_promotion_summary_w

- session: `dev-20261013-002`
- 父会话: `dev-20260929-001`（需求与设计在渠道周表目录）
- 粒度: `week_start_dt` × `app_id`
- 新增: 产品内渠道注册用户去重
- 充值: `SUM(revenue_total)`，单位分
- test 已建表；海豚 task `23353810594048`，上游 `ads_channel_metrics_daily_d`，工作流 `wf_ads_日报表_日`
- test 补数 pi 84552 SUCCESS（业务日 2026-10-12）：176 行，新增 105197，充值 31203800 分，与日表按产品对上

## 2026-10-14

- 四列齐。日批覆盖业务日所在自然周，窗口到 T-1。
- 本表 `app_id` 是应用编码。产品名称关联 `dim.dim_app_info_all.app_code`。维表 `app_id` 是另一套数字编号。
- test 周起始 2026-10-12（窗口到 2026-10-13）：208 个产品，四列与日表一致。`YC-001` 新增 121137、充值 57640000 分、次留 3014、日均活跃 142739。65 个编码在维表没有名称。
- 会话 v2，1–6 完成，产发待审。提交 `02e566b9`。生产须按新 DDL 重建后再跑。

## 2026-10-19

- 产品周增加 `dept_code`，来自 `dim.dim_app_info_all.dept_code`，用 `app_code` 对齐 `app_id`。
- 产品周增加 `paid_type`，来自 `dim.dim_app_info_all.paid_type`。一个产品一行，不另存付费加免费合计。
- test 业务日 2026-10-18、周起始 2026-10-12：320 行，149 行有部门编码。`DX-085` 为 `ZQ_B`。

<<<<<<< Updated upstream
## 2026-10-21

- 部门统一 `dept_id` / `dept_name`（渠道维）；去掉产品维 `dept_code`。同产品多渠道取 `dept_id` 最大一条。
- test 表已 `ADD dept_id/dept_name`、`DROP dept_code`。

## 2026-10-21

- 无部门产品不落表（INNER JOIN app_dept）。

## 2026-10-22

- 渠道周/月：维表对不上时 `dept_id`/`dept_name` 可空（LEFT JOIN）；RANGE 分区 OVERWRITE 用「本周/月新数 UNION 其它分区旧数」保住历史。
- 产品周：部门取渠道维按产品 `dept_id` 最大一条；可空。
- 已去 `dept_code`；test 核对通过后入库并申请/发布生产。
=======
## 2026-10-20 paid_type hotfix
- test publish + TASK_ONLY complement PI 86450 SUCCESS (biz_dt=2026-10-19)
- test complement PI 86450 SUCCESS; week_start_dt=2026-10-19 rows=207; paid_type filled 140 (0=61,1=78,2=1), null=67 no dim match
- prod live SQL 仍无 paid_type；表空；已 request-publish 提审产发
>>>>>>> Stashed changes

## 2026-10-23 16:00 bus#11262 撤回海豚产发申请

- 知秋 10-20 定：管理报表三表不上海豚，走 Spark（dev-20261022-001/002/003 · ad004aed）。
- 本会话 withdraw-publish：原 pending→野花（kakakh7787）申请已撤，status=none。
- 勿再 request-publish 本海豚会话。
