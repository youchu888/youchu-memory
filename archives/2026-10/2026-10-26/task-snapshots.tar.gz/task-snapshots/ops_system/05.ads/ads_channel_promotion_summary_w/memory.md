# memory · 【渠道推广周汇总】ads_channel_promotion_summary_w

- session: `dev-20260929-001`
- 部门：只认 `dim.dim_channel_info_all`，禁止 `dim_app_info_all.dept_code`
- test：表已建；海豚挂 `wf_ads_日报表_日` task `23209697185664`
<<<<<<< Updated upstream
- 次留：`LEAST` 右侧必须 `DATE(DATE_SUB(...))`；周一 biz 次留可为 0，验收用周中 schedule
- stage4 PASS（80861）；stage5：prod 无目标表 + 无渠道维表（WARN）；stage6 已推送 `75630359`
- 2026-10-08：生产发布申请已通过，审核人野花（周 `dev-20260929-001`、月 `dev-20260929-002`）。建表含周表、月表、`dim.dim_channel_info_all`
- 2026-10-19：报表部门改 `dept_code`（产品维 `app_code`），另加 `paid_type`。三个金额分开：VIP / 扣量后 VIP / 金币，取日推广表相加。次留改加日表 `last_day_retention_num`（次日任意渠道）。活跃改按产品人天加总，不除以天数。渠道 `dept_id` 列保留。test 已重跑业务日 2026-10-18 所在周、月。4–9 月未补。

## 2026-10-21

- 去掉 `dept_code`：产品维部门码与渠道部门不一致，取错。部门只留 `dept_id`/`dept_name`（渠道维）；`paid_type` 仍产品维。
- test 正式表与影子表已 DROP `dept_code`。

## 2026-10-21

- 部门必有：channel_dept 去重 + INNER JOIN；维表无匹配渠道不落表。海豚/Spark 同口径；Spark 读 SR 维表 srViews。

## 2026-10-22

- 渠道周/月：维表对不上时 `dept_id`/`dept_name` 可空（LEFT JOIN）；RANGE 分区 OVERWRITE 用「本周/月新数 UNION 其它分区旧数」保住历史。
- 产品周：部门取渠道维按产品 `dept_id` 最大一条；可空。
- 已去 `dept_code`；test 核对通过后入库并申请/发布生产。

## 2026-10-22 session

- stage6：`f6353b2f` → origin/dev
- stage7：request-publish pending，审核人 admin（超管）
- prod `ads_日报表` 当前无 promotion_summary 类 task，需同步创建后再发 SQL
=======
- 次留：注册渠道的新增 ∩ 次日该 App 全渠道活跃；`LEAST` 右侧必须 `DATE(DATE_SUB(...))`；周一 biz 次留可为 0
- stage4 PASS（80861）；stage5：prod 无目标表 + 无渠道维表（WARN）；stage6 待 commit
- 2026-10-12：test 周/月表已 ALTER 充值三列；ETL 已改仓库，海豚未重发，现有分区金额仍为 0
- 2026-10-20（知秋 #10750 / 回 #10715）：**本轮新口径先不迁 Spark**，继续走原海豚会话 `dev-20260929-001`，发布交野花。
  - **不迁原因**：paimon 日推广 `ads.ads_channel_promotion_summary_d_d` 次留列全空；产品日活仍在 SR `ads.ads_app_metrics_daily_d` → Spark 这轮出不全。
  - **再迁前提**（须同时满足，满足后再开 Spark 迁移，**勿当永久海豚**）：① 日推广次留列已进 paimon 且可对账；② 产品日活已进 paimon。
  - **发布说明必写**：prod 渠道部门列（`dept_id`/`dept_name`）可继续为空——上游 `dim.dim_channel_info_all` 缺失/无匹配时的预期，不是报表 bug；禁止用产品维表部门顶。

- 2026-10-21（狂人 bus#10874）：prod 海豚 `ads_channel_promotion_summary_m/_w` 已回滚到 **10-09 版**。根因：10-20「测试同步生产」推了未发版（含 dept 新列）SQL，生产表未加列→10-21 日报表 Unknown column、连带约20 task。新版上产须 **S6/S7 + 生产改表同批**，禁止再测同生产单推 SQL。补数由狂人侧进行中。
>>>>>>> Stashed changes
