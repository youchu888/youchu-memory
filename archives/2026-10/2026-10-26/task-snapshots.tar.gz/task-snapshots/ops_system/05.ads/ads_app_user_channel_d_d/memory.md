# 每日用户规模表 — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 但又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-10-09
- 会话 dev-20261009-001 创建
- [stage 1 发现] 上游 `paimon.dws.dws_app_user_d_h` 同一 dt 分区有两个产出步：小时累积版（中间态，0 点那轮已写 T-1 分区）和整天版日批（04 槽，最终态）。表内无区分标记，本任务只能靠调度排在整天版日批步之后；不能用「T-1 分区有数」做触发判据。
- [stage 1 发现] `active_devices_fp` 只在 paimon 侧，StarRocks `dws.dws_app_user_d_h` 没有这列（元数据里也查不到）。数据源必须读 paimon；该指标对账只能对 paimon 上游，且指纹数据不全、会低于 device_id 口径。
- [stage 1 发现] 上游整天版 channel = COALESCE(register_channel, channel, 'organic')，注册渠道优先，与知识库 id=5（统一用 dim_user_all.channel）不一致。spec 按「继承上游、本层不改」写，待用户确认。
- [stage 1 待确认，spec 里是 AI 的默认取法] ① 指标列名按标准库复用：new_user_cnt / active_users / old_active_users / active_devices_fp（未统一成 _cnt 后缀）；② 四个指标全为 0 的行（仅登录的组合）不输出。
- [stage 1 发现] 本次 session.get 返回的 artifacts 全为空串，但本地会话目录文件有内容；读现状要以本地文件为准。state 里 current_stage=2 且 stage 1/2 同为 in_progress。
- [stage 1 收尾] 用户看过 spec 与三个待确认点（渠道继承上游 / 列名按标准库复用 / 全 0 行不输出）后回复「推进s2」，未提异议、未逐条表态；AI 理解为按默认取法执行。
- [stage 2 决策] 调度：加入 `app_user_daily` 线末尾（排在 `pb_dws_app_user_d_h` 之后），04 槽，计算步 `ads_app_user_channel_d_d` + 回写步 `pb_ads_app_user_channel_d_d`。不新建线、不进 retention_daily：探上游表水位分不出整天版与小时版。待用户确认。
- [stage 2 决策] StarRocks 表用 PRIMARY KEY(dt, app_code, channel)，共 8 列（3 维度 + 4 指标 + update_time）；paimon 桶数留到 stage 3 对照同量级表定。
- [stage 2 备忘] Spark 侧 bitmap 函数：`bm_merge` 聚合合并、`bm_count` 取基数；对 NULL 输入的行为未实测，stage 4 要验。回写步 SQL 文件 stage 3 需先用 update_outputs 登记。
- [stage 3 平台异常，未解决] 进入 stage 3 时 `session.set_stage_status(2, done)` 被 spark 调度门禁拒绝，理由是 design.md 里没有 spark-scheduling 块——但本地 design.md 第 6 节里这个块是有的。随后 `session.advance_to_stage(3)` 成功，state 显示 stage 2 = done。同时 `session.get` 的 files 仍全为空串、`session.lint` 报「task.yaml: task.name 必填」（本地 task.yaml 有 name）。三者指向同一件事：平台服务端读会话文件读到的是空内容，而写入（local_written=true）正常。已报给用户，AI 不改平台。后续 stage 标 done 的后台守卫可能同样误拦。
- [stage 3 代替 lint 的自查] 因 session.lint 不可用，手工查过：三个 SQL 文件注释里无占位符字面量、无带分号的注释行；task.yaml 可解析且 params 为空。这不等于平台 lint 通过，平台读文件恢复后要补跑一次 session.lint。
- [stage 3 产出] outputs 登记为一张表：ddl_file = `ads_app_user_channel_d_d_ddl.sql`（StarRocks 正式表），etl_files = [`ads_app_user_channel_d_d.sql`（Spark 计算步），`pb_ads_app_user_channel_d_d.sql`（回写步）]。paimon 表的建表语句按同线兄弟步的惯例放在计算步 SQL 里（CREATE TABLE IF NOT EXISTS），没有单独的 paimon DDL 文件。
- [stage 3 决策] paimon 表桶数定为 1：实测 2026-10-08 上游该日 279 万行、99098 个 app×channel 组合，过滤全 0 后产出约 8.75 万行/天，8 列纯数值，一个桶足够（上游 279 万行/天用 4 桶）。design 4.1 里「桶数 stage 3 定」即指此。
- [stage 3 决策] StarRocks 历史分区用批量语法预建 2026-08-01 至 2026-10-09 共 70 个（分区名 p 加八位日期，与动态分区前缀一致），动态分区 start=-9999、end=3、时区 Asia/Shanghai。若建表日晚于 2026-10-12，批量区间的结束日要顺延到建表当天之后，否则中间会缺分区。
- [stage 3 实测] 2026-10-08 上游 app_code / channel 无 NULL 无空串，最大长度 10 / 49，StarRocks 侧 VARCHAR(50) / VARCHAR(64) 够用。prod StarRocks 里目前没有 ads_app_user_channel 开头的表。
- [stage 3 写法] 计算步输出 catalog 用 runner 渲染变量（与 fake_register、video_device 等兄弟步一致，沙箱可切到 test catalog），读取侧写死生产 paimon 的活跃天表。回写步用显式数据日分区覆盖 + 源端限定数据日 + 显式 8 列清单（照 pb_ads_content_rank_d_d 的形态）。
- [stage 3 指标库] `active_devices_fp` 已提议入库（pending）；四个指标列已绑定到 ads.ads_app_user_channel_d_d（binding_type=code，均落在 pending 区）。维度 `app_code` 库里没有，且没有提议维度的工具，未入库，需用户在平台侧处理。
- [stage 3 遗留给 stage 4] ① `bm_merge` 对 NULL 行、`bm_count` 对空组的返回值仍未实测，SQL 里已用 COALESCE 兜 0 并显式转 BIGINT；② 计算步是不带分区子句的 INSERT OVERWRITE，依赖 paimon 动态分区覆盖只覆盖数据日分区（兄弟步同写法），stage 4 在 test catalog 上验一次「重跑不动其他日期分区」。
- [stage 3 复查，第二次进入] 平台读文件已部分恢复：`session.get` 的 files 现在有内容，`session.set_stage_status(2, done)` 这次通过。但 `session.lint` 仍报「task.yaml: task.name 必填」，issues 为空——用 write_artifact 原样重写 task.yaml 后再跑结果不变；本地 task.yaml 的 `task.name` 存在、结构与兄弟任务（ads_content_rank_d_d、dws_video_device_d_d）一致。结论：lint 这条不是文件内容问题，仍是平台侧问题，AI 无法解决，平台 lint 至今没有通过过一次。
- [stage 3 复查] `metric.bindings_for_table(ads, ads_app_user_channel_d_d)` 返回 0 条。上一轮记的「四个指标列已绑定、落在 pending 区」在这个查询里看不到；是 pending 不出现在该查询里，还是绑定没落库，未确认，需用户在平台指标面板核对。
- [stage 3 复查] 手工自查重跑一遍：三个 SQL 注释行无占位符、无分号；计算步 3 条语句（建库 / 建表 / 覆盖写），回写步 2 条（SET + 覆盖写），DDL 1 条；占位符只有 runner 变量 DT / DTC / OUT_DB。

## 2026-10-14
- [stage 2 重进] 平台新增门禁：spark-scheduling 块必须带 run_mode。本表判为 partition（分区独立：只读上游数据日分区、整分区覆盖、不读自身历史），已补进 design 第 6 节表格与结论块；同时按编排版本 50 刷新了槽位数据（04 槽余量 1936 秒，05 槽余量 −58 秒），选线结论不变。4.1 桶数改写为已定的 1。
- [stage 3 第三次进入] DDL 历史分区批量区间结束日改为 2026-10-15（覆盖 2026-08-01 至 2026-10-14 共 75 个）；实际建表若晚于 10-14 仍需再顺延。三个 SQL 补 `doc` 文件头行后 session.lint 0 错误 0 警告（首次真正通过）。
- [stage 3 指标库] 四个指标重新 metric.bind(code)，返回 id 324–327、stored_in=metric_pending。bindings_for_table 查不到是因为它只返回已审的绑定，绑定本身已落库，需用户在指标面板审核。
- [stage 2 第三次进入] 按编排版本 51 重查调度上下文，04 槽余量 1936 秒、05 槽余量 −58 秒、app_user_daily 线中位 108 秒，与版本 50 一致，design / playbook 未改。用户回复「推进s3」。
- [stage 3 第四次进入，平台新规] Spark 会话要求 paimon 建表单独成文件、计算脚本禁 CREATE TABLE、另交 step.json。outputs 的 etl_files 改为 [`ads_app_user_channel_d_d_paimon_ddl.sql`, `ads_app_user_channel_d_d.sql`, `pb_ads_app_user_channel_d_d.sql`]；计算脚本删掉建库建表，只剩 SET + INSERT OVERWRITE（带 8 列清单）。
- [stage 3 踩坑·已修] 原计算脚本缺 `SET spark.sql.sources.partitionOverwriteMode = dynamic`。paimon 在 Spark 下默认静态覆盖，不带分区子句的 INSERT OVERWRITE 会清空整张表全部历史分区——兄弟步 ads_content_rank_d_d 第一行就是这句。之前备忘里「依赖动态分区覆盖、兄弟步同写法」的判断不成立，现已补上。
- [stage 3 平台缺口] step.json 不在 session.write_artifact 白名单里（报「必须是允许的 artifact 之一」，且 update_outputs 只能登记 ddl/etl），写不进会话目录。内容已按现网同类步拟好：计算步 timer + spark_sql + sqlFile `/home/ec2-user/pipeline-runner/sql/ads_app_user_channel_d_d.sql` + render OUT_DB=paimon + tagTargets 为 paimon 目标表、不带 runMode；回写步 timer + sr_sql + sqlFile `/home/ec2-user/pipeline-runner/sql/pushback/pb_ads_app_user_channel_d_d.sql` + countTable ads.ads_app_user_channel_d_d。已报给用户，等平台放开白名单。
- [stage 3 第五次进入] 平台已放开 step.json 白名单，按上一条拟好的内容写入（两步数组：计算步 timer/spark_sql/render OUT_DB=paimon/tagTargets 为 paimon 目标表，run_mode=partition 故不带 runMode、startDate；回写步 timer/sr_sql/countTable，不配锚点）。trigger 用 timer：线内位置即顺序保证，与 ads_content_rank_d_d 同款。session.lint 0 错误 0 警告。stage 3 交付物齐。
- [stage 4] Spark 测试面板已完成：建 paimon 和 SR 两张表、挂到 app_user_daily 线 04 槽、跑一步（10-13）、补数（起点 10-13，1 天）；三勾由 spark-s4 自动勾上。本任务不挂海豚，Part B 不适用。
- [stage 4 核对] sr_test 上对 10-12、10-13 跑 CP1–CP7 全部通过。测试上游新增 / 老活跃 bitmap 为空，这两列全 0 属测试数据的情况，留到 stage 5 用生产数据核对。
- [stage 4 幂等] 10-13 跑了两次结果一致，10-12 分区未被改动，Spark 动态分区覆盖已验证。AI 单独重跑回写步（db.run_ddl_etl）被本机权限策略拦下；另外 db.run_ddl_etl 不接受带 SET 语句的 SQL。
- [stage 4 第二轮核对] 编排快照版本 53：上游整天版由 app_user_daily 线第 1 步 dws_app_user_d_h 产出（04 槽，中位 95 秒），本任务挂在同线该步之后，挂法正确、无需探针；04 槽余量 1892 秒；同槽的 base 线小时步写的是当天分区，不会和 T-1 冲突。快照里 app_user_daily 线还只有两步，说明挂步只在测试调度器上，上线时要同步到现网编排。
- [stage 4 第二轮核对] 测试 paimon 与 sr_test 一致：10-12 共 57 行，10-13 共 5 行；主键无重复（CP1），channel 全为 organic、无空值。上游 10-12 有 60 个组合，少的 3 个（JLYQ-004 / WX-225 / JHA-157）四项全为 0，按规则过滤，正确。抽 YC-001、JHGXN-112、TRFB-011、DX-032 用 bm_count(bm_merge) 反算，与结果表逐值一致。10-12 分区 update_time 为 21:00，早于记录里的跑一步和补数（补数起点是 10-13），是更早一次手跑留下的。
- [stage 4 覆盖缺口，留给 stage 5] 测试上游每个组合只有 1 格、只有 organic 一个渠道、新增和老活跃 bitmap 全空；生产 10-13 是 292 万行、10.2 万组合（平均每个组合约 29 格）、8.4 万个渠道。所以「跨格先合并再取基数」、渠道维度、新增 / 老活跃两列在测试里都没有真正测到，stage 5 必须拿生产数据核。另外建议 stage 5 加一条：新增 + 老活跃 应基本等于活跃（现在 CP6 只检查不大于）。
