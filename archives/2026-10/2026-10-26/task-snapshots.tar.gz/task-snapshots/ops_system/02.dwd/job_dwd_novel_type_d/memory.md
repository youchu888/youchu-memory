# memory · novel chapter

- Session：`dev-20260727-novel-chapter-001`
- 止于 request-publish；证据门控重走（禁盲勾）

## 2026-10-16 测试海豚 chapter_name 截断（仅测试）

- 测试海豚 `dwd_novel_event_d`（task 174729506942802，v440）的 `chapter_name` 写成 `LEFT(get_json_string(payload, '$.chapter_name'), 100)`，列宽 `varchar(300)` 不动。
- 原因：10-15 有 1 行 chapter_name 360 字节，超 varchar(300) 字节上限，整条 INSERT 失败（`SET enable_insert_strict = false` 没起作用）。
- **老板定：只在测试截断；上生产不截断。** 仓库 `dwd_novel_event_d.sql` 保持不加 LEFT，生产发布以仓库为准，不要从测试海豚拷 SQL。
