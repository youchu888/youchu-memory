# 【渠道汇总】ads_channel_summary_d · 又初 — 会话备忘录

## 2026-10-16
- 新建 Spark 会话 dev-20261016-014。目录与现网海豚会话分开。
- 正式表仍由海豚写入。回写只进影子表。
- 不直接读事件，读三张日汇总。等上游 Spark 有数再写 SQL。

## 2026-10-20
- stage 3：`ads_channel_summary_d.sql` / paimon DDL / SR 影子 DDL / `pb_*.sql` / `step.json` 已写。
- test 实查：`paimon.dws.dws_app_channel_summary_d_d` 在 2026-10-19 约 13.2 万行；`dws_app_channel_retention_d_d` 同日 0 行；`dws_register_by_landing_page_d_d` 在 Paimon 尚未建表（跑数前需补迁移或改读路径）。
- 用户上下文提到的 `paimon.ads.ads_channel_metrics_daily_d` 与本表无关（本表上游是三张 DWS 汇总，非 metrics_daily）。

## 2026-10-20 stage4

- 挂 `g_ads_channel_summary_d@10`，补 `2026-10-19` → Paimon **3747** 行。
- 落地页上游表未建，ETL 用空源（landing_page_new_user_num=0）。
- SR 回写暂失败：catalog 列名 `date_key` vs Spark 分区 `dt` 不一致，待对齐后再 pb。
