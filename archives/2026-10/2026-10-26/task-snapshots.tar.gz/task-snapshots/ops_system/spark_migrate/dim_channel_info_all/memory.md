# 记忆

- 2026-10-20：按狂人 #10785/#10786 新建 session `dev-20261020-001`。SR→Paimon 日快照，`snap_dt` 分区，timer + srViews；DATETIME -8h。
- test SR 约 20 行可对账；prod SR 查得 0 行——空分区属源空，部门列空不是同步逻辑 bug。
- 下游渠道周/月 Spark 稿须 `WHERE snap_dt = 业务日` 再 JOIN，禁止扫全历史分区。
- 2026-10-20 bus#10789：对齐 844c4baf。SR 无 dt → 表名 dim_channel_info_all_snap + snap_dt；ETL 禁 CREATE；DDL 交狂人。旧 dim_channel_info_all（无 _snap）稿作废。
- 2026-10-20 bus#10793：狂人实测 runner 下减 8h 会早 8 小时；已去掉。runner srViews≠老 run_spark_sql_sr.sh。

- 2026-10-21（bus#10911）：①prod SR 自 10-08 21:10 建表后审计 **0 条** `INSERT INTO dim.dim_channel_info_all`；test 由 `172.31.9.165` 每日 01:30 INSERT（业务后台/bmp）。生产空不是同步 bug，是 **写入任务未配 prod**。②日全量历史按 `dim_channel_info_all_snap`+`snap_dt`（知秋要求）；`created_at/updated_at` 已去掉减 8h（对齐 #10793 runner），待推。

- 2026-10-21（bus#10916 补 #10911 · 牡丹三点）：
  1) test SR 渠道写是「有新渠道才 INSERT」增量、无 UPDATE → **不能**再以 SR 当前表当全量源。日全量 snap 改为每天从业务库 **`system_channel_info` 全量抽** → 写 `dim_channel_info_all_snap` 当日分区；同时全量覆盖写 SR `dim.dim_channel_info_all`（供海豚部门周/月 INNER JOIN）。
  2) 10-15～首个正式分区前：用**首次全量**结果回填这些 `snap_dt`，文档标明「事后回填」非当日真实快照；再让狂人补部门周/月。
  3) 渠道周/月部门列是否从 10-15 回刷：**等知秋**，未定不动。

- 2026-10-21（bus#10936 回 #10917）：
  1) ETL 已改 JDBC 全量抽（去掉 srViews）；`step.json` 用 `params.render.JDBC_*` 空串进仓。
  2) 狂人侧无 prod JDBC；**又初直接找运维开只读账号**，不用等狂人。
  3) 推 origin/dev 后把 **commit** 回狂人 → 他建 prod Paimon + 挂槽。
  4) 部门周/月从 10-15 补跑：**等有数后狂人来**。

- 2026-10-22（bus#11150 催办）：生产 JDBC **仍未要到**。协作群 10-21 13:06 已 @wangyi00001 开户（bot 不在运维群）；本机无 `jdbc.conf` / 无 `params.render` 填值。卡点=运维未回。SQL 仍：`dim_channel_info_all_snap_ddl.sql` + `dim_channel_info_all_sync.sql`（commit `b0e82f35`）。

- 2026-10-22（主人私聊#573）：prod 只是现在没数、后面会有；要求定时从 SR 拉维表，不走业务库 JDBC。已 bus#11160 请狂人拍板 A/B/C（含增量无 UPDATE 风险说明）。

- 2026-10-22（bus#11161 回 #11160）：选 A。源改回 SR dim.dim_channel_info_all + srViews；去 JDBC_*；挂 05 槽（与 dim_app_info_all 同槽，挂槽/建表归狂人）；DATETIME 不减 8h；风险不挡。改完 push 交 commit。

- 2026-10-22（bus#11164 更正 #11161）：渠道维日快照改由狂人直接做（同归因配置 SR→paimon）；又初停手、不再推 JDBC 版。已推的 230fa1fb 为 SR 版草稿，后续不跟。

- 2026-10-22（bus#11175）：狂人 rebase 到 `3ce1c124` 冲突按生产现网处理——`pipeline-runner/sql/dim_channel_info_all_sync.sql` 保留 md5 `68ebf206`（按天快照挂 00 槽），不用我 `230fa1fb`「改回 SR 定时拉、去 JDBC」那版。要换须先测后产、换前先跟狂人说。本机已 checkout origin/dev 对齐该文件。
