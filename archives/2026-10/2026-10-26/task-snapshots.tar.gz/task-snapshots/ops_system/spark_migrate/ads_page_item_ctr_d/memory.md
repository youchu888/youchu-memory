# 【点击率分析】ads_page_item_ctr_d · 又初 — 会话备忘录

## 2026-10-20
- 新建 Spark 会话 dev-20261020-002。
- 已定：按次数；只有曝光也落行；两边都没有不落行；按 event_time 归日；历史先不补；清单维表日期是分区，从 2026-10-01 起维护。
- 上游字段：page/item 均在 payload。

## 2026-10-20 stage3
- Stage 1/2 已完成。Stage 3 编码中：DDL/ETL/step/回写已落盘。

## 2026-10-20 stage3 收口
- step.json 四步补中文名/简介；调度线定为 `g_page_item_ctr`，11 槽，探针 `dw.dw_user_event_detail_new`（规则 `partition`，原 partition_ready 平台不认）。
- lint：ETL 无 error（step.json 头注释 warning 可忽略）。

## 2026-10-20 stage4
- 测试五步已由 API 直接跑完。
- ① 送 SQL ② Paimon+SR 建表 ③ 挂 `g_page_item_ctr`@11 ④ 单跑 T-1 四步 SUCCESS（dim/ads 各 436 行）⑤ 起点 2026-10-19 补 1 天 SUCCESS。
- playbook：rows=436、exposure_only=301、both_zero=0。
- `stage4_db_check` 三勾已写；Stage 4=done，进入 Stage 5。

## 2026-10-20 stage5
- 生产目标表未建、验证无产出：stage5_prod_dryrun=WARN。上游字段核对 PASS。Stage 5=done，进 Stage 6。

## 2026-10-21 stage6
- 会话文档与 SQL 已在 origin/dev；补对接表结构文件 `对接_表结构.md`。
- Stage 6 提交收口后进 Stage 7（仅 request-publish，不自发产发）。旧 tip 曾为 `07c52cef`（仍含 ctr）。

## 2026-10-24 bus#11375 审回改
- 审核未过：表存了 `ctr` 违反「表不存比率」。已去掉 ctr：paimon/SR DDL、ETL、回写、对接说明、spec/design/step 简介一并改。
- test：Paimon rebuild + SR `ALTER DROP COLUMN ctr`；近 3 天有数。

## 2026-10-24 bus#11377
- 去 ctr 版已推 **origin/dev** `59705bcf`（cherry-pick 自 `4e7987a3`）。
- 重做 S6：`stage6_commit.sha=59705bcf`，pushed=true。
- 重做 S5 verify 数据日 2026-10-23：rows=106995；exposure_sum=13508036；click_sum=1766525；与上游 `dw.dw_user_event_detail_new` 两事件条数对平。
- 等狂人复审后让野花发；又初不自行产发。
