# 【渠道推广周汇总】ads_channel_promotion_summary_w · 又初 — 会话备忘录

## 2026-10-16
- 新建 Spark 会话 dev-20261016-015。目录与现网海豚会话分开。
- 正式表仍由海豚写入。回写只进影子表。
- 读渠道日指标。现有海豚会话保持原样，本会话只走 Spark。

## 2026-10-20
- 口径对齐现网：日推广表相加；活跃用人天；部门/是否免费来自产品维。
- SR→Paimon 改为独立日批：每天 0 点过后按天增量拉 T-1（线 `sr_to_paimon_daily`，00 槽）。配置在 `../mysql_jdbc_sync/`。
- 周汇总只探同步表水位，再算、再回写影子表。

## 2026-10-20
- 对齐 Paimon 现网：渠道维 `dim_channel_info_all_snap`；推广日表 `ads_channel_promotion_summary_d_d`（date_key）；活跃 `bm_count(ads_app_metrics_daily_d.dau_ids)`（test 表空则 0）
- step 去掉 SR 影子回写；先只写 Paimon
- 部门/产品 Spark ETL 已落盘；依赖 `ads_channel_metrics_daily_d`（test Paimon 暂空）


## 2026-10-21

- ETL/DDL/pb 去掉 `dept_code`；部门只写渠道 snap 的 dept_id/dept_name。

## 2026-10-21

- 部门：sr_dim_channel + INNER JOIN，禁止空 dept_id / dept_id=-1。

## 2026-10-22

- 与海豚同口径：渠道周/月 LEFT JOIN 渠道维（部门可空）；产品周代表部门可空；已去 `dept_code`。
