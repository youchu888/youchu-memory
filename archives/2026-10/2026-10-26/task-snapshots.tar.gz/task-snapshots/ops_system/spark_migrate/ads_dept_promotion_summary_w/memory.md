# 【部门推广周汇总】ads_dept_promotion_summary_w · 又初 — 会话备忘录

## 2026-10-16
- 新建 Spark 会话 dev-20261016-017。目录与现网海豚会话分开。
- 正式表仍由海豚写入。回写只进影子表。
- 读渠道日指标。现有海豚会话保持原样，本会话只走 Spark。

## 2026-10-20
- 对齐 Paimon 现网：渠道维 `dim_channel_info_all_snap`；推广日表 `ads_channel_promotion_summary_d_d`（date_key）；活跃 `bm_count(ads_app_metrics_daily_d.dau_ids)`（test 表空则 0）
- step 去掉 SR 影子回写；先只写 Paimon
- 部门/产品 Spark ETL 已落盘；依赖 `ads_channel_metrics_daily_d`（test Paimon 暂空）


## 2026-10-20 stage4

- 挂 `g_ads_dept_promotion_summary_w@10`，补 `2026-10-19` → 4 行（test 渠道维约 20 行，LEFT JOIN 后多为 dept=-1）。
- 月表曾误写周表名，已改回 `_m` 后同日 4 行。
- S5 仍卡 prod `sql/deploy` 403。

## 2026-10-21

- 部门：sr_dim_channel + INNER JOIN，禁止空 dept_id / dept_id=-1。
