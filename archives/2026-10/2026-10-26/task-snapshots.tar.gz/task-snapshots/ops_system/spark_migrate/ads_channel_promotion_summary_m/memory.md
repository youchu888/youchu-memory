# 【渠道推广月汇总】ads_channel_promotion_summary_m · 又初 — 会话备忘录

## 2026-10-16
- 新建 Spark 会话 dev-20261016-016。目录与现网海豚会话分开。
- 正式表仍由海豚写入。回写只进影子表。
- 读渠道日指标。现有海豚会话保持原样，本会话只走 Spark。

## 2026-10-20
- 与周表同一套：JDBC 同步上游 + Spark 月汇总 + 影子回写。会话 dev-20261016-016。

## 2026-10-20
- SR→Paimon 按天增量独立日批（00 槽）；月汇总只读已同步分区。

## 2026-10-20
- 对齐 Paimon 现网：渠道维 `dim_channel_info_all_snap`；推广日表 `ads_channel_promotion_summary_d_d`（date_key）；活跃 `bm_count(ads_app_metrics_daily_d.dau_ids)`（test 表空则 0）
- step 去掉 SR 影子回写；先只写 Paimon
- 部门/产品 Spark ETL 已落盘；依赖 `ads_channel_metrics_daily_d`（test Paimon 暂空）


## 2026-10-21

- ETL/DDL/pb 去掉 `dept_code`；部门只写渠道 snap 的 dept_id/dept_name。

## 2026-10-21

- 部门：sr_dim_channel + INNER JOIN，禁止空 dept_id / dept_id=-1。

## 2026-10-22

- 与海豚同口径：渠道周/月 LEFT JOIN 渠道维（部门可空）；产品周代表部门可空；已去 `dept_code`。
