# 关键词检索小时分布 — 会话备忘录

## 2026-10-20
- 会话 dev-20261020-003。老板定先迁这张。
- 现网日批、小时批都 JOIN `dim.dim_user_all`，不是 `dim_user_snap`。
- `paimon.dwd.dwd_keyword_search_h_r` 最后分区 2026-09-14 23 点，停更。改读仍在出数的 `paimon.dwd.dwd_keyword_search_d_r`，小时用 `HOUR(event_time)`，对齐现网 `date_trunc(event_time)`。
- 先做日终（昨天分区）对影子表。小时批继续写今天的正式分区，先不停。不补历史。
- 2026-10-20 晚上老板改了原始需求：用户类型改读视图 `paimon.dim.dim_user_all_d_v`（指向数据日那一版快照，和视频分析日终是同一份）。目标表名改为 `ads_keyword_search_hour_d_d`。空和关联不上仍为 unknown，不改大小写。正式表 2026-10-19 实测 user_type 为 NORMAL / VIP / unknown。
