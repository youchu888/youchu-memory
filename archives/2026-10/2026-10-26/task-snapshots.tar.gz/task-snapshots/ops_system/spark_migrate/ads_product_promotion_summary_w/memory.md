# memory

## 2026-10-20
- 对齐 Paimon 现网：渠道维 `dim_channel_info_all_snap`；推广日表 `ads_channel_promotion_summary_d_d`（date_key）；活跃 `bm_count(ads_app_metrics_daily_d.dau_ids)`（test 表空则 0）
- step 去掉 SR 影子回写；先只写 Paimon
- 部门/产品 Spark ETL 已落盘；依赖 `ads_channel_metrics_daily_d`（test Paimon 暂空）


## 2026-10-21

- 部门改为渠道 snap 的 dept_id / dept_name；不再写 dept_code。

## 2026-10-21

- 部门：sr_dim_channel + INNER JOIN，禁止空 dept_id / dept_id=-1。

## 2026-10-22

- 与海豚同口径：渠道周/月 LEFT JOIN 渠道维（部门可空）；产品周代表部门可空；已去 `dept_code`。
