---
date: 2026-07-17
tags: [worker_ant, datacheck, dws_app_user_w_d_new, dws_app_user_m_d_new, dws_app_user_d_h, complement, starrocks, severe]
severity: high
domain: datacheck
source: worker_ant 协作群 2026-07-17 全量核查 severe 复核
---

# 活跃周/月表重建后缺数 · Step3 周活 -59% 实锤

## 背景

监控 Step3 报周活 -59.91%；狂人 SR 实证为真缺数（非核查算法误报）。`dws.dws_app_user_w_d_new` 全部分区创建时间均为 07-16 18:30，整表昨晚被重建；`dws_app_user_m_d_new` 同病。源表 `dws_app_user_d_h` 完整（2025-12-20~今）。

## 坑 / 错误做法

- 看到监控大幅波动直接当算法误报，不查分区创建时间与分区行数
- 表重建后只跑日任务、未补历史逐日 INSERT，周/月 LIST 分区长期为空
- 未区分新表 `dws_app_user_w_d_new` 与旧表 `dws_app_user_w` 的下游绑定，误判用户侧影响

## 现状快照（07-17 狂人实证）

| 对象 | 状态 |
|------|------|
| `dws_app_user_w_d_new` p2026027 | 已回填 ~580 万行 |
| p2026029 | 仅今晨日任务插入 07-16 单日（18,724,644 = 当日 uniq） |
| 缺口 | 本周 07-13~15、整周 2026028、2026026 及更早全空 |
| `dws_app_user_m_d_new` | 仅 202607，历史月份全空 |
| 源 `dws_app_user_d_h` | 完整；本周真实周去重 = 46,704,932 |
| 旧表 `dws_app_user_w` | 仍在出数；挂旧表下游暂无感 |

## 正确做法

1. **验数**：查分区 `create_time`；按 week/month 分区 COUNT 与源表对账
2. **补数**：逐 dt 重跑日 ETL 的 `INSERT INTO dws_app_user_w_d_new`（读 `dws_app_user_d_h`）；范围 **2025-12-20 ~ 2026-07-15**（~210 天）；`BITMAP_UNION` 聚合幂等，重跑不会多算
3. 周/月分区由日增量 **自动聚合**，无需单独补周/月 INSERT
4. **应急**：可先只补近 4 周全历史逐日 INSERT
5. **拍板项**：重建操作者/是否迁移中 → 确认后再大规模补数

## 验证

- 各 week 分区行数与 `dws_app_user_d_h` 按周去重一致
- 监控 Step3 周活环比恢复正常量级
- `backfill_app_user_views_history.sql` Step 4 校验 base vs mv 对齐

## 关联

- 日 ETL：`ops_system/04.dws/dws_app_user_active/dws_app_user_w_d_new/dws_app_user_w_d_new.sql`
- 历史补数脚本：`ops_system/04.dws/dws_app_user_active/backfill_app_user_views_history.sql`
- 昨日月表验数：`2026-07-16-dws-app-user-m-verify-object.md`（202607 膨胀根因，与本条重建缺数并行）
