# dev-20260719-001 设备标签 v2 merge_pool

## 2026-07-22 SF-81 Paimon 试点验数通过

- DWM 四表各 27 天（06-24~07-20）；06-21~06-23 源无 SF-81 行
- fail_hint=9：Paimon 并发写冲突；串行重跑 order×8 + ad×2 = **10/10 OK**
- 宽表 calc_dt=07-20 行 111348；multi7=70103 PASS
- 报告：`ops_system/04.dws/dws_device_tag_d/reports/paimon_verify_SF81_2026-07-22.md`
- git：`origin/dev` @ bbd40f38；集群代码 rsync `/tmp/dtag_spark`
- stage：**4 in_progress**（test 发布准备；不等 uid_map 拍板）
- 待拍板：uid_map 是否并行（dev-20260720-001）
