# 日报 / 周报归档

> **Canonical**：`CHcode/.cursor/work-log/reports/` · **不进 Git**

## 规则

1. **内容来源**：仅归纳**当日**用户提问 / 交办任务
2. **双写**：
   - 正式日报 → `reports/YYYY-MM-DD-日报.md`
   - 结构化流水 → `../YYYY-MM-DD.md`

## 文件命名

| 文件 | 用途 |
|------|------|
| `YYYY-MM-DD-日报.md` | 对外/提交用日报全文 |
| `YYYY-Www-周报.md` | 自然周汇总 |

## 非工作日

法定假日、常规周日：不生成日报（无交办除外）。
