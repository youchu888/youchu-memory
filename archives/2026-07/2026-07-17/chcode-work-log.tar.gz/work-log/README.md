# 工作流水 · 又初（CHcode 项目）

> **Canonical 路径**：`<repo>/.cursor/work-log/` · **不进 Git**（`.gitignore` 已忽略 `.cursor/`）  
> 日历规则：[`~/.dc-platform/memory/reference_work_calendar_cn.md`](file:///Users/mac/.dc-platform/memory/reference_work_calendar_cn.md)  
> 生成剧本：[`~/.dc-platform/memory/playbook_daily_weekly_report.md`](file:///Users/mac/.dc-platform/memory/playbook_daily_weekly_report.md)

## 目录结构

```
.cursor/work-log/
├── README.md                 # 本文件
├── _template.md              # 日流水模板
├── _template_weekly.md       # 周汇总模板
├── YYYY-MM-DD.md             # 日流水（结构化摘记）
├── YYYY-Www.md               # 自然周索引
└── reports/
    ├── README.md
    ├── YYYY-MM-DD-日报.md    # 正式日报（对外/提交）
    └── YYYY-Www-周报.md      # 正式周报
```

## 规则摘要

| 类型 | 来源 | 落盘 |
|------|------|------|
| **日报** | 当日用户提问/交办 | `reports/YYYY-MM-DD-日报.md` + 同步 `YYYY-MM-DD.md` |
| **周报** | 合并该自然周各日日报 | `reports/YYYY-Www-周报.md` + `YYYY-Www.md` |
| **lesson** | 踩坑经验 | 仍写 `~/.dc-platform/memory/lessons/` |

- **自然周**：周一～周日（ISO `YYYY-Www`）
- **工作日**：周一至周六；法定假/调休见工作日历

## Agent 收尾

1. append `YYYY-MM-DD.md`（工作日）
2. 用户要日报时写 `reports/YYYY-MM-DD-日报.md`
3. 子 Agent 同样写本目录，不只写 transcript

> 旧路径 `~/.dc-platform/memory/work-log/` 已弃用，仅留重定向说明。
