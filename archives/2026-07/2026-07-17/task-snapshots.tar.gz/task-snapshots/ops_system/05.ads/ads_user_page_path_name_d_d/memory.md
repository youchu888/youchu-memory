# 用户页面路径日表 ETL — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 但又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-05-13
- 会话 dev-20260513-001 创建
- **DAG 串行（用户拍板）**：本任务 `ads_user_page_path_name_d_d` 不与前置任务 `ads_user_page_path_d` 并行；必须挂在前置任务的下游，前置任务跑完才触发。stage 4 在海豚 DAG 配 task 依赖时严格按"前置任务 → 本任务"单边连线，不要直接连到 `dwd_app_page_view_d`。
- **"24 个中文汉字" = 24 个 utf8 字符**（用户未推翻 stage 1 该解释）：ETL 用 `LEFT(page_name, 24)`，按 StarRocks 字符语义切。
- **DDL 跟前置表 1:1 对齐**（用户确认）：PRIMARY KEY `(dt, path_key, app_id, user_type)`、`path_key VARCHAR(64)`、`path VARCHAR(5012)`、`HASH(path_key) BUCKETS 32`、`dynamic_partition.start=-9999`。
- **跨表对账阈值（用户确认）**：`SUM(s_cnt)` / `SUM(u_cnt)` 与前置表误差 < 1%；`COUNT(DISTINCT path_key)` 在 [old, old×5]。
- **参数 pattern 由 ${name} 改为 inline `$[...]` 宏（stage 3 用户拍板）**：stage 2 design 原方案是复用 wf globalParam `${dt}` + task localParam `${pt}`（跟前置任务一致），但 session.lint 报 `undeclared_param` 错（lint 强制要求 `${name}` 必须在 task.yaml 声明）。用户在 stage 3 选 "改 SQL 用 inline `$[...]` 宏"：`WHERE dt = '$[yyyy-MM-dd-1]'`、`PARTITION (p$[yyyyMMdd-1])`、`'$[yyyy-MM-dd-1]' AS dt`。**task.yaml 保持 params: []**；stage 4 发布**无需**配 dt/pt localParam；DolphinScheduler 直接展开 `$[...]` 宏。

### stage 4 关键发现
- **DDL 初始 RANGE 起点必须早于上线日**（2026-05-13 踩坑）：第一版 DDL `START ("2026-05-13") END ("2026-05-14") EVERY (INTERVAL 1 DAY)` 只 bootstrap 单天分区，`dynamic_partition.end=3` 只 forward 新分区不 backfill 过去；今天跑昨天 (yyyy-MM-dd-1=2026-05-12) 时目标分区 p20260512 不存在 → INSERT OVERWRITE 失败。修复：START 改成 `2026-01-01`（覆盖年度全部历史分区，方便回刷），用户 DROP 后我重建。下次新任务先检查"今天跑昨天"的分区是否在 DDL 初始 RANGE 内。
- **平台 db_run_ddl_etl 禁 ALTER**：分区不够时无法 `ALTER TABLE ADD PARTITION`，只能命令行人工跑。所以 DDL 设计阶段就要把 RANGE 一次到位。
- **GROUP_CONCAT(... ORDER BY event_time) tie-breaker 缺失**（2026-05-13 发现）：dwd 上游数据完全不变情况下，两次 ETL 跑出来差 48 行（占 0.43%）。原因是 event_time 在多行并列时排序不稳定 → raw_path 拼接顺序变 → UDF 折叠 final_path 不同 → 多算或少算几条 path。**前置表 ads_user_page_path_d 理论上同问题**。差异极小（万分之一聚合量），生产可接受；如果业务方要求严格幂等，stage 6 可在 ORDER BY 加 tie-breaker（如 event_id）。
- **UDF `default_catalog.path_folder_udf` 末节点附加 trailing `-`**：前置表也有同样行为（如 `search-`、`av_list-`、`/read_lld_member-`）。这是 UDF 共性，不归本任务处理。playbook part_02"节点字符数 ≤ 24"会因 trailing `-` 计成 25，已记录但不阻塞。
- **playbook 3 处 bug 已修**（part_01 u_cnt>s_cnt 改告警 / part_02 REGEXP 反向引用不支持改 split_part / part_04 SUM 不等于 distinct 是设计选择）。

### stage 4 test 海豚 wf 当前状态
- **`wf_ads_日报表_日`** wf (test) 整 wf 5/12 + 5/13 SCHEDULER 实例 RUNNING 12h+：卡在入口 DEPENDENT 任务 `dwd_dwm_dim_dws` 等 **`wf_dws_汇总_日`** 当日 SUCCESS。
- **`wf_dws_汇总_日`** 临时 OFFLINE（用户确认 2026-05-13）：不是配置过期 / 不是被废弃，实际是在用的，只是临时维护。**不要去修 wf 配置，不要去停这两个 RUNNING 实例**——wf 上线后 DEPENDENT 会自然放行。（prod UI legacy 名 `dws_日`）
- **影响 stage 4 海豚发布**：safety_check 因有 2 个 RUNNING 拒绝创建新 task，需要 `force=true` 绕过。绕过本身不破坏什么（这两个 RUNNING 不会自然结束）。
- **影响 Part B 海豚跑数验证**：即便 force 发布成功，整 wf 入口卡在 DEPENDENT 永不放行 → 即便 SCHEDULER 触发也跑不到本 task。要真正验证 task SQL 跑通，只能用 `start_node_list=[新 task code]` + `TASK_ONLY` 单独触发本 task，绕过入口。

### stage 5 关键发现
- **上游 page_name 缺失 session 级集中度 ≫ 行级**（2026-05-13 prod dry-run 发现）：dwd.dwd_app_page_view_d 单日 page_name 行级 null 率只 0.6%（2.35M / 390M），但 session 维度 (app_id, sid, uid) 三元组 page_name 全空率高达 **2.77%**（page_key 过滤后 44.20M session / page_name 过滤后 42.98M session，差 1.22M）。即缺失行集中分布在某些 session，整 session 都没有任何 page_name 非空 → 整 session 被本表 ETL 丢掉。这导致 `SUM(s_cnt)` 比前置 `ads.ads_user_page_path_d` 低 2.77%（44.17M vs 42.95M，差 1.22M 几乎完全等于 session 数差异）。**非 ETL bug**，是上游埋点状态；playbook 第 6 节"page_name 缺失高发期"已预告此情况。stage 5 已 ⚠️ warning 通过。如果业务方对该缺口敏感，需联系埋点同学补 page_name 上报；本表 ETL 无需改。
