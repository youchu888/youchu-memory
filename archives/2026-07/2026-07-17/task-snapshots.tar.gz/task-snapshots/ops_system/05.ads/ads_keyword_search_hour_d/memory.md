# 关键词分析-24h检索分布 — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 但又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-06-04
- 会话 dev-20260604-001 创建
- stage2：design+playbook+DDL/ETL 定稿；表名 `ads_keyword_search_hour_d`；hourly+daily OVERWRITE；CP2 不拆词对账
- stage3：DDL RANGE 自 2025-12-20；ETL dt 用 yyyy-MM-dd 宏；repo/lint ok；search_cnt propose+bind code
- 2026-06-08 stage7：prod 同步 404 时，确认 prod 里已有 `运营系统` 项目和对应 workflow，但 `ads_keyword_search_hour_d_hourly` / `ads_keyword_search_hour_d_daily` 尚未落到 prod；当前平台不允许 AI 直接写 prod，只能由 admin 手工补任务或修复同步接口后再试。
