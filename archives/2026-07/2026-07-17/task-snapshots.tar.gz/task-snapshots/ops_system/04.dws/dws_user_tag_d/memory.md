## 2026-06-05
- 活跃口径：page_view ∪ login（业务已拍板）。
- bucket_n：用户=4 / 设备=8。

## 2026-06-09
- **DWM 中间层**落地：spec/design/playbook/README 对齐；宽表读 6 张 DWM + `init`/`daily` 拆分。
- 上线路径：DWM 冷启动 → 宽表 init @ D → 日常 T+1 **不补历史**。
- 阻塞：prod 老 `dwm_user_register_d`（channel 汇总）须改名后再建 tag 身份表。
- 旧 playbook stage5 记录归档作废；stage 4/5 按新 playbook 重跑。

## 2026-06-10
- 宽表 SQL 性能优化 ①②③（与设备标签同构）；`cascade_rollback` → **stage 2** 重走平台流程。
- `outputs` 已登记 `dws_user_tag_d_init.sql`；`task.yaml` 移除 `dt`，仅 `bucket_n`/`bucket_id`。
- 后端 state + artifact 已与磁盘 DWM 版同步；**outputs = 6 DWM + 1 DWS 单会话**（对齐设备标签，不拆子会话）。
- Stage 4 三勾须 **全部取消** 后按 DWM→init→daily 顺序重跑；勿用旧直扫 DWD 数据对账。
- 辅助脚本：`dc-platform-server/scripts/backfill_user_dwm_phase3.py`
