# 【归因看板二期】dashboard_ext — 会话备忘录

> 父会话：dev-20260624-001（`dws.dws_register_attribution_metrics_d_d`）

## 2026-07-08
- 知秋/看板截图二期：渠道 Top、高风险 Top5、健康指标、分数分布 → 四张 DWS 预聚合表
- 单 task `dws_register_attribution_dashboard_ext_d`，挂 `metrics_d_d` 之后
- prod `metrics_d_d` 06-30 起断流（群聊#38 已报），二期告警/7日滚动依赖一期，修 metrics 优先
- 代码落盘 `ops_system/04.dws/dws.dws_register_attribution_dashboard_ext_d/`，test DDL 已建
- test 海豚 task_code=22281101734272，挂 metrics 后；分区宏 typo 已修并重发 v104
- test 补跑 06-28：metrics 3 行 + ext 四表有数，playbook 对账通过
