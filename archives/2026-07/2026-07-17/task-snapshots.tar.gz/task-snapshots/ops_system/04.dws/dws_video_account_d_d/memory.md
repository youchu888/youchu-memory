# 视频分析-账户 — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 但又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-05-18
- 会话 dev-20260518-001 创建

## 2026-05-19
- stage2 design 完成：两级聚合（sid级预聚合 → 维度级汇总），PRIMARY KEY + INSERT OVERWRITE 幂等
- device 归一化：取 dwd 原始值优先，dim 作 fallback，输出 IOS/ANDROID/PC/OTHER
- region 使用 dim_region_info_all.full_path_name（VARCHAR），优先 city 匹配兜底 country
- 互动指标（like/comment/collect/purchase）不走 sid 去重，直接从事件层计数
- bounce_count 口径：有 video_play 但无 play_duration>=5s 的 (sid, video_id) 对
- 历史补数起点 2026-01-01，DDL 需显式 START/END 预建分区
