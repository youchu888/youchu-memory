# dev-20260714-001 真标签

- 2026-07-14 bus#4569 拍板 is_paid→order 事实；对齐日快照23列
- Phase0 报告：omdb/projects/user-tag/phase0_paid_amount_reconcile_20260714.md
