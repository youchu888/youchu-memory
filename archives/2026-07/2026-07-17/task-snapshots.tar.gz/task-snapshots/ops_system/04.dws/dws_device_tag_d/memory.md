# dev-20260714-002 设备标签

- 2026-07-14 又初接手（bus#4564 test全权）
- 目标表 `dws.dws_device_tag_d_d`
- 6 DWM 脚本在 `ops_system/03.dwm/dwm_device_*`
- prod 写动作 HOLD 等知秋令
- [假设·可回滚] 辅表单段 `_d` 保留

## 2026-07-14 test 验数（bus#4569）

- **根因**：wf globalParams `bucket_n` 空串 → `${bucket_n}` 未替换 → update_pool 空 → 0 行
- **修复**：`POST .../global-params` 设 `bucket_n=8` + `dt=$[yyyy-MM-dd-1]`
- **PI#58988** SUCCESS schedule=2026-07-13 → calc_dt=2026-07-12 **982,516 行**（旧表 982,515）
- wf：`wf_设备标签_日` 21969029457664；8 桶 b0=21971513829632 … b7=21971594792704
