# dwd_keyword_click_d 小时增量 — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 但又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-06-06
- 会话 dev-20260606-001 创建

## 2026-06-10
- 当前阶段按用户要求**只补 markdown，不改既有 SQL**；后续文档要和在线 SQL 口径对齐。
- 小时窗说明以 workflow 全局 `slot_start_time` / `slot_end_time` 为准，日补数保留最终校正口径。
