# memory · 页面停留 / sid 宽表

## 决策
- 从 0 新建，不改 ads_user_page_behavior_stats_d
- 知秋：先 dwm sid 宽表；相邻 PV 卡时间
- 狂人 bus#4083：1800s / 末页不计 / 空sid丢弃+dropped探针

## 进度 2026-07-14
- bus#4377 stage7 复审：技术面 PASS；整改① stage6 git 全套入库+push ② INSERT 补 16 列 col_list
- test 海豚已发 v145/146（col_list 版）
- 待：狂人复验 → stage7 PASS → 人工界面点 publish（知秋铁律禁 API 跳审）

## 进度 2026-07-15
- 牡丹 bus#4687 会话时长 DWS 联评：主路径 sid轻汇总→DWS；page_stay 降旁路
- 又初联评结论：用户侧 dwm 原地加列（不改名）；设备侧新建 dwm_app_session_sid_device_d
- 设计 v0.1：`ops_system/04.dws/dws_session_duration_d/design.md`
- test T-1 有数：page_stay 4398267 / session_sid 1164040
- duration_bucket 五档已按 PRD§5.5.3 定稿；本地草稿已落 ops_system，待走平台 session 发 test

session_code: dev-20260711-001
