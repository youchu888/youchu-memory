# memory · 页面停留 / sid 宽表

## 决策
- 从 0 新建，不改 ads_user_page_behavior_stats_d
- 知秋：先 dwm sid 宽表；相邻 PV 卡时间
- 狂人 bus#4083：1800s / 末页不计 / 空sid丢弃+dropped探针

## 进度 2026-07-14
- bus#4377：同父 session；dwm ETL 补 19 列 col_list；test 海豚 v146
- 待狂人复验 col_list + git SHA

session_code: dev-20260711-002
parent: dev-20260711-001
