# memory · page_stay_session

## 平台
- dev-20260711-001 / 002 · stage4
- test tasks: stay=22312343348736 sid=22312343918080 @ wf_dwd_事件明细_日

## 决策
- dropout 1800s / 末页不计 / 空sid丢弃+dropped探针
- DAG：旁路 page_view→stay→sid；主链 page_view→register（已修）

## 执行
- 18:00 脚本：`.claude/database/scripts/page_stay_18h_hang_validate.py`
- **2026-07-23 私聊#199**：主人要求停 18:00 自动发狂人 → `launchctl bootout com.youchu.page-stay-18h` 已卸载定时；需手动验数时 `PAGE_STAY_FORCE=1 python3 …/page_stay_18h_hang_validate.py`
- runbook：`AWAY_WEEK_RUNBOOK.md`（仅内部；对外禁止提个人行程）
- **隐私铁律**：行程/在岗状态只主人↔又初；bus/TG/日报禁止写
- bus#4118：结案认可；内容12.69/工具5.50 OK；test直修 prod报狂人+知秋；07-11起 dw 全量→趋势分段(07-10/11残缺 vs 07-13/14全量)
- bus#4139（#4138回执）：全量07-10健康——stay≈95.8万=keep_pv、dropped 0%；均PV 11.38→9.43 为全量更均衡（非劣化）；**bounce 28.2% 记全量基线**；**07-11 不补数等明天03:20**；明日18:00前交分段趋势（内容/工具+多dt）
- **私聊#78（07-13）**：近3日运行汇报已 bus 狂人（#4264），dt=07-10~12 全对账平、dropped 0%
- **bus#4265**：狂人 approve prod 审阅包；边界①18:00 launchd 先装②开发审核分离③prod 首日全量重刷；审阅包 `.cursor/dev-sessions/page_stay_session/PROD_REVIEW.md`
- **bus#4268**：stage5/6 done + request-publish pending(admin)；子002 stage7 pending
- **私聊#79**：18:00验数失败根因=launchd PATH无mysql + publish字段task_sql→new_sql；已修并重跑✅07-12对账平；平台API写工件content落库全空(服务端bug待狂人)
