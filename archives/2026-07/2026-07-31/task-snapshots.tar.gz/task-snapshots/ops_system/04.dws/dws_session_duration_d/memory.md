# memory · DWS 会话时长五档

session_code: dev-20260729-002（重建；旧 `dev-20260721-002` 已删：backend 文件 410 / 他人打不开）

## 2026-07-29 · 重建可打开 session

- 误把「设备标签」当打不开目标 → 已撤回 `dev-20260729-001` 对野花的 publish（设备标签无海豚发布需求）
- 真正打不开：`dev-20260721-002`（path-only + 内容已不在 backend → 410）
- 新建 `dev-20260729-002`：`project_id=dmp/dc-parent`，`rel_dir=ops_system/04.dws/dws_session_duration_d`
- **主人纠正**：空标 stage1~6 done 不够；野花插件要读 `strict_mode/owner_boundary/stage4_db_check/stage5_prod_dryrun/stage6_commit`
- **严格重走**（biz_dt=2026-07-28）：test 列/行/grain PASS；live SQL markers PASS；prod 两表 `__TABLE_MISSING__`；commit 已记
- `state_json` 现 26 key，五件齐；**request-publish** pending → **蓝猫**（主人 07-31 改派，原野花）
- 报告：`_strict_rewalk_report.json`

## 2026-07-25 · 合表落地

- 账号侧 + **设备侧** DDL/ETL 均已合表（stat_grain=session|daily）
- `dws_session_daily_user_d` / `dws_session_daily_device_d` deprecated
- **test 迁移**：DDL/DROP 用 `root@43.212.113.132:9030`（无密码）；`my.cnf.test` 的 admin 仅 dc_admin 角色，dws 无 DROP
- test 账号 dt=2026-07-24：session 870578/282260/bounce 639130；daily user 184944
- test 设备 dt=2026-07-24：session 1314326/720989；daily device 368098
- **#220**：`avg_session_duration_sec` + `avg_daily_duration_sec` 分列
- 海豚：`dws_session_daily_*` task 待停用；只保留 `dws_session_duration_*`
- **dev session `dev-20260721-002`**：outputs 4→2、DDL/ETL/task.yaml 已同步平台（2026-07-25）
- **test 发布**（2026-07-25）：user v137 / device v138；PI61929 SUCCESS；dt=2026-07-24 验数 PASS
- **request-publish** pending → reviewer=**蓝猫**（hull367660@gmail.com）；主人 07-31 改派
- **遗留**：daily 旧 task 22357870925056/22357871175296 仍在 wf（delete API 404），审核时建议下线
- **dev session**：`dev-20260721-002` 已同步 v2（title/outputs 2表/12 工件 push 平台）

## 2026-07-27 · 知秋统一分档

- 主人令：单次/日均、用户/设备 **一律候选 B**（bounce=0 + 60/300/900/1800）
- 设备 DWM 原 180/420 已改齐；design §3 废止 PRD 单次双轨
- 用户 DWM 本已是 60/300；野花 bus#5501 异议项据此消
- **git**：`bf316ab2` 已 push `origin/dev`
- **test 发布**（live=local）：device DWM 22357755019392 v231；user DWS v139；device DWS v140
- **补跑**：schedule=2026-07-27（dt=07-26）pi62412/62413/62414 SUCCESS
- **验数**：设备 DWM bucket1≤60、bucket2=61~300；bounce→0 违规=0
- 已 bus#5538 请野花再审 pending request-publish（后改派蓝猫，见 07-31）

## 2026-07-31 · 知秋钦定：收敛单目标表（bus#5789）

- 狂人 admin `fix-metadata`：`outputs` / `dolphin_owned_tasks` 已摘 `dws_session_duration_device_d`
- 又初跟进：PUT `/full` 更新 `related_tables`；`task.yaml` 仅 user；设备三文件移至 `_parked_session_duration_device_d/`
- 设备 DWM 新 session：`dev-20260731-001`（`job_dwm_app_session_sid_device_d`），须先 prod 再开设备 DWS session
- 本 session request-publish 仍 pending → 蓝猫

## 2026-07-31 · prod 用户表上线 + 数据字典（bus#5802）

- 狂人 prod 建 task `180283360953472`；知秋重建表（`history_partition_num=30`，`start=-10000`）
- 07-30 首补 SUCCESS；design.md 已补 §10 数据字典 + §11 口径 A/B/C
- PUT `/full` 合并 prod dolphin_owned_tasks / stage5 / prod_target（未覆盖设备摘出）


## 2026-07-28 · 旧 daily_* task 下线

- test `wf_dws_汇总_日` 删除 `dws_session_daily_user_d` / `dws_session_daily_device_d`（表早 DROP，task 残留导致汇总日调度挂）
- 根因：合表半迁移；已沉淀 lesson `2026-07-28-deprecate-must-offline-old-dolphin-task`
