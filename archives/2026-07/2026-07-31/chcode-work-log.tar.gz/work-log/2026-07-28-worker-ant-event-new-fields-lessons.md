# 群消息沉淀 · event_new_fields bus#5596/5597 · 2026-07-28

来源：工作狂人 @worker_ant_bot → 蓝猫 event 新字段复审 PASS

## 可复用规则

- [LESSON: INSERT/ETL 通用 | 凡 INSERT INTO/OVERWRITE 写表必须带显式 col_list，与 SELECT 逐列对齐；加/换列首稿就要齐，禁等 review 打回（bus#5588 B1 硬 blocker，活教材 dim_user_all 2026-07-02）]
- [LESSON: 多段 ETL | 同一表日批+小时、多 event 类型各算一段 INSERT，每段独立 col_list；event_new_fields 5 表共 8 段]
- [LESSON: DDL↔ETL 宽度 | ETL 中 LEFT/TRUNCATE 宽度须与 DDL 声明一致（如 recommend_trace VARCHAR(256) 则 LEFT 256 非 64），即使当前数据未触顶]
- [LESSON: 字段变换文档 | -1→NULL 等清洗规则须在 SQL 注释与 review HTML 逐列写清「做/不做」，禁笼统「click DOUBLE + -1→NULL」]
- [LESSON: 狂人复审验放 | 三路验：git diff 全 col_list → col_list↔SELECT↔DDL 逐列对齐 → test 海豚 publish 后 API 拉 sqlStatement 对头注释]
- [LESSON: 新列发产 | ALTER + publish DWD 同批；禁历史 COMPLEMENT；session 转 knight 后 request-publish，prod 由 admin 发，又初不自发]
- [LESSON: 发产后验 | 次日抽查新列覆盖率，不补历史]

## 待同步 canonical

写入目标（需同步至 ~/.dc-platform/memory/）：
- feedback_insert_into_explicit_column_list_safety.md
- lessons/2026-07-28-event-new-fields-col-list-review-pass.md
