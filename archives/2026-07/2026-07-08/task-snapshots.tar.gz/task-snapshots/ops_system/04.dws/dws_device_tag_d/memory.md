# 设备标签体系 — 会话备忘录

## 2026-06-03

- 会话 `dev-20260603-002`，与用户标签 `dev-20260602-001` **并列**展示（勿挂 sub_session）
- 目录：`ops_system/04.dws/dws_device_tag_d`
- Stage 4 执行器用 mysql2；stripSqlComments 须先删块注释再删行注释（`/* --- */` 内含 `--`）

## 2026-06-02

- sr_test 若仍为旧表（含 dt 分区）需 DROP 后重跑 DDL 再 init
