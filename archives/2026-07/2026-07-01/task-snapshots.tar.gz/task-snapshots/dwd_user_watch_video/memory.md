# Memory：dev-20260617-001 · dwd_user_watch_video

## Session 要点

- 从 **dev-20260616-001** 拆分；一 Session 一主表
- 交付物：`ops_system/.../dwd_user_watch_video_daily.sql`（已改造 _new + DATE_ADD dt 双扫）
- test stage4/5 结论沿用父 Session；本 Session 规范文档 + 平台 metadata
- HTML 6-16：prod **直接下线**，不走并行双跑

## 平台

- rel_dir：`dwd_user_watch_video`
- 占位 `dwd_user_watch_video_d_d/` 作废
