# 关键词分析（词粒度 · 小时+日批 · PRD v1.0.2） — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 但又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-06-03
- 会话 dev-20260603-001 创建
- stage 1：spec.md §1–§6 已写入；§0 表单原话未改；PRD v1.0.2；16 列含 post_click_cnt
- 标准库：`click_cnt`/`user_type` 为 proposed；其余指标 stage 3 propose

## 2026-06-16 hotfix：过滤 keyword 字面量 null

- **改动**：DWD hourly/daily + ADS hourly/daily 增加
  `AND LOWER(TRIM(keyword)) <> 'null'`
- **原因**：JSON null 序列化为字符串 "null"，原 IS NOT NULL 拦不住
- **test**：publish 3 任务 + TASK_ONLY 2026-06-15 SUCCESS；null=0；playbook 9/9
- **prod 基线**（只读）：ODS 677 / DWD 616 / ADS 13 null 行；待 Stage7 补跑
- **search_uv**：不改 ETL；查数用 BITMAP_COUNT(search_uv)

## 2026-06-22 click_item_type_key 大写规范化
- 知秋确认：DWD `click_item_type_key` 归一为大写（VIDEO/NOVEL/COMIC/POST），硬编码 CASE WHEN 过渡，等上游 ETL 自动映射后再改
- ADS hourly/daily 已用大写过滤（代码层无需改，早已是 `'VIDEO'`/`'NOVEL'`/`'COMIC'`/`'POST'`）
- playbook CP3 过渡说明：2026-06-22 前历史 DWD 数据为小写，CP3 对历史分区会报 diff（预期）
- test `dwd_keyword_search_h` 最新 dt=2026-06-16，ADS 补数用该日期验证；2026-06-22 DWD click 数据大写验证 OK（VIDEO=17, COMIC=5）
- 平台 stage4 三关全勾；stage5 P0-P11 已做（pass=10，P6 预期 fail）；可进 stage 6 commit