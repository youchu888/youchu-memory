# 【归因看板日指标】dws_register_attribution_metrics_d_d — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 但又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-06-24
- 会话 dev-20260624-001 创建
- stage 3：DDL/ETL 首版落盘（对齐 ops_system 归因汇总逻辑；分区预建 2025-12-20～2026-06-27）
- test 海豚 DAG：方案 A 定稿 — `result_d → channel_apply → metrics → recharge`（wf v42）；写回 KPI 须在 channel_apply 之后

## 2026-07-01
- bus#652 P0：test `wf_dws_汇总_日` v73→**v74**；脚本 `dc-platform-server/scripts/reorder_wf_attribution_first.py`
- bus#664：`rewrite_status` 列错位 → publish v75 + 补跑
- **P0 验数通过**：prod 整日灌样 dt=2026-06-28（7553 reg / 5792 view）→ test ETL **567/567** 与 prod 金标字段一致；报告 `reports/attribution/validate__2026-06-28__test_prod_sample__20260701.md`
- runbook 新增 `copy-sample-to-test`（`attribution_runbook.py`）
- **P1 已建（test）**：`wf_归因落地页快路_日` **22204696592512** schedule `0 10 0 * * ? *`；汇总日 v76 加 `等_归因落地页快路_日`；脚本 `create_wf_attribution_fast_path.py`；#55546 SUCCESS
- **P2 已收尾（test）**：deduction_d v15；渠道分析 sched#125 cron 00:15；结算首跑 v10 DEPENDENT+sched#126 00:18；脚本 `patch_wf_settlement_p2_tail.py`
- **bus#652 test 落地结案**：报告 `validate__bus652_test_closeout__20260701.md`；**已到可发prod节点即结案**；prod 发布等知秋令后**另开新任务**
