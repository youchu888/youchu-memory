# memory

- 会话 `dev-20260610-904`，rel_dir `ops_system/04.dws/dws.dws_register_attribution_result_d`
- 2026-06-10 口径反转：attribution_flag=1（客户端标记需归因）才计算；0/NULL 跳过
- 测试 dws task v5 已上线；schedule 发布后必须复位 ONLINE（踩坑 2026-06-09）
- 生产上线前置：dwd_user_register_d_v2 加 attribution_flag、dim 配置加 is_rewrite_channel（生产 SR readonly，需海豚/ETL 账号执行）
- 2026-06-30 私聊#30/#32：`rewrite_status` TINYINT 落结果表；1=成功/0=失败/NULL=不适用；channel_apply 回写
- 2026-06-30 worker_ant 审核：test 影子验过（06-28 567 行全 NULL）；**可上 prod 影子**；禁单独重跑 result；灰度勿与 A 类/geo 并发写 dim_user_all
- 2026-07-01 prod 故障：表已加 rewrite_status(28列)但 result ETL 仍27列无列清单→05:25起全链挂；又初侧仅 test DDL/发布，prod 须知秋令+ETL同步
- lesson：`~/.dc-platform/memory/lessons/2026-07-01-rewrite-status-prod-schema-etl-mismatch.md`
- 经验：.claude/memory/lessons/20260609-attribution-flag-column-order.md
