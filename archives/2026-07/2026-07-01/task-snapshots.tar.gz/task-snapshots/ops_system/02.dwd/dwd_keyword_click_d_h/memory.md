# dwd_keyword_click_d 小时增量 — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 但又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-06-22
- stage4 playbook 复核（sr_test，因 dc-platform MCP 异常改用本地 mysql CLI，MySQL 9.x 客户端须加 `--default-auth=mysql_native_password` 否则 native_password 插件加载失败）：CP3 幂等 PASS（dt=2026-06-12 rows=distinct_pk=182461）、CP4 keyword LEFT600 PASS（max_len=45/over_600=0）；CP1/CP2 受阻（今日 dt=2026-06-22 分区 0 行，hourly 未在 test 跑）；CP5 ADS 类型分桶仍按未规范化原值（ADS video=118152≈原值 video=120087，非规范化后 ~159838）→ 规范化 ETL 尚未在 test 重跑。待 MCP 恢复补跑后复核 CP1/CP2/CP5。
- click_item_type_key 大写规范化（过渡方案，硬编码 CASE WHEN）已改入 hourly/daily ETL；映射规则见 ops_system 项目 memory。
- 对账（test sr_test，dt=2026-06-12，182461 行）：映射后 18 原值合计 = 总行数，**零丢行、零 NULL/空**；VIDEO=159838 NOVEL=68 COMIC=765 POST=21384，与枚举聚合一致 → 映射逻辑 PASS。
- 兜底大写未归类项：community(352)/pic/graph/user/blogger/txt → 进 click_cnt 不进四类分类计数，待业务确认 community 是否单列。
- 2026-06-22 第二轮（dc_api.js fallback）：修 dwd_ad_click_h localParams bug（${var}→$[expr] 内联宏）→ publish；publish 本会话 hourly v41（CASE WHEN + dw_user_event_detail_new + dt IN 分区裁剪）；TASK_ONLY complement 12:00-14:00 两 slot SUCCESS；CP1/CP2/CP3 pass；CP5 ADS 待 scheduler 修复后重验；测试数据发现 `video_video` 原始值 2 条规范化为 `VIDEO_VIDEO`（未覆盖），待业务确认是否加 CASE WHEN `WHEN 'video_video' THEN 'VIDEO'`。
- 平台侧操作全程走 dc_api.js 直接 HTTP，MCP 不可用期间可用。
- 2026-06-22 wf 全扫：`wf_广告渠道扣量_小时`（21869819046144）9 个 task，6 个带 `${var}` 占位符。已修 dwd_ad_click_h / dwd_coin_consume_h（直接阻塞本 session）。剩余带占位符且**不属于本 session**（渠道/订单链路，别的 owner）：dwd_order_created_h（11 占位符，同 partition 漏配模式，几乎必 fail）、dwd_order_paid_h、dws_app_channel_deduction_h、dws_app_channel_summary_h、ads_channel_promotion_summary_h。用户钦定**停在这**，不越界改别人业务，扫描结论告知负责人/知秋。本 session task dwd_keyword_click_d_hourly 16:03 SCHEDULER 已 SUCCESS。

- 2026-06-22 第三轮 `/dc-stage4-playbook-check`（scripts/playbook_check_click_d_h.js，sr_test MySQL CLI fallback，MCP server errored）：CP1-CP4 全 pass（hourly SUCCESS 17:03 / slot cnt=10 / today rows=distinct_pk=18 / 代码 LEFT600 无 SUBSTR2048）。CP5 fail = ads.ads_keyword_analysis_d_h 今日 0 行（该表最新 dt=2026-06-16），根因在下游 ADS（dev-20260603-001，wf `ads_关键词分析_*` 当前未在 test 21 个 wf 列表中、未小时调度），**非本 session dwd 代码问题**。本 session DWD 交付判定通过。

- 2026-06-22 `/dc-stage5-datacheck`（scripts/stage5_datacheck_click_d_h.js，sr_prod readonly dry-run + sr_test）：**全 6 项 pass**（biz_dt=2026-06-21 完整日）。DC1 prod dry-run hourly rows=2,964,019；DC2 prod 整日 dw=83,376,511 vs dwd=83,311,989 diff 0.077%；DC3 test dwd≤dw；DC4 LEFT600；DC5 幂等 13=13；DC6 today_cnt=18。⚠️ 坑：harness 默认 biz_dt=MAX(dt)=今天，今天分区还在小时累计→DC2 算出 2.62%>2% 假 fail，**整日对账必须用已跑完的完整日**（指定昨天），别用当天。

- 2026-06-22 `video_video` 结论：**test 脏数据，prod 无，不加 CASE WHEN 分支**。prod readonly 验：`dw.dw_user_event_detail_new` keyword_click 的 click_item_type_key distinct 原值 dt=2026-06-21（74M 行）与 dt 2026-06-15..21（435M 行）都只有 {video, comic, novel}，全被现有显式分支覆盖，ELSE(UPPER) 在 prod 不触发 → 规范化映射对 prod 真实值已完备。CASE WHEN 不需要为 test 脏值兜分支。

## 2026-06-06
- 会话 dev-20260606-001 创建
