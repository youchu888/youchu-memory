# dw明细表迁移 — 2026-06-13 源表切 _new

## Phase1（dwd #1~#4）— 已完成

- 4 路 ETL 源表改为 `dw.dw_user_event_detail_new`
- test 已建 VIEW 兼容（改名后 detail 即原 _new）
- 海豚发布 v38/39/27/28；日批补数 PI 51068 SUCCESS
- 验证 2026-06-12/13：raw 与 dwd 行数完全一致
- git dev 分支已推送 commit 20a3b19
- 小时补数 PI 51069 login 首小时 FAILURE（日批已覆盖，待重跑小时）

## Phase2（dws 渠道 3 表）— 2026-06-16

- **范围**：直连 `dw.dw_user_event_detail` 的 DWS 渠道汇总表，同过渡方案加 **dt 双扫**
- **表**：`dws_app_channel_dau_d`（日）、`dws_app_channel_summary_d`（日）、`dws_app_channel_summary_h`（小时）
- **改动**：`dw.dw_user_event_detail` → `dw.dw_user_event_detail_new`；WHERE 增加  
  `dt IN (DATE(${start_time}), DATE_ADD(DATE(${start_time}), INTERVAL 1 DAY))`
- **仓库**：3 个 SQL 已写入 `ops_system/04.dws/dws_app_channel_*/`
- **参考**：`db/dws/dws.sql`、`db/dws/用户活跃.sql` 同步更新
- **待办**：发布 test 海豚（wf_渠道分析_日 / wf_dws_汇总_日 / wf_广告渠道扣量_小时）→ 对账 → 提交 dev
