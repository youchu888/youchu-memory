# memory · dev-20260804-001

- 显示名：【归因Paimon影子压测】result/apply/metrics_r · 又初
- test wf 已 ONLINE；T-1 0 行因湖 `attribution_flag` NULL，按拍板不改口径
- prod `_r` / 影子 wf 未建 → Stage5 WARN；Stage7 申请审核后由审核人发
- 审核人：平台指定 `admin`（可发 prod）；同步 bus 狂人协调审核发布
- 关联：现网会话 `dev-20260610-904` / `dev-20260701-001` / `dev-20260624-001`（只读现网，不混本影子链）
- 探针长文：`../dws.dws_register_attribution_result_d/paimon_shadow_probe.md`
- Stage6 commit `71c81aa4` pushed origin/dev · 2026-08-04
- Stage7 request-publish pending · reviewer=admin；bus#5944 已请狂人审核发布
