# memory · dev-20260727-011

## 2026-07-27 stage 3
- 不拆子：父持 3 outputs（同 010）
- 表名保持单段 `_d`

## 2026-07-28 PK 压缩
- 三表 PRIMARY KEY；VARCHAR 缩短压 ≤128
- request: app/slot=32；funnel: type=16 ad_id=40；error: 无 ad_type，ad_id=32 ec=20 es=8
- ETL `LEFT(...,N)` 对齐；test 样例日 max 远小于上限

## 2026-07-28 stage 4 Part A
- sr_test 建 3 表 + 只跑 2026-07-24；不补历史
- CP1~5 全过；fill DISTINCT=1847（非行数 1853）
- 等用户面板勾三项后做 Part B 海豚

## 2026-07-28 stage 5
- sr_prod dry-run：6 上游 DWD + 3 DWS 均不存在 → blocked
- 上游 `dev-20260727-010` stage=7 pending、`prod_table_built=false`
- 用户选方案 2：接受跳过 prod dry-run、以 test 为准 → 推 stage 6
