# memory · dws_app_event_funnel_d_d · 大漏斗

- 显示名：【大漏斗事件统计】dws_app_event_funnel_d_d · 又初
- **口径权威**：http://54.255.236.159:8012/library/metric_big_funnel_event_dictionary  
  仓库副本：`docs/event_dictionary_big_funnel_20260801.html`
- 后端对接：`后端对接说明.md` · 对外副本 `omdb/tgbot/outgoing/大漏斗表结构-后端对接-2026-08-11.md`
- 需求材料目录：`materials/`（知秋对齐纪要 + 索引；DDL/ETL 待回补）

- 2026-08-11：整理后端对接说明（表/字段/上卷/转化率现算/示例 SQL），与页面访问对接文档同级结构

- 2026-08-07：主人确认保留知秋 bus#6161 全量材料（不因「只要程序框架」丢弃）；已落 `materials/worker_ant_alignment_20260807.md`
- 2026-08-07：口径 8 项已关闭（08-05 起）；写 SQL 前必看大小写 + 新旧命名覆盖率坑；知秋六条已入库
- 2026-08-07：已回 bus#6163 只要 DDL + 落地 SQL/骨架 + 海豚挂法；等知秋回后追加进 `materials/`
- 2026-08-07：主人定案 — **跑数引擎 = Spark**（非海豚 SR SQL 日批）。参考同仓 `dws_user_tag_d_d` / `dws_device_tag_d`：本地写代码推仓，集群由知秋侧 submit；字典里「INSERT OVERWRITE PARTITION」是口径/表形态描述，落地形态改按 Spark（spark-sql 或 Scala job，待知秋骨架）
- 2026-08-07：主人令「不用等知秋，直接开始」→ 已建平台 session **`dev-20260807-big-funnel-001`**（project_id=`dmp/dc-parent`）；stage1–2 done、stage3 in_progress
- 2026-08-08：stage3 集群试跑：Paimon DDL OK；日批首跑卡在 dim_user_daily_snapshot 未落湖 → 已改 user_is_new CTE（dim_user_all_d_d.register_time）
- 2026-08-08：全量 S profile 22min 仍 ~10%（user_is_new JOIN dim_user_all_d_d 无 dt 分区全表 ~1.5 亿行）→ 已改 reg_uids 用当日 user_register 事件推导 is_new，去掉 dim 全表 JOIN
- 2026-08-08：metric_rows 18 路 UNION ALL 计划过大 → 已改各源条件聚合 + keys 外连接宽表；S profile shuffle=100
- 2026-08-08：第三轮 SF-81 冒烟（app_2556）跑 ~2h 后 stage37 executor OOM；S profile 已提 driver 8g / exec 12g / 8 executors，关 CBO
- 2026-08-08：为压低 stage37 内存峰值，已把 `dws_app_event_funnel_d_d_daily.sql` 从单条超宽 `COUNT DISTINCT CASE` 重构为「每事件独立聚合 + keys 外连接拼宽表」；口径不变，待第 4 轮 SF-81 冒烟验证
- 2026-08-08 21:57：第 4 轮 SF-81 冒烟已提交集群（dt=2026-08-03, profile=S, app=app_2556）；YARN `application_1782286624361_2559`；SQL 已同步 `/tmp/dws_app_event_funnel_d_d_daily.sql`（24KB 重构版）；日志 `/tmp/funnel_smoke_r4.log`
- 2026-08-08 22:10：**第 4 轮 FAIL**（~13min）· `application_1782286624361_2559` Final-State=FAILED。根因 **driver Java heap OOM**（`SparkSQLDriver` 在 query plan/explain 阶段 `TreeNode.generateTreeString` 爆堆），非上轮 executor stage37 OOM。重构版已避开超宽 distinct 聚合，但 CTE 层数多导致 driver 编译计划过大。
- 2026-08-08 22:20：**两阶段 ETL** — stage1 `metric_stg` 长表（18 路 UNION ALL 独立聚合）+ stage2 `MAX(CASE…)` pivot 宽表；新增 Paimon 表 `dws_app_event_funnel_metric_stg_d`；S/M profile driver 提至 16g。弃用单文件 keys 外连接版 `daily.sql`。
- 待验：第 5 轮 SF-81 冒烟（dt=2026-08-03, profile=S, app=app_2556）
- 2026-08-08 22:21：**第 5 轮 PASS（运行时）** · 两阶段 ETL：`application_2563` stage_metrics ~267s + `2564` stage_wide ~3.6s，**无 driver/executor OOM**（对比第 4 轮 13min driver heap 失败）。`app_2556` 过滤产出 0 行（疑 app_id 应为 `SF-81`），已补跑 r5b（SF-81）。
- 2026-08-09：**r5b 验数闭环** · `application_2575` stage_metrics ~6.3h + stage_wide ~17s，日志 `done ===`。**根因**：冒烟脚本误传 `app_2556`（源表 0 行），正确 app 为 `SF-81`（~6022 万行）。Paimon 产出：宽表 3 行（is_new=-1/0/1 各 1，粒度正确）、stg 39 行；无 OOM。
- 2026-08-09：`run_yarn_daily_sql.sh` 已拦截 `app_2556`；README 补冒烟记录与 SF-81 默认命令。

- 2026-08-10：**spot-check PASS**（SF-81 dt=2026-08-03）· 报告 `.claude/database/reports/dws.dws_app_event_funnel_d_d/validate__2026-08-03__spot_check_20260810.md`
  - video_view 小写 106,906 与 dwd 对齐；novel/comic `VIEW` 大写对齐
  - page_view 漏斗 UV 100,849 < dwd 全量 103,232，page_key>1 过滤生效
  - stg 39 行 / 宽表 is_new 三档各 1 行复验 OK

## 下一步（stage3→4）

1. ~~口径 spot-check~~ **已完成**
2. **全量压测**：`M` profile 无 app 过滤跑 **T-1=2026-08-09**，记 stage_metrics 墙钟；>2h 再评估 day_uids 四表 UNION 能否缩窗。
3. **平台推进**：M 压测有结论后 stage4 写证据，commit 推 `origin/dev`（目录当前未进 git）。
