# memory

- 会话 `dev-20260610-904`，rel_dir `ops_system/04.dws/dws.dws_register_attribution_result_d`
- **bus#4228 案结（2026-07-12）**：#4171「断供」叙事作废。知秋定性 `attribution_flag`=注册自带入参，test 全 0=业务真实、链路无坏不修。日常 result 狂人已修 wf_dws_汇总 v120 照跑；快路 wf result 副本残版（INSERT29/SELECT28，与宏无关）已撤回 OFFLINE。
- **二期备忘**：①快路 result 列数对齐；②分区/业务日宏按铁律 knowledge#10（$[] 替代 ${}）。OFFLINE 来龙去脉不用写。
- 2026-07-12：仓库 SQL 已改 PARTITION/业务日走 $[]（bus#4220）
- 2026-07-11：对齐 prod（含 attribution_flag=1）；test 同步 prod；已推 remote dev
- 2026-06-10 口径反转：attribution_flag=1（客户端标记需归因）才计算；0/NULL 跳过
- 测试 dws task v5 已上线；schedule 发布后必须复位 ONLINE（踩坑 2026-06-09）
- 生产上线前置：dwd_user_register_d_v2 加 attribution_flag、dim 配置加 is_rewrite_channel（生产 SR readonly，需海豚/ETL 账号执行）
- 经验：.claude/memory/lessons/20260609-attribution-flag-column-order.md
- **bus#4492（2026-07-14）**：#4 宏改造 test 验数造样：prod golden 100 条（dt=0713 非 organic 成功）→ test 灌样+complement schedule 0714 05:20→golden 100/100 对齐；清理对平 reg100/click137/view250。脚本 `attribution_copy_golden_to_test.py`。
- **JHG 六 app 开算（2026-07-25）**：`dim_app_attribution_config` 已 INSERT 015/052/059/064/087/092（is_run=1, rewrite=0）。T-1 prod 六 app iOS organic 注册有量但 **attribution_flag 仍全 0** → result_d 0 行；等客户端开 flag 后 complement。
- **Paimon 影子 B 线（2026-07-25）**：`_r` 表+SQL（bd64e46f）；CAST staging 已修。prod click 与 SR 齐；**paimon.register.attribution_flag 全 NULL**（SR 有 9.4万 flag=1）为压测阻塞。见 `paimon_shadow_probe.md`。
- **Paimon 影子全链（2026-08-03）**：按拍板落 test 全链 `_r` + 独立 wf `wf_dws_归因_paimon_shadow_日`（22565681487488）调度 ONLINE 06:30；试跑 08-02/06-12 均 SUCCESS（~6–8s），行数 0（flag 同现网入围）。prod 未动。
