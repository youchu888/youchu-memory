# memory · 用户日停留汇总 DWS

## 决策
- bus#4912 知秋终稿：sid 宽表=中间层；最终交付=uid×dt 日停留汇总
- **2026-07-21 主人令**：整条停留线（uid 日汇总 + 五档 DWS）归又初，不再经小花
- dwd/dwm 照跑不动

## 进度 2026-07-16
- bus#4912 ACK；spec.md + design.md + division_alignment.md 已落本地
- platform session dev-20260716-001 已 sync（2026-07-21 晚补 artifact）

## 2026-07-17 bus#5044 设计稿复审（4b365a85）

- stage1/2 PASS（带澄清项）
- **C1**：采纳双字段 `session_cnt` + `valid_session_cnt`；均值分母用 valid
- **C2**：design §2 逐字段标来源（sid 首会话 vs dim 快照）；dim 无 source_type
- **C3**：spec §7.6 写清 sid 跨 uid 对账边界（test 07-16 约 4899 sid）
- 已修订 spec/design 待狂人复核落字

## 2026-07-21 (续)

- stage3 DDL：test 建表 `dws.dws_user_page_stay_d` 成功
- stage4 ETL：dt=2026-07-20 写入 282564 行；行数= sid distinct uid；stay_sum=164657525 与 sid 完全一致；null uid=0
- 海豚 create-task API 404，test task 待平台/手搓挂 wf_dws_汇总_日
- prod 卡点仍 DWD+DWM publish 等知秋界面点放行

## 2026-07-21 晚
- DWD+DWM 已 request-publish pending；本表 **不跟本批 prod**，继续 test（stage5 / 挂海豚）
- **19:45** stage5 验数 PASS（dt=2026-07-20）：uid 282511 / stay_sum 164657525 与 sid 层逐位一致；null uid=0
- 平台 path 登记齐；**stage6 in_progress**
- **卡点**：~~test 海豚 `dws_user_page_stay_d` task 未挂~~ → **已挂** wf_dws_汇总_日 task_code=22426102513280

## 交付门禁（私聊#177 · 2026-07-21 19:35）
- 与 `dev-20260711-002` + `dev-20260721-002` **一并**验完再 publish
- 全链完成后：发群数据流说明 → request-publish 审核人=**野花**

## 2026-07-21 20:15
- stage6 done；git push `session-duration-bucket-b` @ be4974d2
- 四 session 一并 `request-publish` pending，审核人=**野花**（kakakh7787@gmail.com）
- 群已发数据流说明 @野花

session_code: dev-20260716-001
parent: dev-20260711-002
