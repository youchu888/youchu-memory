# memory · dws_app_page_visit_d_d · dev-20260804-002

- 显示名：【页面访问·日指标】dws_app_page_visit_d_d · 又初
- **口径权威**：http://54.255.236.159:8012/library/metric_page_visit_analysis（2026-08-05 对齐）
- 表：`dws.dws_app_page_visit_d_d`；只账号；进入=来路空/`unknown`；跳转边表已删
- 只落分子分母；比率查询侧现算；uid_cnt=BITMAP
- 2026-08-06：主人令 — 改好后提交 → 发 test → 验数通过 → request-publish

- 2026-08-06 11:52：test 挂 task `22599391396992`（wf_dws_汇总_日 v167）；PI64878 SUCCESS；dt=2026-08-05 rows=20062 pv=5890928 uv=309818
- 2026-08-06 11:52：git `ceace1b7` 已 push；request-publish pending → 野花（kakakh7787@gmail.com）
