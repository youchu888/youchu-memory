# 3.5落地页指标小时表（合规重建）— 会话备忘录

## 2026-08-01
- 会话 dev-20260801-001 创建。
- hour 为分区字段，dt 为普通字段；frequency=daily，partition_grain=hour，因此规范表名后缀为 h_d。
- 旧 session `dev-20260801-landing-metrics-01` 和旧测试表 `ads.ads_landing_page_metrics_h` 保留，不删除、不作为本会话交付物。
- 生产环境仅允许只读查重，禁止生产写入。

## 2026-08-04

- 用户确认Stage 3代码复核；开发平台已推进为 `Stage3=done`、`Stage4=in_progress`。
- `sr_test` 实时查重时目标表不存在；随后仅在test执行DDL，回读18列、小时表达式分区和普通字段 `dt` 均符合设计。
- 原小时SQL只读 `EXPLAIN` 被 `Unknown partition 'p2026073123'` 阻断，未执行ETL。
- 语句级 Dynamic Overwrite 的小时、日临时SQL均通过test `EXPLAIN`，但源码尚未修改；继续前需要重新审核空集清理语义并回退Stage 3改码。
- 用户确认修复方案后，开发平台回退为 `Stage3=in_progress`、`Stage4=pending`。
- 两份ETL已改为语句级 Dynamic Overwrite 并移除物理分区名；真实test `EXPLAIN`由RED转GREEN，开发平台lint均为 `0 error / 0 warning`。
- Dynamic Overwrite全窗口输出0行时可能不触碰旧分区；playbook已增加候选输出行数与目标现有行数的强制门禁，ETL尚未执行，等待Stage 3重新人工复核。
- 用户再次确认后重新进入Stage 4。小时任务固定跨日时间连续执行两次均为821行，日任务固定T-1连续执行两次均为8,697行；各自业务快照哈希一致，日批后的22/23点快照也与小时任务一致。
- 目标表已生成24个小时分区；主键、dt、非负、Bitmap、访问PV、下载PV和三类归因抽样检查均通过。
- 固定业务日不存在下载点击IP为空的样本，下载PV无IP过滤仅由源码和完整源目标对账证明，运行时空IP边界仍未覆盖。
- 测试DS `运营系统` 项目实时查重为0后，新建 `wf_广告落地页_小时`(22580689470720) / task(22580689387648) / schedule(150) 和 `wf_广告落地页_日`(22580704360704) / task(22580704277504) / schedule(151)，工作流与schedule均ONLINE。
- DS 3.1.9要求workflow ONLINE后才能创建schedule；首次小时创建停在OFFLINE且无schedule，随后仅对显式owned code做SQL/DAG一致性校验后恢复，没有删除或覆盖。
- 手工START_PROCESS虽然显式传scheduleTime，但实例回读为null且内置宏按实际触发时刻解析；小时实例64394/task176607和日实例64395/task176608均SUCCESS，实际窗口分别为2026-08-04 17/18点与2026-08-03。
- `sr_test`回读：小时窗口4行/2小时，日窗口8,928行/24小时；空主键或dt异常、负数、Bitmap计数差异、重复主键组均为0。
- 开发会话 `dolphin_owned_tasks` 已登记两条测试任务；中文编码纠偏后回读 `diffs=0`。
- OpenMetadata/平台可见性仍阻塞：平台搜索0条、详情和在线血缘均404；当前部署没有`POST /api/v1/tables/sync-from-openmetadata`（调用为HTTP 405），网页登录态`POST /tables/sync`实跑结果`added=0, updated=322, skipped=0`。目标FQN尚未进入OM，未声称平台可搜索，Stage 4保持in_progress。
