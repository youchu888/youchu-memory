## 2026-07-16 11:34

- 野花问 test/仓库是否齐：仓库早已改 `_h`；**test 刚才未齐**，已用平台 `publish-task-sql` 补齐 early v9 / full v26，自验 h=True；prod 仍 h=True。

## 2026-07-16 11:25

- 野花令：`dwd_order_created` / `dwd_ad_click` 有 `_h` 则改读 `_h`。
- 核数：`created_h` 07-15=60528 行；`ad_click_h` 07-15≈3409 万行。与快照交集预计 ordered≈4.2 万、clicked_ad≈507 万。
- 已改仓库 early/full/分段/task.yaml/spec/playbook；**prod** 海豚 early+full SQL 已 PUT 并 ONLINE（sched#25/#8 仍 ONLINE）。test 同步视连通性。

## 2026-07-16 10:48

- 野花要现状报告+昨日分区核数：已写 `.Codex/database/reports/dim_user_daily_snapshot_status_20260716.md`。
- prod `dt=2026-07-15`：行≈1959.8万；Σpaid=269,514,150 = dwd；PK dup=0；品类有量≈654万。
- 昨日最终态来自早窗 pi21862 + 补算 COMPLEMENT pi21980；维度日 pi21911 **尚无** full task。新 early/full 定时实跑待明日。

## 2026-07-16 10:29

- 野花问 md 是否齐：此前仅 `task.yaml`/`memory.md` 新；已补齐 **`design.md` §4/§6、`playbook.md` 前置、`spec.md` §2.5/产物表** 对齐合并调度。

## 2026-07-16 10:22

- **prod 已同步**（野花令「同步prod」）：
  - `wf_用户日快照_日` ONLINE：单 task `dim_user_daily_snapshot`（early SQL）；sched#25 00:15 ONLINE tenant=dolphinscheduler
  - `wf_dim_维度_日` ONLINE：新增 `dim_user_daily_snapshot_full`，边=`等_dwd_事件明细_日`→full；sched#8 04:50 ONLINE
  - `wf_用户日快照_日_补算` OFFLINE；sched#26 OFFLINE
- test 验跑已 PASS；prod 实跑未做（等令）。

## 2026-07-16 10:15

- **test 验跑 PASS**（COMPLEMENT，tenant=`dolphinscheduler`）：
  - 早窗 pi=`59375`：`dim_user_daily_snapshot` SUCCESS（有日志）
  - 维度日 pi=`59376`：`dim_user_daily_snapshot_full` SUCCESS（有日志）
  - test 表 `dt=07-15` 行≈45.2万，有 paid/login/pv/品类量
- prod 仍未 sync。

## 2026-07-16 10:01

- 野花令：先 test 后 prod。合并方案落地 **test**：
  - `wf_用户日快照_日`：只留 `dim_user_daily_snapshot`（early=s1+s2 SQL）；摘掉 s2；sched#127 00:15 仍 ONLINE
  - `wf_dim_维度_日`：新增 `dim_user_daily_snapshot_full`（s1b+s2+s3），边=`等_dwd_事件明细_日`→full；sched#101 04:50
  - `wf_用户日快照_日_补算`：sched#128 OFFLINE + wf OFFLINE
  - 仓库新增 `dim_user_daily_snapshot_early.sql` / `_full.sql`；`task.yaml` 已改目标态
- **prod 未动**，等 test 验跑后再 sync。

## 2026-07-16 09:24

- 野花令：补算定时改 **04:50**（避开事件明细未齐）。
- prod schedule **#26**：`0 30 3 * * ? *` → **`0 50 4 * * ? *`** Asia/Shanghai；仍 ONLINE / tenant=`dolphinscheduler` / worker=`default` / failureStrategy=END。
- 今早定时失败根因：DEPENDENT 等事件明细时上游尚未 SUCCESS；白天 COMPLEMENT（tenant 对）已补齐 dt=07-15。

## 2026-07-15 18:20

- 野花回「建好了」：prod 表核过（23列 / repl=3 / colocate / 分区 p20260715+）。
- schedule **25/26 ONLINE**；`prod-publish/complete` → PublishRun **#333–338**；stage7 **done**；publish_request **approved**。
- 首跑：明天 **00:15** 写 `dt=2026-07-15`。历史补算待分区（当前动态分区只有 07-15 起）。

## 2026-07-15 18:46

- **野花令「知秋同意了可以上」**（狂人暂死）：开干 prod。
- 平台 `prod-sync/apply` 新建 wf 踩坑：`_create_prod_wf` 写死 `process-definition` → 新 prod DS 3.4 **405**；改走公网 EIP `13.212.153.182` 先 stub `workflow-definition` 再建，再 `apply_sync` update。
- **prod 已落**：
  - `wf_用户日快照_日` code=`178870612504704` ONLINE；tasks S1+S2；SQL=git MATCH
  - `wf_用户日快照_日_补算` code=`178870613030016` ONLINE；DEPENDENT remap → prod `wf_dwd_事件明细_日`(`174729507576640`)
  - schedule id **25**=`0 15 0 * * ? *` / **26**=`0 30 3 * * ? *` Asia/Shanghai；**暂 OFFLINE**（等建表）
- **卡点**：`sr_prod` 只读，CREATE 需野花写账号跑 `dim_user_daily_snapshot_ddl.sql`。建完 → schedule online + PublishRun/stage7 + 可选补数。
- TG：私聊野花#4106（附 DDL）/ 群#4107。

## 2026-07-14 15:02

- **bus#4472**：狂人 ACK 明晨双盯（00:15 早窗 / 03:30 补算），实例+表数据双验后回；ordered_today/sign-off 等知秋，不代推。

## 2026-07-14 09:32

- **bus#4424 调度目标态全闭环 PASS**：
  - 早窗 `22335482717184` ONLINE v7 ROOT→S1→S2 sched#127 00:15 Asia/Shanghai
  - 补算 `22343669874432` ONLINE DEPENDENT→S1b→S2→S3 sched#128 03:30 Asia/Shanghai
- 明晨盯：00:15 早窗 / 03:30 补算 / 07-15 白天对账(paid+品类+channel)。三点绿 + 知秋裁 ordered_today → sign-off。
- 野花今日 UI 人点获认可。

## 2026-07-14 09:27

- **bus#4421**：早窗终验 PASS（ONLINE v7，ROOT→S1→S2，cron 00:15）。补算 **必须** 加 schedule `0 30 3 * * ? *`（03:30）+ ONLINE；DEPENDENT≠触发器。待野花 UI 点完回报 schedule id。

## 2026-07-14 09:20

- **bus#4416 目标态整改**:
  - design §6 / task.yaml 对齐：早窗无 DEPENDENT、无 S3；补算 DEPENDENT→S1b→S2→S3。
  - 早窗：已删 S3(`22335954501760`)；DEPENDENT 摘除 API 会断 root→S1 边导致 cycle(50019) → **留野花 UI 摘 `dwd` DEPENDENT，使 S1 为入口**。
  - 补算：已挂 S1b=`22343844271232` → S2=`22343846092416` → S3=`22343846290304`；入口 DEPENDENT=`22343661350144`（现名 `dwd`，需改名为等_dwd_事件明细_日并核对依赖 wf_dwd_事件明细_日）。
  - cron 00:15 / 03:30 + 两 wf ONLINE：UI。

## 2026-07-14 07:55

- **bus#4393**：①②③+col_list 全销案。悬挂 a补算wf / b stage凭证 / c ordered_today。
- stage_evidence 已写入 session `dev-20260713-002`（4/5/6 凭证字段）；**stage4_db_check 三勾留给野花面板点**，AI 未 API 代勾。

## 2026-07-14 07:52

- **bus#4389**：①③②基本销案；尾巴=S1b INSERT 补显式 23 列清单（8DWD 铁律）→ 重新 push，回报新 SHA。
- 后续：a) 野花 UI 建补算 wf 后挂 S1b→S2→S3；b) stage4/5 凭证补登记；c) ordered_today 知秋未裁不动。

## 2026-07-14 07:55

- **bus#4387 有条件 ACK 落地**:
  - design §6：补算窗改 S1b UPDATE 结算列（护 channel）+ INSERT 迟到 paid；触发=`等_dwd_事件明细_日` DEPENDENT（禁固定钟点）。
  - design §2.1：注明 comic/novel 与源差=无 4 源观看者不进宇宙。
  - 新增 `dim_user_daily_snapshot_s1b.sql`；task.yaml 登记补算 wf。
  - **07-13 手工 S1b 补算 PASS**：Σpaid_amount_today=**13,691,000** = dwd；行 290171→290191（+20 late paid）；missing=0。
  - 补算调度：**待 UI 建** `wf_用户日快照_日_补算`（入口 DEPENDENT 抄维度日）后挂 S1b→S2→S3。平台 create-task 仅 SQL，DEPENDENT 需人点 UI。
  - stage 凭证：本批文件 commit+push origin（SHA 回 bus）。

## 2026-07-14 07:45

- **bus#4374 stage7 打回处理中**:
  ① test SHOW PARTITIONS 全部 ReplicationNum=**3**（含 p20260712/13）；仓 DDL=3。
  ② 结算调度: design §6 已写 **方案 B**（早窗 0:15 保 0:30 + **04:10 补算**重跑 S1/S2/S3）。**等 ACK 再改 cron**。
  ③ S3 07-13 手工补成功: Σcomic=101640 Σnovel=173825 Σvideo=1012921（clone 齐后）。**04:10 S3 调度尚未挂**，等方案 B ACK 一并改。
  - ordered_today / stage 凭证 push / 禁 API 跳审核: 认。


## 2026-07-13 21:50

- **bus#4331 PASS**：技术侧复核通过。已 create-session `dev-20260713-002` ← draft `draft-8d2845f1de4b`，并 request-publish（待知秋 sign-off）。

# dim_user_daily_snapshot 开发存档

## 2026-07-13 21:50

- **bus#4331 PASS**：技术侧复核通过。已 create-session `dev-20260713-002` ← draft `draft-8d2845f1de4b`（已删），`request-publish` pending → reviewer=知秋。

## 2026-07-13 15:28

- **野花令「报狂人」**：准备 bus 报送 test 挂载+真跑+深验全 PASS（D=2026-07-12）。等狂人审 / 是否可 request-publish。

## 2026-07-13 15:26

- **野花「深验」**：playbook A2–A7/A9 对 `dt=2026-07-12` **全 PASS**（详见 playbook 记录区）。宇宙对齐、user_type、内容 cnt、first_paid 均 0 偏差。
- 下一步：报狂人。

## 2026-07-13 15:16

- **野花「真跑」**：`START_PROCESS` + `TASK_ONLY` 仅跑 SQL task（跳过 DEPENDENT）。
- PI=`58680` / TI=`153651` **SUCCESS**（~2s 墙钟但已落数；宏解析业务日=`2026-07-12`）。
- test 自验：`dt=2026-07-12` **98996** 行 / 21 app；PK 无重；VIP=7771 NORMAL=91225；`update_time`=15:16:00 对齐海豚。
- 备注：complement-data 曾 502（DS start error）；改用 process-instances/start 成功。误触第二枪 PI=`58681` 亦 SUCCESS（同日幂等）。
- 下一步：按 playbook 系统勾 A4–A7 → 报狂人。

## 2026-07-13 15:12

- **野花「Wf好了」**：test 已见 `wf_用户日快照_日` code=`22335482717184`（初建含 DEPENDENT `dwd`=`22335477229696`）。
- **已挂载** SQL task `dim_user_daily_snapshot` code=`22335533939456`，mode=after(dwd)；五步 offline→put→online→schedule_online 全过；`schedule_id=127`；wf 现 **ONLINE v2**。
- lint：SQL 注释禁止写宏字面量（`$[]`/美元花括号），已改注释；真实宏保留。
- 下一步：补数/start 真跑 → playbook Part A 勾验 → 报狂人。

## 2026-07-13 14:52

- **野花令「开干」**：已落 `playbook.md`（Part A DB 验数 A1–A9 + Part B 海豚挂载 + Part C 报审）。
- **阻塞**：平台无「新建空 wf」API；`wf_用户日快照_日` 须 test 海豚 UI 先建，才能 `POST .../workflows/{wf}/tasks` 挂载。
- 下一步：UI 建专 wf → 挂 task → 真跑 → 报狂人。

## 2026-07-13 10:49

- **野花令**：指标口径 / 反爬降优先；**先干用户日快照**（本作业唯一主线）。
- 下一步不变：挂专 wf → playbook 验数 → 报狂人。

## 2026-07-13 16:21

- **野花令「回狂人」**：bus 报送 #4277/#4282/#4283 落地 + 三段挂载 + PI 58694 真跑核数。

## 2026-07-13 16:10

- **野花令「真跑」**（三段）：`START_PROCESS` + `TASK_POST` 从 S1 起（含 S2/S3，跳过 DEPENDENT）。
- PI=`58694`：S1 TI=`153694` / S2=`153695` / S3=`153696` **全 SUCCESS**（~5s）。
- 业务日 **2026-07-12**；test 核数：`84468` 行 / 21 app（较旧 11 源宇宙 98996 ↓，符合 4 源收窄）；PK 无重；VIP=7771 NORMAL=76697；paid_cnt=190 / first_paid=176 / paid_users=179；pv=1286688；video/comic/novel=334843/99605/159297。

## 2026-07-13 16:06

- **野花令「挂三段」**：test wf `wf_用户日快照_日` v5 ONLINE 已挂链：
  - DEPENDENT `dwd`(`22335477229696`)
  - → `dim_user_daily_snapshot`(`22335533939456`) = **S1 SQL**（旧单 task 已 publish 替换）
  - → `dim_user_daily_snapshot_s2`(`22335954339200`)
  - → `dim_user_daily_snapshot_s3`(`22335954501760`)
- schedule_id=127；五步均 ok。
- 下一步：真跑三段 / 等狂人复核；S1 任务名仍为旧名（内容已是 S1）。

## 2026-07-13 15:50

- **bus#4283**：撤回「归因不碰 snapshot」。DDL 已核实 PRIMARY KEY(dt,app_id,uid)，channel 非主键可被 Step3 UPDATE。文档已改。

## 2026-07-13 15:45

- **bus#4282**：S1 5min硬窗(0:15-0:20)；first_paid 仅自表 NOT EXISTS；ETL 拆 s1/s2/s3；channel=first-non-organic-wins 初值（#4283：归因 Step3 可 UPDATE）。
- test 07-10：S1 2.7s / S2 3.9s / S3 3.7s（样本集群，prod dry-run 另报）。

## 2026-07-13 15:35

- **bus#4277 REJECT**：universe 改回 4 源；品类/交互只 LEFT JOIN；first_paid 改自表+all.first_pay_*；paid CTE amount>0。SQL/spec/design 已改，报审。RP HOLD。

## 2026-07-13 08:55

- **bus#4218 铁律**：海豚 SQL 禁 `${}`，改 `$[]`。snapshot daily 已扫改：`PARTITION (p$[yyyyMMdd-1])` + `'$[yyyy-MM-dd-1]'`；task.yaml params 清空。

## 2026-07-11 23:20

- **bus#4150 两案全定进 test**：v1 CTE；comic/novel IN VIEW+*_VIEW；长尾观察不收。
- stage3：DDL(BUCKETS 64 对齐 grp)、daily SQL、task.yaml 已落；test 表已建（repl=1，暂无 colocate——与 group repl=3 冲突）。
- test 自验：`dt=2026-07-10` INSERT OVERWRITE SUCCESS（需先关 DP 补历史分区 p20260710）。
- 下一步：挂专 wf / playbook 验数；报狂人。


## 2026-07-11 23:15

- **狂人 bus#4148** 有条件批落地：
  1. paid 保留=业务起点（无清理）：`wf_清理历史分区_日` 仅 3 表；平台无「数据中心-清理数据」；`dynamic_partition.start=-9999`；199 日连续 → **v1 CTE**
  2. comic/novel 近 3 天分布：COMIC_VIEW≈21.7M、NOVEL_VIEW≈0.67M → `IN (VIEW, COMIC_VIEW/NOVEL_VIEW)`
- 下一步：stage3 DDL/分段 ETL + test。

## 2026-07-11 23:05

- **狂人 bus#4146** 三疑点钉死并写入 design：
  1. video=`video_behavior_key='video_view'`；comic/novel 后被 #4148 扩成 IN VIEW+*_VIEW
  2. channel=事件原始直出，不做归因
  3. first_paid 方案 A → #4148 确认无滚动清理后批 v1
- 下一步：等狂人审 §5；stage3 DDL/分段 ETL。

## 2026-07-11 22:50

- **知秋终稿开工** bus#4144：23 列定稿（删 5 冗余布尔；加 geo 三列；首事件口径）。
- spec + design 已更新；first_paid 倾向 A；分层 L1/L2/L3 可砍。
- 下一步：stage3 DDL/分段 ETL + 专 wf；test 建表。
- 发布：等飞飞 reviewer 部署，狂人通知；request-publish。
- 旧拉链：v54 INSERT0 no-op 封存中。
