# memory · 页面停留 / sid 宽表

## 决策
- 从 0 新建，不改 ads_user_page_behavior_stats_d
- 知秋：先 dwm sid 宽表；相邻 PV 卡时间
- 狂人 bus#4083：1800s / 末页不计 / 空sid丢弃+dropped探针

## 进度 2026-07-14
- bus#4377 stage7 复审：技术面 PASS；整改① stage6 git 全套入库+push ② INSERT 补 16 列 col_list
- test 海豚已发 v145/146（col_list 版）
- 待：狂人复验 → stage7 PASS → 人工界面点 publish（知秋铁律禁 API 跳审）

## 进度 2026-07-15
- 牡丹 bus#4687 会话时长 DWS 联评：主路径 sid轻汇总→DWS；page_stay 降旁路
- 又初联评结论：用户侧 dwm 原地加列（不改名）；设备侧新建 dwm_app_session_sid_device_d
- 设计 v0.1：`ops_system/04.dws/dws_session_duration_d/design.md`
- test T-1 有数：page_stay 4398267 / session_sid 1164040
- duration_bucket 五档已按 PRD§5.5.3 定稿；本地草稿已落 ops_system，待走平台 session 发 test

## 进度 2026-07-16
- bus#4819→4836 F1-F3 全闭环；bus#4837 **stage7 PASS**（dev-20260711-001/002）
- **知秋裁定 bus#4840**：空uid排除=账户口径维持，无需改码；匿名会话归设备侧后续议
- **停等**：①~~uid空43%~~已结案 ② duration_bucket→业务确认 ③ prod publish→知秋界面点

## 进度 2026-07-21（prod 发布预检 · 小花）
- 又初指派 prod 发布；预检全绿：render/lint 过（仅 dt/pt 未用 ${} 的良性 warning）
- test T-1(07-20)：page_stay=4,672,089 / session_sid=1,170,037；prod snapshot 依赖就绪(2006万行)
- prod：wf_dwd_事件明细_日 ONLINE(v168, code 174729507576640)；两表未建，随发布建
- dwd SQL repo==test 逐字一致；dwm SQL repo(180/420老档)≠test(候选B bounce0/60/300)——bus#5414 已知会初儿
- **野花令(07-21 23:04)：dwm 基准 diff 先不管，直接走发布流程（发布向导人工点）**

session_code: dev-20260711-001
