# Session memory · dev-20260727-010

## 2026-07-27 stage 2
- 表名保持单段 `_d`（对齐 comic_like），不 rename 到 `_d_d`
- MD-065～071 指标列不在本 DWD；bind 留给 `dev-20260727-011`
- 跳过 = `ad_close` + `close_type=skip`，无独立 skip 表
- ETL 时间窗用半开区间（优于 comic_like BETWEEN）
- 建议挂 `wf_dwd_事件明细_日`；不改 wf globalParams

## 2026-07-27 stage 3
- 用户选 **② 不拆子**：父会话持 6 outputs 继续写码
- DDL/ETL 已齐；lint ok=true（0 error / 0 warn）
- 列级血缘 146 行已写入 design.md（source=`event:<name>`）
- 无指标 bind（明细无 cnt 列）

## 2026-07-27 stage 4～6（测试完成 · 暂停 stage 7）
- **Part A**：sr_test 建 6 表；ETL 试跑 2026-07-24 有量（request 1857 等）
- **Part B**：用户手建占位 task `1`–`6` → publish SQL + 改名；`environmentCode=-1`
- 串行：`dwd_novel_purchase_d` → request → fill → impression_sdk → click_sdk → close → error
- 试跑 pi `#62487` 6 task SUCCESS（schedule_time 空 → T-1=07-26 空分区亦成功）
- task_code：request `22494144019712` / fill `22494145316480` / impression `22494146849408` / click `22494148307456` / close `22494150013568` / error `22494151491072`
- **平台坑**：`create_task_in_workflow` HTTP 404；`start_process` 走 `POST /api/v1/dolphin/process-instances/start`
- **stage 5**：sr_prod readonly；主验日 2026-07-25；CP1～5 全 pass；PK 去重偏差已记
- **stage 6**：git commit `1e8a40bb`；用户确认测试完成、暂不上线
- **现状**：stage 1–6 done，stage 7 pending；`prod_table_built=false`；续作走发布向导
- **下游**：DWS session `dev-20260727-011` 另开
