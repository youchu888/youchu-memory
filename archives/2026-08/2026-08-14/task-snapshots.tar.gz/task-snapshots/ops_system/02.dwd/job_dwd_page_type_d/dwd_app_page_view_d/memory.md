# memory · dwd_app_page_view_d

- P0：5 新字段；`page_enter_ts` 是 Unix **秒**；viewport `-1`→NULL；不补历史
- 日+时两份 ETL 都要改
- 平台职责止于 request-publish
- 姊妹 session：`dev-20260727-page-click-001`（已 RP）
