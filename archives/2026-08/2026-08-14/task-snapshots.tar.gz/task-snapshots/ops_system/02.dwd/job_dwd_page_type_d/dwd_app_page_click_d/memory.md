# memory · page_click 加列

## 2026-07-27 · 纠偏：必须严格走平台

- **问题**：IDE 曾直接对 `sr_test` ALTER、并裸调 `publish-task-sql`，跳过 Dev Session 面板三勾与 `publish-from-repo` 闸门。
- **纠正**：以 session `dev-20260727-page-click-001` 为唯一容器；后续 DDL/ETL/发海豚只走平台七步流。
- **权限**：prod 只读；stage 5 只 SELECT；发产 stage 6/7 交给有写权限的人。
- **压力**：禁止历史 COMPLEMENT；test 真跑 ETL 须用户确认窗口，避免扫 `page_click` 全日。

## 已落盘（可被平台流程复用）
- ALTER SQL / ETL / DDL / fanout 已在仓库
- test 表已有 10 新列；test 海豚 SQL 已含新字段（v240）——**仍须在面板补齐 stage4_db_check 三勾与 playbook 记录，才算正规 stage 4 done**
