# memory
P1 search_id/search_trace_id；P2 search_content_type 另议；职责止于 RP。
