# dev-20260719-001 设备标签 v2 merge_pool

## 2026-07-27 stage4 test 通过

- DDL：补 `dt` + PK `(dt,app_id,device_id,pool_source)`，对齐 active_d_d 分区属性
- ETL：PARTITION 改 `('p${pt}')`；`CAST AS VARCHAR`；默认 `bucket_n=1`（避免同分区多桶 OVERWRITE 互覆盖）
- 样例 `dt=2026-07-12`：
  - delta=91427 / expiry_7=60080 / expiry_15=72068 / expiry_30=1885
  - rows_total=225460 · uniq_dev=202545 · bad_device=0
  - boundary=0（test 无 `calc_dt=2026-07-11` prev 宽表，可接受）
- stage4_db_check：created / etlRan / playbookConfirmed → 推进 5/6 后 request-publish

## 2026-07-22 SF-81 Paimon 试点验数通过

- DWM 四表各 27 天（06-24~07-20）；06-21~06-23 源无 SF-81 行
- fail_hint=9：Paimon 并发写冲突；串行重跑 order×8 + ad×2 = **10/10 OK**
- 宽表 calc_dt=07-20 行 111348；multi7=70103 PASS
- 报告：`ops_system/04.dws/dws_device_tag_d/reports/paimon_verify_SF81_2026-07-22.md`
- 待拍板：uid_map 是否并行（dev-20260720-001）

## 2026-07-29 下线（bus#5693）

- **结论**：不修 SQL；v2 merge_pool/enroll_gate 架构已归档，设备标签主线改姿态 F Spark
- **test 海豚**：`dwm_device_tag_merge_pool_d_d` task_code=`22493680696960` → **flag=NO**（wf v23）
- **DAG 桥接**：`dwm_device_pay_sum_d` 直连 `dws_device_tag_d_b0`（去掉 merge_pool 边）
- **根因备忘**：`PARTITION ('p${pt}')` 引号内 `${}` JDBC 绑定失败（知秋铁律应改 `$[]`，但本 task 已废弃）

## 2026-07-27 stage6/7

- git：`origin/dev` @ `ec737adf`
- test 海豚：`wf_设备标签_日` 新建 `dwm_device_tag_merge_pool_d_d` task_code=`22493680696960`（after pay_sum）
- request-publish：**pending** · reviewer=`admin`（超管）· 等审 prod，不自发
- stage：1–6 done · 7 in_progress
