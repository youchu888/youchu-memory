# memory · DWM 设备会话 sid 宽表

session_code: dev-20260731-001

## 2026-07-31 · bus#5789 新建

- 知秋钦定：`dev-20260729-002` 仅 user DWS；设备链须 **先 DWM prod 后 DWS**
- prod 无 `dwm.dwm_app_session_sid_device_d`（狂人实地：dwm 仅 `dwm_app_session_sid_d`）
- 平台 sync + PUT state；stage1 in_progress
- 设备 DWS 代码暂存：`ops_system/04.dws/_parked_session_duration_device_d/`
