# memory · 页面停留 / sid 宽表

## 决策
- 从 0 新建，不改 ads_user_page_behavior_stats_d
- 知秋：先 dwm sid 宽表；相邻 PV 卡时间
- 狂人 bus#4083：1800s / 末页不计 / 空sid丢弃+dropped探针

## 进度 2026-07-14
- bus#4377：同父 session；dwm ETL 补 19 列 col_list；test 海豚 v146
- 待狂人复验 col_list + git SHA

## 进度 2026-07-16
- bus#4819 F3: test dolphin sid v220→v221，SQL 与 repo 逐字一致（duration_bucket 新档）
- 分档边界(180/420/900/1800)提案待知秋拍板，未 request-publish

## 进度 2026-07-21（prod 发布预检 · 小花）
- 分档已按候选B落 test（bounce=0/60/300/900/1800，知秋终裁，狂人 bus#5329 PASS）
- **基准现状**：test v221=候选B=本地WIP；origin/dev 仍老档(180/420)，候选B在 session-duration-bucket-b(850af4a2) 未合 dev
- 07-20 test 分布：bucket0=867,617 / 1=58,237 / 2=83,087 / 3=80,237 / 4=35,390 / 5=22,591 / NULL=22,878
- **野花令(07-21 23:04)：基准 diff 先不管，直接走发布流程**；bus#5414 已知会初儿

session_code: dev-20260711-002
parent: dev-20260711-001
