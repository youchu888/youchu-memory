# memory · ads_product_day_stat_d

## v5 · ad_impression_cnt（2026-08-27）
- 字段：`ad_impression_cnt = SUM(ads_ad_space_summary_d.exposure_pv)`
- DDL：`ads_product_day_stat_d_alter_v5_ad_impression.sql`
- test 锚点@2026-08-26：全局 exposure_pv=65973

## v4 · video_play 对齐（2026-08-21）
- `video_play_cnt` = `SUM(dws.dws_video_account_d_d.play_count) WHERE video_content_type='all'`
- prod publish v157

