# 漫画分析账号维日汇总 — 会话备忘录

> session `dev-20260814-comic-001`。记跨 stage 决策，不替代 spec/design/playbook。

## 2026-08-14

- **仅账号表**：设备维本期不做。
- **BITMAP**：所有 BITMAP 列无数据一律 `BITMAP_EMPTY()`，禁止 NULL（bus#6525）。标量 bitmap 函数遇 NULL 会静默出 0。
- **channel organic 兜底**：`COALESCE(dim_user_all.register_channel,'organic')`；join 不上也计 organic。228k 哨兵 cohort 永久 organic。
- **维来源**：只 JOIN `dim.dim_user_all`（`app_id+uid` 双列），禁止 `dim_user_daily_snapshot`。
- **DAG**：`mode=parallel` + anchor=`ads_app_summary_d` 才能挂到 `等_dws_汇总_日` 扇出；直挂 `等_dws` 的 parallel 会落成 ROOT。禁止 `mode=after` 抢边。

## 2026-08-15

- test：表已建 · task `22699282398336` · v310 · complement PI67795 SUCCESS · C1–C8 PASS。
- prod 只读 dry-run：ADS 表不存在；上游五张 DWD + dim 都在；闸门（唯一/守恒/UDF）过。**WARN 不装 PASS**。
- git `2a9ee8ab` 已 push；stage6 done。

## 2026-08-18

- request-publish → 又初 pending。
- **prod 先 DDL**：过审后顺序不能倒：DDL → 建 task → DAG 同级扇出 → 发 SQL → 再补数（历史起点 2026-03-09）。
- 开发不直写 prod；又初默认不自发 prod。
