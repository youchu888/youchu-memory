# memory · DWS 会话时长五档

session_code: dev-20260729-002（重建；旧 `dev-20260721-002` 已删：backend 文件 410 / 他人打不开）

## 2026-08-18 · bus#6668 工作簿状态改 HOLD（口径分层）

- 工作簿「子项·停留时长」状态固定为：`HOLD · 等产品答复离开事件埋点(狂人 bus#6573 Q1-Q3)`（`workbook_progress_service.py`）
- prod 有分区≠完成；单页会话缺离开事件，数仓补不了
- **口径分层（勿混答）**：
  - **bounce/有效会话（<5s、>12h 剔除）**：✅ 已与产品确认 — 阿莱士，2026-08-17（私聊#330/#331），无 bounce 概念，墙钟 <5s 或 >12h 直接剔除
  - **08-04 commit a17b55f6**：当时开发自解读 PRD 未当面确认；08-17 阿莱士答复与现 DWM `is_valid` 一致，可视为事后对齐
  - **离开事件埋点（单页会话测不出时长）**：❌ 产品未答复 — 这才是 bus#6573/6668 HOLD 所指

## 2026-08-17 · 产品阿莱士口径（私聊#330/#331）【已确认】

- **无「跳出/bounce」概念**（产品阿莱士 2026-08-17 明确）
- **页面停留时长**：墙钟 **<5 秒** 或 **>12 小时** 的会话 **直接剔除**，不进五档汇总
- 与 DWM 现逻辑一致：`is_valid=1` ⇔ `5s ≤ session_duration_sec ≤ 43200`；剔除侧 `duration_bucket=NULL`
- **废止**：2026-07-21「bounce 单列第 0 档」、`bounce_cnt` 进 DWS 时长分布 — 以产品本条为准，待知秋书面确认后改 test ETL/文档
- prod 现役 DWS 仅 `is_valid=1` 与产品一致；test 仓 `(is_valid=1 OR bounce bucket0)` 草案应回退
- 已 bus 狂人同步（私聊#331/#332）；45 天 prod 重跑仍 HOLD
- **主人 2026-08-17**：不再周期性 bus 催狂人/知秋（#329/#332 停 30 分钟催办）

## 2026-08-17 · bus#6586 第三次打回

- 快车道误结案：09:12 自动 reply「待命/rest」未答 Q1-Q3；主人私聊#321 要求补正
- Q1（分层）：**离开事件埋点**未问产品；**有效会话/<5s/12h** 08-17 已与阿莱士确认（私聊#330/#331）；08-04 a17b55f6 为开发自解读，事后与产品对齐
- Q2：仓库无 PRD §5.5.4 逐字原文；最近似表述「小于5秒与大于12小时不参与计算」
- Q3：产品未答复；45 天重跑 HOLD
- COMMENT 三处补丁已落 `dws_session_duration_user_d_ddl.sql` + design.md 对齐 bounce 第0档
- prod 现状：bucket0=0，dwm bounce 未进 DWS（08-14 bounce 856万 vs DWS session 2241万）

- 过滤：session/daily 一律 `is_valid=1`（去掉 `OR duration_bucket=0`）
- test 发布 user DWS v6；T-1 试跑 SUCCESS；`duration_bucket=0` 行数 0
- 文档：spec / design / playbook / README 已对齐；设备 parked SQL 同步改（未发布）
- prod 未发

## 2026-07-29 · 重建可打开 session

- 误把「设备标签」当打不开目标 → 已撤回 `dev-20260729-001` 对野花的 publish（设备标签无海豚发布需求）
- 真正打不开：`dev-20260721-002`（path-only + 内容已不在 backend → 410）
- 新建 `dev-20260729-002`：`project_id=dmp/dc-parent`，`rel_dir=ops_system/04.dws/dws_session_duration_d`
- **主人纠正**：空标 stage1~6 done 不够；野花插件要读 `strict_mode/owner_boundary/stage4_db_check/stage5_prod_dryrun/stage6_commit`
- **严格重走**（biz_dt=2026-07-28）：test 列/行/grain PASS；live SQL markers PASS；prod 两表 `__TABLE_MISSING__`；commit 已记
- `state_json` 现 26 key，五件齐；**request-publish** pending → **蓝猫**（主人 07-31 改派，原野花）
- 报告：`_strict_rewalk_report.json`

## 2026-07-25 · 合表落地

- 账号侧 + **设备侧** DDL/ETL 均已合表（stat_grain=session|daily）
- `dws_session_daily_user_d` / `dws_session_daily_device_d` deprecated
- **test 迁移**：DDL/DROP 用 `root@43.212.113.132:9030`（无密码）；`my.cnf.test` 的 admin 仅 dc_admin 角色，dws 无 DROP
- test 账号 dt=2026-07-24：session 870578/282260/bounce 639130；daily user 184944
- **2026-08-03 PRD §5.5.4**：DWS session 去掉 `OR duration_bucket=0`，仅 `is_valid=1`；test 发 v6 + T-1 试跑 SUCCESS，bucket0=0。prod 未发。
- test 设备 dt=2026-07-24：session 1314326/720989；daily device 368098
- **#220**：`avg_session_duration_sec` + `avg_daily_duration_sec` 分列
- 海豚：`dws_session_daily_*` task 待停用；只保留 `dws_session_duration_*`
- **dev session `dev-20260721-002`**：outputs 4→2、DDL/ETL/task.yaml 已同步平台（2026-07-25）
- **test 发布**（2026-07-25）：user v137 / device v138；PI61929 SUCCESS；dt=2026-07-24 验数 PASS
- **request-publish** pending → reviewer=**蓝猫**（hull367660@gmail.com）；主人 07-31 改派
- **遗留**：daily 旧 task 22357870925056/22357871175296 仍在 wf（delete API 404），审核时建议下线
- **dev session**：`dev-20260721-002` 已同步 v2（title/outputs 2表/12 工件 push 平台）

## 2026-07-27 · 知秋统一分档

- 主人令：单次/日均、用户/设备 **一律候选 B**（bounce=0 + 60/300/900/1800）
- 设备 DWM 原 180/420 已改齐；design §3 废止 PRD 单次双轨
- 用户 DWM 本已是 60/300；野花 bus#5501 异议项据此消
- **git**：`bf316ab2` 已 push `origin/dev`
- **test 发布**（live=local）：device DWM 22357755019392 v231；user DWS v139；device DWS v140
- **补跑**：schedule=2026-07-27（dt=07-26）pi62412/62413/62414 SUCCESS
- **验数**：设备 DWM bucket1≤60、bucket2=61~300；bounce→0 违规=0
- 已 bus#5538 请野花再审 pending request-publish（后改派蓝猫，见 07-31）

## 2026-07-31 · 知秋钦定：收敛单目标表（bus#5789）

- 狂人 admin `fix-metadata`：`outputs` / `dolphin_owned_tasks` 已摘 `dws_session_duration_device_d`
- 又初跟进：PUT `/full` 更新 `related_tables`；`task.yaml` 仅 user；设备三文件移至 `_parked_session_duration_device_d/`
- 设备 DWM 新 session：`dev-20260731-001`（`job_dwm_app_session_sid_device_d`），须先 prod 再开设备 DWS session
- 本 session request-publish 仍 pending → 蓝猫

## 2026-07-31 · prod 用户表上线 + 数据字典（bus#5802）

- 狂人 prod 建 task `180283360953472`；知秋重建表（`history_partition_num=30`，`start=-10000`）
- 07-30 首补 SUCCESS；design.md 已补 §10 数据字典 + §11 口径 A/B/C
- PUT `/full` 合并 prod dolphin_owned_tasks / stage5 / prod_target（未覆盖设备摘出）

## 2026-08-15 · bus#6557 打回「已完成」（bounce 缺失 + COMMENT 未交底）

- 狂人 prod 复核 bus#6556：行数/conservation 对，但 bounce 45 天全 0、bucket0 无行
- 根因：2026-08-03 DWS 仅 `is_valid=1`，bounce 上游 `is_valid=0` 被整段过滤
- dt=08-14：dwm is_bounce=1=8,560,961；DWS bounce_cnt=0
- 条件2：`duration_sum_sec`/`user_cnt` prod COMMENT 缺 stat_grain 取数规范
- **已完成撤回**；修复：session WHERE 加 bounce 单列 + COMMENT/design 补齐 → test 验数后再 RP
- 2026-08-15 下午：主人令继续推进。已改本地 ETL `is_valid=1 OR (is_bounce=1 AND duration_bucket=0)`，DDL/design/playbook 同步；待 test 发版试跑 T-1，prod 等知秋确认后 RP
- 2026-08-15 15:45 test v189 PI 67837 SUCCESS dt=T-1：bucket0=bounce=dwm_bounce=145771；档1–5 session_cnt=306509=dwm_valid；daily 无 0 档。COMMENT 已改 test。**禁止 ALTER COMMENT 与 INSERT 并行**（67835 秒败 SCHEMA_CHANGE）。prod 未 RP。

## 2026-08-01 · YC-002 新用户漏斗对账（bus#5853）

- 狂人 prod 独立复现三层数，拆清 L1 注册 → L2 DWM is_new → L3 is_valid=1 → L4 DWS SUM(user_cnt)
- 结论：**非 bug，口径漏斗**；daily 无 bucket0，无有效会话者不落档
- 又初同意 A/B 倾向：A 不计无有效会话、页面标注；B 先修展示 grain 名实相符；不动 ETL
- 已写入 `design.md` §11-D + `playbook.md` part_04


## 2026-07-28 · 旧 daily_* task 下线

- test `wf_dws_汇总_日` 删除 `dws_session_daily_user_d` / `dws_session_daily_device_d`（表早 DROP，task 残留导致汇总日调度挂）
- 根因：合表半迁移；已沉淀 lesson `2026-07-28-deprecate-must-offline-old-dolphin-task`
