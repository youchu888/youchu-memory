# memory · dws_app_page_visit_d_d · dev-20260804-002

- 显示名：【页面访问·日指标】dws_app_page_visit_d_d · 又初
- **口径权威**：http://54.255.236.159:8012/library/metric_page_visit_analysis（2026-08-05 对齐）
- 表：`dws.dws_app_page_visit_d_d`；只账号；跳转边表已删
- 只落分子分母；比率查询侧现算；uid_cnt=BITMAP
- **2026-08-21 口径改定**：进入=本页且来路非空非 unknown；跳转=来路本页且去向非空非 unknown 且≠本页
- 2026-08-21：test publish v195→**v196**；补分区 `p20260721`；COMPLEMENT 业务日 **2026-07-21～08-20**（schedule 07-22～08-21 05:20）TASK_ONLY 全 SUCCESS
- 对账 TJ-027 / JHA-124：DWS↔DWD 的 pv/entry/jump **三指标 diff=0**；TJ 进入里约半数为自刷新（ref=pk），故 entry≫jump 属口径现象非 ETL 错

- 2026-08-06 11:52：test 挂 task `22599391396992`（wf_dws_汇总_日 v167）；PI64878 SUCCESS；dt=2026-08-05 rows=20062 pv=5890928 uv=309818
- 2026-08-06 11:52：git `ceace1b7` 已 push；request-publish pending → 野花（kakakh7787@gmail.com）
- 2026-08-06 12:06～12:08：prod 首次发布（publish-run #526/#527，task `180825664895104` @ wf_dws_汇总_日）；审核/发产人为 **野花**
- 2026-08-21：新口径 test 已验；重新 request-publish → 野花（又初无 prod 发权限）
