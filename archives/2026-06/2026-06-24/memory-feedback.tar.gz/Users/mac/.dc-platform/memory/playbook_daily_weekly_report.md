# Playbook：日报 / 周报（基于 work-log）

> 维护人：又初 · 本地 playbook · 不进 Git  
> 日历：[`reference_work_calendar_cn.md`](reference_work_calendar_cn.md)

## 触发

| 类型 | 触发 |
|------|------|
| 日报 | 用户说「日报/今日总结」；或 **工作日** 21:30 Asia/Shanghai 自动 |
| 周报 | 用户说「周报/上周总结/本周计划」 |

## 日历规则（摘要）

| 项 | 规则 |
|----|------|
| 周报统计周期 | **自然周**（周一 00:00 ~ 周日 24:00），`YYYY-Www` |
| 常规工作日 | **周一至周六**（6 天） |
| 常规休息 | 周日 |
| 法定假日 | 国务院安排，**不要求日报**，不计入「应完成工作日」 |
| 调休上班 | 国务院指定日（含部分周日），**计工作日**，需日报 |

## 数据源（按优先级）

**日报内容只来自当日用户提问/交办**，不臆造未交办项。

1. **当日** `agent-transcripts/**/*.jsonl` 中 `"role":"user"` 消息（主来源）
2. 当日对话上下文中的完成结果
3. **`work-log/YYYY-MM-DD.md`**（若已有，用于核对）
4. `git log --since=<当日0点> --until=<次日0点>`（辅助）
5. `lessons/_index.md`（仅写【死锁阻碍】）

## 日报流程（生成 → 记录）

1. 检索**当日**用户全部交办（transcript grep / 会话记忆）
2. 按模板写 `【今日结果】` 3 条左右，每条 20～30 字
3. **落盘**：`CHcode/.cursor/work-log/reports/YYYY-MM-DD-日报.md`
4. **同步**：更新 `.cursor/work-log/YYYY-MM-DD.md` 的 `## 完成` / `## 阻碍` / `## 明日`
5. 无交办的工作日：可不生成，或写「无交办」一条

## 日报模板

```markdown
# 日报 · 又初·YYYY-MM-DD

[REPORT-ORG:天穹部门] [LEVEL:L1] [TYPE:日报] [DATE:YYYY-MM-DD]
> 提交人: 又初 · 工号: DN6517 · 岗位: 后端 BE · 层级: L1

## 【今日结果】
- [TQ-002 | DMP系统] ……（20~30字），已完成；

## 【死锁阻碍】
- 

## 【专项复盘】
- 

## 【明日动作】
- TOP1: …（截止：下一工作日）
```

规则：

- 仅**工作日**生成；法定假日跳过（除非用户显式要求）
- `【明日动作】` 指**下一个工作日**（跳过周末与法定假）
- 每条 20～30 字；通常 3 条

## 周报模板

```markdown
# 周报 · 又初·YYYY-Www（MM-DD 周一 ~ MM-DD 周日）

[REPORT-ORG:天穹部门] [LEVEL:L1] [TYPE:周报]
> 统计周期：自然周 · 有效工作日 N 天（已扣法定假/含调休）

## 【本周完成】
（合并该自然周内**工作日** work-log，按专项分条）

## 【卡点】
（work-log 阻碍 + lessons）

## 【下周计划】（自然周 YYYY-Www+1）
（仅排**工作日** TOP3；标注 P0/P1；遇端午/国庆等注明放假区间）
```

## 收尾

- 缺当日流水 → 生成日报时**一并创建/更新** `.cursor/work-log/YYYY-MM-DD.md`
- 正式日报/周报必存 `.cursor/work-log/reports/`
- **周日或下周一**：刷新 `.cursor/work-log/YYYY-Www.md` + `reports/YYYY-Www-周报.md`
- 写周报：合并该自然周各 `reports/*-日报.md`，去重按专项归纳
- 写周报前先读 `reference_work_calendar_cn.md` 算有效工作日天数
