# memory

- 会话 `dev-20260610-904`，rel_dir `ops_system/04.dws/dws.dws_register_attribution_result_d`
- 2026-06-10 口径反转：attribution_flag=1（客户端标记需归因）才计算；0/NULL 跳过
- 测试 dws task v5 已上线；schedule 发布后必须复位 ONLINE（踩坑 2026-06-09）
- 生产上线前置：dwd_user_register_d_v2 加 attribution_flag、dim 配置加 is_rewrite_channel（生产 SR readonly，需海豚/ETL 账号执行）
- 经验：.claude/memory/lessons/20260609-attribution-flag-column-order.md
