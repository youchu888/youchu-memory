# dwd_user_register_d_v2_daily双扫迁移 — 会话备忘录

> **会话级 free-form memory**，全 stage AI / 用户都可读可写。
> 用途：记跨 stage 的**重要决策 / 用户口头确认 / 踩坑发现 / 临时 context**——这些不适合塞进 spec/design/playbook 但又必须跨 stage 共享。
> 写法：日期戳 + 单行决策 / 备注。AI 在任何 stage 发现重要 context 都该追加。

## 2026-06-17
- 会话 dev-20260617-002 创建
